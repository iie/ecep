<?php
namespace App\Http\Controllers\IIE;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Region;
use App\Models\Aplicaciones;
use App\Models\EvaluadosAplicaciones;
use App\Models\EstudianteListado;
use App\Models\CentroInstitucion;
use App\Models\CentroAplicacion;
use App\Models\Dependencias;
use App\Models\Carrera;
use App\Models\LimeResultado;
use Illuminate\Support\Facades\DB;
use App\Models\Institucion;

class Asignacion extends Controller
{
	 
	public function __construct()
    {
		$this->fields = array();	
    }	
	
    public function asignacionDias($doc)
    {
		
		/*************************************************************/
		/** A DISTANCIA
		/** - comuna de residencia y aquellas comunas en las que no tenemos sedes de aplicación, se asignaron a la más cercana

		/** PRESENCIAL
		/** - 1er Alumno rinde en su sede/universidad
		/** - 2do Los alumnos rinden la prueba en la comuna de su sede/universidad 
		/*************************************************************/
		
		/**Laboratorios*/
		$path = app_path('Http/Controllers/')."IIE/datos_txt/asignacion/";
		$file = file($path."laboratorios4enero.txt");
		
		$laboratorioPorDias["Día 1"] = array();
		//$laboratorioPorDias["Día 2"] = array();
		//$laboratorioPorDias["Día 3"] = array();
		//$laboratorioPorDias["Día 4"] = array();

		$index_region = 1;

		$index_universidad = 2;
		$index_comuna = 4;
		$index_sede = 6;
		
		$index_nombrelab = 9;
		$index_dia1 = 17;
		$index_dia2 = 11;
		$index_dia3 = 12;
		$index_dia4 = 13;
		$index_confirmado = 15;
		
		// foreach($file as $fileAux){
			// $noContar = ["Universidad de O'Higgins"];
			// $fileAux = trim($fileAux);
			// $campos = explode("\t", trim($fileAux));		
			// if(!in_array($campos[$index_universidad], $noContar))
			// $institucionestudios = Institucion::where("nombre_institucion", multibyte_trim($campos[$index_universidad]))->first();
			// if(!isset($institucionestudios->id)){
				// arreglo($campos);exit;
			// }
		// }	
		
		$region = Region::get();
		foreach($region as $rr){
			$regNombre[$rr->numero_region] = $rr->nombre_region;
		}
		
		$noUsarLabs[] = 18;
		$noUsarLabs[] = 109;
		$noUsarLabs[] = 708;
		$noUsarLabs[] = 247;
		$noUsarLabs[] = 327;
		$noUsarLabs[] = 389;
		$noUsarLabs[] = 428;
		
		foreach($file as $fileAux){
			$fileAux = trim($fileAux);
			$campos = explode("\t", trim($fileAux));
			//arreglo($campos);exit;
			if(!in_array($campos[0],$noUsarLabs)){
				if((isset($campos[$index_confirmado]))&&(mb_strtolower(trim($campos[$index_confirmado])) == mb_strtolower(trim('Confirmado')))){

					$campos[$index_comuna] = mb_strtolower(multibyte_trim($campos[$index_comuna]));
					//if(array_key_exists($index_dia1, $campos)){
						//$resd1 = multibyte_trim(strtolower($campos[$index_dia1]));
						//if($resd1=='si'){
							//$laboratorioPorDias["Día 1"][multibyte_trim(mb_strtolower($campos[$index_universidad]))][multibyte_trim($campos[$index_comuna])][multibyte_trim(mb_strtolower($campos[$index_sede]))][] = $campos;
							$campos["disponible"] = $campos[$index_dia1];	
							$laboratorioPorDias["Día 1"][multibyte_trim(mb_strtolower($campos[$index_universidad]))][multibyte_trim(mb_strtolower($campos[$index_sede]))][] = $campos;
						//}
					//}
					//if(array_key_exists($index_dia2, $campos)){
						//$resd2 = multibyte_trim(strtolower($campos[$index_dia2]));
						//if($resd2=='si'){
							//$laboratorioPorDias["Día 2"][multibyte_trim(mb_strtolower($campos[$index_universidad]))][$campos[$index_comuna]][multibyte_trim(mb_strtolower($campos[$index_sede]))][] = $campos;
							//$campos["disponible"] = $campos[$index_dia2];
							//$laboratorioPorDias["Día 2"][multibyte_trim(mb_strtolower($campos[$index_universidad]))][multibyte_trim(mb_strtolower($campos[$index_sede]))][] = $campos;
						//}
					//}
					//if(array_key_exists($index_dia3, $campos)){
						//$resd3 = multibyte_trim(strtolower($campos[$index_dia3]));
						//if($resd3=='si'){
							//$laboratorioPorDias["Día 3"][multibyte_trim(mb_strtolower($campos[$index_universidad]))][$campos[$index_comuna]][multibyte_trim(mb_strtolower($campos[$index_sede]))][] = $campos;
							//$campos["disponible"] = $campos[$index_dia3];
							//$laboratorioPorDias["Día 3"][multibyte_trim(mb_strtolower($campos[$index_universidad]))][multibyte_trim(mb_strtolower($campos[$index_sede]))][] = $campos;
						//}
					//}
					//if(array_key_exists($index_dia4, $campos)){
						//$resd4 = multibyte_trim(strtolower($campos[$index_dia4]));
						//if($resd4=='si'){
							//$laboratorioPorDias["Día 4"][multibyte_trim(mb_strtolower($campos[$index_universidad]))][$campos[$index_comuna]][multibyte_trim(mb_strtolower($campos[$index_sede]))][] = $campos;
							//$campos["disponible"] = $campos[$index_dia4];
							//$laboratorioPorDias["Día 4"][multibyte_trim(mb_strtolower($campos[$index_universidad]))][multibyte_trim(mb_strtolower($campos[$index_sede]))][] = $campos;
						//}
					//}	
					
					$comunasConLaboratorio[$campos[$index_comuna]] = $campos[$index_comuna];
				}
			}
		}	
		
		//arreglo($laboratorioPorDias);exit;
		
		/**Fin Laboratorios*/
		//Día->universidad->comuna->sede->laboratorio
		// echo count($laboratorioPorDias["Día 1"])."<br/>";
		// echo count($laboratorioPorDias["Día 2"])."<br/>";
		// echo count($laboratorioPorDias["Día 3"])."<br/>";
		// echo count($laboratorioPorDias["Día 4"])."<br/>";
		// echo "----------------------<br/>";
		//arreglo($laboratorioPorDias);
		//exit;
		
		$file = DB::select("SELECT institucionestudios.id as id_universidad, id_excel_iie as cod_iie, nombre_institucion, nombre_sede, carrera, rut, evaluados.id_comuna, 
					carreras.carrera,		
					cs.nombre_comuna as nombre_comuna, 

     				ce.nombre_comuna as nombre_comuna_evaluado,
					rs.numero_region as numero_region_sede,
					rs.nombre_region as nombre_region_sede,	
					
					carreras.dia_de_aplicacion, modalidad_estudio, ce.region_id as region_reside, cs.region_id as region_estudia
					FROM evaluados,  institucionestudios, sedeinstitucion, carreras, comunas as ce, comunas as cs, regiones as rs 
					WHERE carreras.id_carrera = evaluados.id_carrera
					AND evaluados.complementaria = true
					AND sedeinstitucion.institucionestudios_id = institucionestudios.id
					AND sedeinstitucion.id = evaluados.sedeinstitucion_id
					AND evaluados.borrado = false
					AND ce.id = evaluados.id_comuna
					AND rs.id = cs.region_id	
					AND cs.id = sedeinstitucion.comuna_id
					ORDER BY modalidad_estudio DESC, carreras.dia_de_aplicacion ASC, nombre_institucion ASC, 
					nombre_sede ASC, carrera ASC, nombre_comuna ASC, nombre_comuna_evaluado ASC
					
					");
					
					
		$conDramas = array();
		$cont = 0;
		$bien = 0;
		$sin_asignar = 0;

		//$alumno_sin_cupo_en_laboratorio_de_su_campus = 0;
		//$alumno_estudia_en_universidad_sin_laboratorio_en_su_campus = 0;
		//$alumno_estudia_en_universidad_sin_laboratorio = 0;		

		$table = "<table border='1'>
			<tr>
				<td style='font-weight:bold; text-align:center'></td>
				<td style='font-weight:bold; text-align:center' colspan='5'>Datos de universidad/campus donde estudia</td>
				<td style='font-weight:bold; text-align:center' colspan='4'>Datos del alumno</td>
				<td style='font-weight:bold; text-align:center' colspan='7'>Datos donde aplica</td>
			</tr>
			<tr>
				<td style='font-weight:bold; text-align:center'>Día</td>
				<td style='font-weight:bold; text-align:center'>Universidad</td>
				<td style='font-weight:bold; text-align:center'>Campus</td>				
				<td style='font-weight:bold; text-align:center'>Región</td>
				<td style='font-weight:bold; text-align:center'>Región Nombre</td>
				<td style='font-weight:bold; text-align:center'>Comuna Campus</td>	
				
				<td style='font-weight:bold; text-align:center'>RUT alumno</td>
				<td style='font-weight:bold; text-align:center'>Comuna residencia</td>
				<td style='font-weight:bold; text-align:center'>Modalidad rinde</td>
				<td style='font-weight:bold; text-align:center'>Carrera</td>

				<td style='font-weight:bold; text-align:center'>Cod IIE</td>
				<td style='font-weight:bold; text-align:center'>Universidad Asignada</td>
				<td style='font-weight:bold; text-align:center'>Nro Región Asignada</td>
				<td style='font-weight:bold; text-align:center'>Región Asignada</td>
				<td style='font-weight:bold; text-align:center'>Comuna Asignada</td>
				<td style='font-weight:bold; text-align:center'>Campus Asignado</td>
				<td style='font-weight:bold; text-align:center'>Laboratorio</td>
			</tr>
		";
		foreach($file as $fileAux){
			$cont++;
			if($fileAux->modalidad_estudio==52){//presenciales 
				
				$fileAux->dia_de_aplicacion = 1;//para la segunda vuelta
				
				$universidad = mb_strtolower(multibyte_trim($fileAux->nombre_institucion)); // Pontificia Universidad Católica de Chile
				$campus = mb_strtolower(multibyte_trim($fileAux->nombre_sede)); // Campus San Joaquín
				$dia = "Día ".$fileAux->dia_de_aplicacion;
				
				if(array_key_exists($dia, $laboratorioPorDias)){
					
					//comprobación
					// if(!array_key_exists($universidad, $laboratorioPorDias[$dia])){
						// //"universidad sin laboratorio";
						// $sinLab[] = "ucinf";
						// $sinLab[] = "universidad iberoamericana de ciencias y tecnologías";
						// if(!in_array($universidad, $sinLab)){
							// echo $dia."-->".$universidad."|<br/>";
							// arreglo($laboratorioPorDias[$dia]);exit;
						// }
					// }
						
					if(array_key_exists($universidad, $laboratorioPorDias[$dia])){
						if(array_key_exists($campus, $laboratorioPorDias[$dia][$universidad])){
							foreach($laboratorioPorDias[$dia][$universidad][$campus] as $index=>$laboratorios){
								$totalDisponibles = $laboratorios['disponible'];
								if($totalDisponibles>0){
									$laboratorioPorDias[$dia][$universidad][$campus][$index]['disponible']--;
									$fileAux->laboratorio = $laboratorios;
									break;
								}
								else{
									//ya no hay cupos en laboratorio. lo quitamos de los disponibles
									unset($laboratorioPorDias[$dia][$universidad][$campus][$index]);
									if(count($laboratorioPorDias[$dia][$universidad][$campus])==0){
										unset($laboratorioPorDias[$dia][$universidad][$campus]);
									}
									if(count($laboratorioPorDias[$dia][$universidad])==0){
										unset($laboratorioPorDias[$dia][$universidad]);
									}	
									if(count($laboratorioPorDias[$dia])==0){
										unset($laboratorioPorDias[$dia]);
									}	
								}
							}
							
							
							if(isset($fileAux->laboratorio)){
								$region = Region::where('numero_region',$fileAux->laboratorio[$index_region])->first();
							
								if($fileAux->modalidad_estudio==52){$modalidad = 'Presencial';}
								elseif($fileAux->modalidad_estudio==51){$modalidad = 'No Presencial';}
								elseif($fileAux->modalidad_estudio==53){$modalidad = 'Semi Presencial';}
								$table.=  "<tr>
												<td>".$dia."</td>
												<td>".$universidad."</td>
												<td>".$campus."</td>												
												<td>".$fileAux->numero_region_sede."</td>
												<td>".$fileAux->nombre_region_sede."</td>
												<td>".$fileAux->nombre_comuna."</td>
												<td>".$fileAux->rut."</td>
												<td>".$fileAux->nombre_comuna_evaluado."</td>
												<td>".$modalidad."</td>
												<td>".$fileAux->carrera."</td>
												<td>".$fileAux->laboratorio[0]."</td>
												<td>".$fileAux->laboratorio[$index_universidad]."</td>
												<td>".$fileAux->laboratorio[$index_region]."</td>
												<td>".$region->nombre_region."</td>
												<td>".$fileAux->laboratorio[$index_comuna]."</td>
												<td>".$fileAux->laboratorio[$index_sede]."</td>
												<td>".$fileAux->laboratorio[$index_nombrelab]."</td>
											</tr>";	
								@$bien++;
							}
							else{
								//"alumno quedó sin cupo en laboratoro de su universidad/campus<br/>";
								//$alumno_sin_cupo_en_laboratorio_de_su_campus++;
								@$sin_asignar++;
								$conDramas[] = $fileAux;
							}
						}
						else{
							if(!@in_Array($campus,$ss[$universidad])){
								$ss[$universidad] = $fileAux->id_universidad."->".$campus;	
							}
							
							//arreglo($laboratorioPorDias[$dia][$universidad]);
							//exit;
							//$alumno_estudia_en_universidad_sin_laboratorio_en_su_campus++;
							@$sin_asignar++;
							$conDramas[] = $fileAux;
						}
					}
					else{
						@$sin_asignar++;
						$conDramas[] = $fileAux;
					}
				}
				else{
					echo "dia no existe";
					arreglo($campos[20]);
					exit;
				}
			}
			else{
				//si no es precencial lo dejamos a la segunda vuelta
				$conDramas[] = $fileAux;
				@$sin_asignar++;
			}
		}
		// arreglo($ss);
		// exit;
		
		//$table.= "</table>";
		
		/*REASIGNACION DE CASOS SIN CUPOS EN SU SEDE*/
		//ASIGNAR ALUMNOS A UNIVERSIDAD/SEDE DE SU COMUNA

		$cont = 0;
		$sin_asignar = 0;
		//$bien = 0;
		
		//$tableEnComuna = "<table border='1'>";
	
		$path = app_path('Http/Controllers/')."IIE/datos_txt/asignacion/";
		$file = file($path."comuna_rinde.txt");
		foreach($file as $fileAux){
			$fileAux = trim($fileAux);
			$campo = explode("\t", trim($fileAux));
			$cRinde[multibyte_trim(mb_strtolower($campo[0]))] = multibyte_trim(mb_strtolower($campo[1]));
		}		
		
		foreach($laboratorioPorDias as $_dia=>$_universidades){
			foreach($_universidades as $_universidad=>$_campuss){
				foreach($_campuss as $_campus =>$_laboratorios){
					foreach($_laboratorios as $dt){
						$laboratorioPorDiasPorComuna[$_dia][mb_strtolower($dt[$index_comuna])][] = $dt;	
					}
				}
			}	
		}
		
		//liberamos memoria y trabajamos con el nuevo arreglo por cuidad
		unset($laboratorioPorDias);
		
		$laboratorioPorDias = $laboratorioPorDiasPorComuna;
		
		$conDramasDeCiudad = array();
		
		foreach($conDramas as $fileAux){
			
			$fileAux->dia_de_aplicacion = 1;//para la segunda vuelta
			
			
			$cont++;
			$universidad = multibyte_trim($fileAux->nombre_institucion); // Pontificia Universidad Católica de Chile
			$campus = multibyte_trim($fileAux->nombre_sede); // Campus San Joaquín
			$comuna = ($fileAux->modalidad_estudio==52)?multibyte_trim(mb_strtolower($fileAux->nombre_comuna)):multibyte_trim(mb_strtolower($fileAux->nombre_comuna_evaluado)); // Santiago			
			$comuna = $cRinde[$comuna];
			
			//CHEKEO. VERIFICAR QUE LA COMUNA DEL EXCEL ENVIADO EFECTIVAMENTE TENGA LABORATORIOS EN LA PLANILLA DE INFRAESTRUCTURA
			// if(!in_array($comuna, $comunasConLaboratorio)){
				// echo $comuna."<br/>";
				// exit;
			// }

			$dia = "Día ".$fileAux->dia_de_aplicacion;
			if(array_key_exists($comuna, $laboratorioPorDias[$dia])){

					
				foreach($laboratorioPorDias[$dia][$comuna] as $index=>$laboratorios){
					$totalDisponibles = $laboratorios['disponible'];
					if($totalDisponibles>0){
						$laboratorioPorDias[$dia][$comuna][$index]['disponible']--;
						$fileAux->laboratorio = $laboratorios;
						break;
					}
					else{
						//ya no hay cupos en laboratorio. lo quitamos de los disponibles
						unset($laboratorioPorDias[$dia][$comuna][$index]);
						if(count($laboratorioPorDias[$dia][$comuna])==0){
							unset($laboratorioPorDias[$dia][$comuna]);
						}
						if(count($laboratorioPorDias[$dia])==0){
							unset($laboratorioPorDias[$dia]);
						}	
					}
				}
				
				if(isset($fileAux->laboratorio)){
					$region = Region::where('numero_region',$fileAux->laboratorio[$index_region])->first();
					if($fileAux->modalidad_estudio==52){$modalidad = 'Presencial';}
					elseif($fileAux->modalidad_estudio==51){$modalidad = 'No Presencial';}
					elseif($fileAux->modalidad_estudio==53){$modalidad = 'Semi Presencial';}
					$table.=  "<tr>
									<td>".$dia."</td>
									<td>".$universidad."</td>
									<td>".$campus."</td>
									<td>".$fileAux->numero_region_sede."</td>
									<td>".$fileAux->nombre_region_sede."</td>
									<td>".$fileAux->nombre_comuna."</td>
									<td>".$fileAux->rut."</td>
									<td>".$fileAux->nombre_comuna_evaluado."</td>
									<td>".$modalidad."</td>
									<td>".$fileAux->carrera."</td>
									<td>".$fileAux->laboratorio[0]."</td>
									<td>".$fileAux->laboratorio[$index_universidad]."</td>
									<td>".$fileAux->laboratorio[$index_region]."</td>
									<td>".$region->nombre_region."</td>									
									<td>".$fileAux->laboratorio[$index_comuna]."</td>
									<td>".$fileAux->laboratorio[$index_sede]."</td>
									<td>".$fileAux->laboratorio[$index_nombrelab]."</td>

								</tr>";	

					@$bien++;
				}
				else{
					//"alumno quedó sin cupo en laboratorio comuna<br/>";
					@$sin_asignar++;
					@$conDramasDeCiudad[] = $fileAux;
				}
			}
			else{
				//echo "no quedan laboratorios para el día en que le toca dar la prueba<br/>";
				@$sin_asignar++;
				@$conDramasDeCiudad[] = $fileAux;
			}		
		}
		//$table.= "</table>";
		//echo $table;
		//exit;		

		/*REASIGNACION DE CASOS SIN CUPOS EN SU COMUNA*/
		//ASIGNAR ALUMNOS A UNIVERSIDAD/SEDE DE SU REGION	
		
		$conDramas = $conDramasDeCiudad;
		$conDramasDeCiudad = array();
		
		
		foreach($laboratorioPorDias as $_dia=>$_comunas){
			foreach($_comunas as $_laboratorios){
				//foreach($_campuss as $_campus =>$_laboratorios){
					foreach($_laboratorios as $dt){
						$laboratorioPorDiasPorRegion[$_dia][mb_strtolower($dt[$index_region])][] = $dt;	
					}
				//}
			}	
		}
		//arreglo($laboratorioPorDiasPorRegion["Día 1"][13]);
		unset($laboratorioPorDias);
		$laboratorioPorDias = $laboratorioPorDiasPorRegion;
		
		//$table = "<table border='1'>";
		foreach($conDramas as $fileAux){
			
			$fileAux->dia_de_aplicacion = 1;//para la segunda vuelta
			
			$cont++;
			$universidad = multibyte_trim($fileAux->nombre_institucion); // Pontificia Universidad Católica de Chile
			$campus = multibyte_trim($fileAux->nombre_sede); // Campus San Joaquín
			$region_reside = ($fileAux->modalidad_estudio==52)?$fileAux->region_estudia:$fileAux->region_reside;

			$dia = "Día ".$fileAux->dia_de_aplicacion;
			if(array_key_exists($region_reside, $laboratorioPorDias[$dia])){

					
				foreach($laboratorioPorDias[$dia][$region_reside] as $index=>$laboratorios){
					$totalDisponibles = $laboratorios['disponible'];
					if($totalDisponibles>0){
						$laboratorioPorDias[$dia][$region_reside][$index]['disponible']--;
						$fileAux->laboratorio = $laboratorios;
						break;
					}
					else{
						//ya no hay cupos en laboratorio. lo quitamos de los disponibles
						unset($laboratorioPorDias[$dia][$region_reside][$index]);
						if(count($laboratorioPorDias[$dia][$region_reside])==0){
							unset($laboratorioPorDias[$dia][$region_reside]);
						}
						if(count($laboratorioPorDias[$dia])==0){
							unset($laboratorioPorDias[$dia]);
						}	
					}
				}
				
				if(isset($fileAux->laboratorio)){
					//arreglo($fileAux);
					//arreglo($laboratorioPorDias[$dia][$region_reside]);exit;
					$region = Region::where('numero_region',$fileAux->laboratorio[$index_region])->first();
					if($fileAux->modalidad_estudio==52){$modalidad = 'Presencial';}
					elseif($fileAux->modalidad_estudio==51){$modalidad = 'No Presencial';}
					elseif($fileAux->modalidad_estudio==53){$modalidad = 'Semi Presencial';}
					$table.=  "<tr>
									<td>".$dia."</td>
									<td>".$universidad."</td>
									<td>".$campus."</td>
									<td>".$fileAux->numero_region_sede."</td>
									<td>".$fileAux->nombre_region_sede."</td>
									<td>".$fileAux->nombre_comuna."</td>
									<td>".$fileAux->rut."</td>
									<td>".$fileAux->nombre_comuna_evaluado."</td>
									<td>".$modalidad."</td>
									<td>".$fileAux->carrera."</td>
									<td>".$fileAux->laboratorio[0]."</td>
									<td>".$fileAux->laboratorio[$index_universidad]."</td>
									<td>".$fileAux->laboratorio[$index_region]."</td>
									<td>".$region->nombre_region."</td>									
									<td>".$fileAux->laboratorio[$index_comuna]."</td>
									<td>".$fileAux->laboratorio[$index_sede]."</td>
									<td>".$fileAux->laboratorio[$index_nombrelab]."</td>

								</tr>";	

					@$bien++;
				}
				else{
					
					@$sin_asignar++;
					@$conDramasDeCiudad[] = $fileAux;
				}
			}
			else{
				//echo "no quedan laboratorios para el día en que le toca dar la prueba<br/>";
				@$sin_asignar++;
				@$conDramasDeCiudad[] = $fileAux;
			}		
		}
		if($doc==1){
			$file = "asignacionAlumnos-".date("Y-m-d_H_i_s").".xls";			
			
			header("Content-type: application/vnd.ms-excel;");
			header("Content-Disposition: attachment; filename=".$file);
			header("Pragma: no-cache");
			header("Expires: 0");
			echo utf8_decode($table);	
		}
		elseif($doc == 2){
			$this->conDramaDeCiudad($conDramasDeCiudad, $cRinde);		
		}
		elseif($doc == 3){
			$this->estadoLaboratorios($laboratorioPorDias);
		}
	}	

	
	
    public function ingresaAsignaciones(Request $request)
    {
	
		
		//truncate table aplicaciones
		//truncate table evaluadosaplicaciones
		//truncate table aplicaciones_has_tiposcontingencia
		
		/**Laboratorios*/
		$path = app_path('Http/Controllers/')."IIE/datos_txt/asignacion/";
		$file = file($path."asignaLaboratorio.txt");
		$carrera = Carrera::get();
		$dependencias = Dependencias::get();
		
		foreach($carrera as $carreras){
			$carreraDia[$carreras->id_carrera] = $carreras->dia_de_aplicacion_complementaria;
		}

		foreach($dependencias as $dependencia){
			$dependenciaId[$dependencia->lab_cod_iie] = $dependencia->id;
		}
		
		
		$fechas[1] = '2019-01-23';
		//$fechas[2] = '2018-12-19';
		//$fechas[3] = '2018-12-20';
		//$fechas[4] = '2018-12-21';
		$hora = '09:30';
		$lab = array();
		
		$estudianteListado = EstudianteListado::where("borrado", false)->where("complementaria", true)->get();
		foreach($estudianteListado as $estudianteListadoAux){
			$estRut[$estudianteListadoAux->rut] = $estudianteListadoAux->id_carrera;
			$estId[$estudianteListadoAux->rut] = $estudianteListadoAux->id;
		}
		
		foreach($file as $fileAux){
			$fileAux = trim($fileAux);
			$campos = explode("\t", trim($fileAux));

			$diaApp = $carreraDia[$estRut[trim($campos[0])]];
			
			if(!@in_array($fechas[$diaApp], $lab[$dependenciaId[trim($campos[1])]])){
				if(array_key_exists(trim($campos[1]),$dependenciaId)){
					$lab[$dependenciaId[trim($campos[1])]][] =  $fechas[$diaApp];		
				}
				else{
				     echo "no existe cod_lab->".trim($campos[1]);	
					 exit;
				}
			}
			$labAlu[$dependenciaId[trim($campos[1])]][$fechas[$diaApp]][] =  trim($campos[0]);		
		}	
		
		
		DB::beginTransaction();
		try{
			foreach($lab as $idLab=>$labAux){
				foreach($labAux as $_labAux){
					$aplicaciones = new Aplicaciones();
					$aplicaciones->fecha_agendada = $_labAux;
					$aplicaciones->hora_agendada = $hora;
					$aplicaciones->dependencia_id = $idLab;
					$aplicaciones->tiposaplicacion_id = 62;
					$aplicaciones->estadosaplicacion_id = 64;
					$aplicaciones->save();
					$idsApp[$idLab][$_labAux] = $aplicaciones->id;
				}
			}
			foreach($labAlu as $idLab=>$labAluAux){
				foreach($labAluAux as $fecha=>$alumnos){
					foreach($alumnos as $run){
						$appId = $idsApp[$idLab][$fecha];

						if(!in_array($run, $estId)){
							$evaluadosAplicaciones = new EvaluadosAplicaciones();						
							$evaluadosAplicaciones->idevaluado = $estId[$run];
							$evaluadosAplicaciones->idaplicacion = $appId;	
							$evaluadosAplicaciones->estadosrespuesta_id = 72;
							$evaluadosAplicaciones->estadosasistencia_id = 32; 
							$evaluadosAplicaciones->save();
						}
						else{
							echo $run."<br/>";
						}
						
					}
				}
			}
		}
		catch(\Exception $ex){

			DB::rollback();
			dd($ex);
			//echo $ex->getMessage();
			return false;
		}
		DB::commit();			
	}

    public function reasignacion(Request $request)
    {
		//https://www.diagnosticafid.cl/public/asignaciones/reasignacion
	
		/**Laboratorios*/
		//$path = app_path('Http/Controllers/')."IIE/datos_txt/asignacion/";
		//$file = file($path."reasignaMartes22.txt");
		$datos = "
16831985-1	279
		";
		$file = explode("\n", trim($datos));
		//despues de eliminar reasignamos
		$carrera = Carrera::get();
		$dependencias = Dependencias::get();
		
		foreach($carrera as $carreras){
			$carreraDia[$carreras->id_carrera] = $carreras->dia_de_aplicacion_complementaria;
		}

		foreach($dependencias as $dependencia){
			$dependenciaId[$dependencia->lab_cod_iie] = $dependencia->id;
		}
		
		$tipoAplicacion = 62;
		$fechas[1] = '2019-01-23';
		//$fechas[2] = '2018-12-19';
		//$fechas[3] = '2018-12-20';
		//$fechas[4] = '2018-12-21';
		$hora = '09:30';
		$lab = array();
		
		$estudianteListado = EstudianteListado::where("borrado", false)->get();
		foreach($estudianteListado as $estudianteListadoAux){
			$estRut[$estudianteListadoAux->rut] = $estudianteListadoAux->id_carrera;
			$estId[$estudianteListadoAux->rut] = $estudianteListadoAux->id;
		}
		
		foreach($file as $fileAux){
			$fileAux = trim($fileAux);
			$campos = explode("\t", trim($fileAux));
			$diaApp = $carreraDia[$estRut[trim($campos[0])]];
			
			if(!@in_array($fechas[$diaApp], $lab[$dependenciaId[trim($campos[1])]])){
				if(array_key_exists(trim($campos[1]),$dependenciaId)){
					$lab[$dependenciaId[trim($campos[1])]][] =  $fechas[$diaApp];		
				}
				else{
				     echo "no existe cod_lab->".trim($campos[1]);	
					 exit;
				}
			}
			$labAlu[$dependenciaId[trim($campos[1])]][$fechas[$diaApp]][] =  trim($campos[0]);		
		}	
		
		DB::beginTransaction();
		try{
			
			//ELIMINACION de la asginación
			foreach($file as $fileAux){
				$fileAux = trim($fileAux);
				$campos = explode("\t", trim($fileAux));
				$aEliminar = EstudianteListado::where("rut", trim(mb_strtoupper($campos[0])))->first();
				if(isset($aEliminar->id)){
					echo "delete from evaluadosaplicaciones where idevaluado = ".$aEliminar->id." ;<br/>";
					DB::select("delete from evaluadosaplicaciones where idevaluado = ".$aEliminar->id." ;");
				}	
				else{
					//echo "no existe alumno->".trim($campos[0]);
					//exit;
				}
			}
			// exit;
			//FIN ELIMINACION
		
			foreach($lab as $idLab=>$labAux){
				foreach($labAux as $_labAux){
					$_app = Aplicaciones::where("dependencia_id", $idLab)->where("fecha_agendada",$_labAux)->where("hora_agendada",$hora)->first();
					if(!isset($_app->id)){
						$aplicaciones = new Aplicaciones();
						$aplicaciones->fecha_agendada = $_labAux;
						$aplicaciones->hora_agendada = $hora;
						$aplicaciones->dependencia_id = $idLab;
						$aplicaciones->tiposaplicacion_id = $tipoAplicacion;
						$aplicaciones->estadosaplicacion_id = 64;
						$aplicaciones->save();
						$idsApp[$idLab][$_labAux] = $aplicaciones->id;

					}
					else{
						$idsApp[$idLab][$_labAux] = $_app->id;
					}
				}
			}
			$cont = 1;
			foreach($labAlu as $idLab=>$labAluAux){
				foreach($labAluAux as $fecha=>$alumnos){
					foreach($alumnos as $run){
						$appId = $idsApp[$idLab][$fecha];

						if(!in_array($run, $estId)){
							$evaluadosAplicaciones = new EvaluadosAplicaciones();						
							$evaluadosAplicaciones->idevaluado = $estId[$run];
							$evaluadosAplicaciones->idaplicacion = $appId;	
							$evaluadosAplicaciones->estadosrespuesta_id = 72;
							$evaluadosAplicaciones->estadosasistencia_id = 32; 
							echo $cont."->".$run."---".$idLab."<br/>";
							$cont++;
							
							$evaluadosAplicaciones->save();
						}
						else{
							//echo $run."<br/>";
						}
					}
				}
			}
		}
		catch(\Exception $ex){

			DB::rollback();
			dd($ex);
			//echo $ex->getMessage();
			return false;
		}
		DB::commit();		
		echo "total ->".$cont."<br/>";
		
		echo "
				SELECT 
				aplicaciones.fecha_agendada, evaluados.rut ,
				institucionestudios.nombre_institucion as institucion_estudia,
				regiones.numero_region as region_sede,	
				regiones.nombre_region as nombre_sede ,
				sedeinstitucion.nombre_sede,	
				cc.nombre_comuna as comuna_campus, 
				cr.nombre_comuna as comuna_reside, 
				evaluados.modalidad_estudio,
				carrera,
				dependencias.lab_cod_iie as id_iie,
				centro_institucion.nombre_institucion as institucion_asignada, 
				reg_instit_asignada.numero_region as region_sede_asignada,	
				reg_instit_asignada.nombre_region as nombre_region_sede_asignada,
				ca.nombre_comuna as comuna_asignada, centrosaplicacion.nombre_sede as sede_asignada, centrosaplicacion.direccion as direccion_sede, dependencias.facultad_sector as facultad, dependencias.nombre_dependencia as laboratorio
				FROM evaluadosaplicaciones, evaluados, aplicaciones, dependencias, comunas ca, comunas cc, comunas cr, centrosaplicacion, centro_institucion, regiones, regiones as reg_instit_asignada,
				institucionestudios,sedeinstitucion,carreras
				WHERE evaluadosaplicaciones.idevaluado  = evaluados.id
				AND carreras.id_carrera = evaluados.id_carrera
				AND evaluados.sedeinstitucion_id = sedeinstitucion.id
				AND institucionestudios.id	= sedeinstitucion.institucionestudios_id
				AND evaluadosaplicaciones.idaplicacion =  aplicaciones.id
				AND evaluados.complementaria = true
				AND dependencia_id = dependencias.id
				AND ca.id = centrosaplicacion.id_comuna
				AND cc.id = sedeinstitucion.comuna_id
				AND cr.id = evaluados.id_comuna
				AND cc.region_id = regiones.id	
				AND ca.region_id = reg_instit_asignada.id
				AND centrosaplicacion.id = dependencias.centrosaplicacion_id
				AND centro_institucion.id_centro_institucion = centrosaplicacion.centro_institucion_id
				AND tiposaplicacion_id  = 62
				ORDER BY aplicaciones.fecha_agendada, lab_cod_iie		
		";
	}


	
	function estadoLaboratorios($laboratorioPorDias){
		$index_region = 1;
		$index_universidad = 2;
		$index_comuna = 3;
		$index_sede = 5;
		//$index_facultad = 7;
		$index_nombrelab = 6;
		$index_dia1 = 10;
		$index_dia2 = 11;
		$index_dia3 = 12;
		$index_dia4 = 13;
		$index_confirmado = 7;
		
		$table = "<table border='1'>
					<tr>
						<td>Día</td>
						<td>Cod</td>
						<td>Universidad</td>
						<td>Comuna</td>
						<td>Sede</td>
						<td>Laboratorio</td>
						<td>Disponiblidad</td>
					</tr>
			";
		
		foreach($laboratorioPorDias as $dia=>$_comunas) {
			foreach($_comunas as $comuna=>$_laboratorios){
				foreach($_laboratorios as $_laboratoriosAux){
					if($_laboratoriosAux["disponible"]!=0){
					$table.=  "<tr>
									<td>".$dia."</td>
									<td>".$_laboratoriosAux[0]."</td>
									<td>".$_laboratoriosAux[$index_universidad]."</td>
									<td>".$_laboratoriosAux[$index_comuna]."</td>
									<td>".$_laboratoriosAux[$index_sede]."</td>
									
									<td>".$_laboratoriosAux[$index_nombrelab]."</td>
									<td>".$_laboratoriosAux["disponible"]."</td>
								</tr>";						
						
					}
					
				}
			}
		}
		$table.= "</table>";

		$file = "saldoLabs-".date("Y-m-d_H_i_s").".xls";			
		
		header("Content-type: application/vnd.ms-excel;charset=UTF-8");
		header("Content-Disposition: attachment; filename=".$file);
		header("Pragma: no-cache");
		header("Expires: 0");
		
		echo $table;
		exit;		
		
	}
	
	function conDramaDeCiudad($conDramasDeCiudad, $cRinde){
		$_modalidad[53] = 'semipresencial';	
		$_modalidad[52] = 'presencial';
		$_modalidad[51] = 'no presencial';
	
		$table = "<table border='1'>
					<tr>
						<td>Día</td>
						<td>Rut</td>
						<td>Universidad</td>
						<td>Campus</td>
						<td>Comuna Sede</td>
						<td>Comuna Residencia</td>
						<td>Modalidad</td>
						<td>Comuna Asignada</td>
					</tr>";
	
	
		foreach($conDramasDeCiudad as $campos){			
				$table.=  "<tr>
								<td>Día ".$campos->dia_de_aplicacion."</td>
								<td>".$campos->rut."</td>
								<td>".$campos->nombre_institucion."</td>
								<td>".$campos->nombre_sede."</td>
								
								<td>".$campos->nombre_comuna."</td>
								<td>".$campos->nombre_comuna_evaluado."</td>
								<td>".$_modalidad[$campos->modalidad_estudio]."</td>
								
							</tr>";	

		}	
		$table.= "</table>";
		$file = "sinCupo-".date("Y-m-d_H_i_s").".xls";			
		header("Content-type: application/vnd.ms-excel;");
		header("Content-Disposition: attachment; filename=".$file);
		header("Pragma: no-cache");
		header("Expires: 0");
		
		echo $table;
		exit;
		
	}
	
	// function multibyte_trim($str)
	// {
		// if (!function_exists("mb_trim") || !extension_loaded("mbstring")) {
			// return preg_replace("/(^\s+)|(\s+$)/u", "", $str);
		// } else {
			// return mb_trim($str);
		// }
	// }		
}

