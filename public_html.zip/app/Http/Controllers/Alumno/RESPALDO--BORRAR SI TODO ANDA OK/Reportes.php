<?php
namespace App\Http\Controllers\IIE;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\LimeEstandar;
use App\Models\Carrera;
use App\Models\Aplicaciones;
use App\Models\Prueba;
use App\Models\EvaluadosAplicaciones;
use App\Models\EstudianteListado;
use App\Models\Reporte\Asistencia;
use App\Models\LimePregunta;
use App\Models\LimeRespuesta;
use App\Models\CentroInstitucion;
use App\Models\CentroAplicacion;
use App\Models\Dependencias;
use App\Models\LimePorcentajeLogro;
use App\Models\LimePorcentajeLogroEstandar;

use App\Models\LimeReporteNacionalGlobal;
use App\Models\LimeReporteInstitucionalGlobal;
use App\Models\LimeReporteInstitucional;
use App\Models\LimeReporteInstitucionalEstandar;
use App\Models\LimeReporteInstitucionalTema;
use App\Models\LimeResultadoInstitucion;
use App\Models\LimeTendencia;
use MathPHP\Statistics\Significance;
use MathPHP\Statistics\Correlation;

use Illuminate\Support\Facades\DB;

class Reportes extends Controller
{
	 
	public function __construct()
    {
		$this->fields = array();	
    }	

	// public function importarExcelEstandar2(Request $request)
    // {

		// //IMPORTAR EXCEL
		// $path = app_path('Http/Controllers/')."IIE/datos_txt/importar_excel/";
		// $file = file($path."estandares_media_7.txt");
		// $c = 1;
		// $tablaNueva = 'lime_estandar';
		// $colsExcluir[] = 'updated_at';
		// $colsExcluir[] = 'created_at';
		
		// //DB::select("truncate table ".$tablaNueva."  ");		
		
		// $colsName = DB::select("SELECT * FROM information_schema.columns WHERE table_schema = 'public' and table_name ='".$tablaNueva."'  ");		
		// foreach($colsName as $colsNameAux){
			// if(!in_array($colsNameAux->column_name, $colsExcluir)){
				// $cols[] = trim($colsNameAux->column_name);	
			// }
		// }

		// foreach($file as $fileAux){
			// $campos = explode("\t", multibyte_trim($fileAux));
			// $nevosDatos = new LimeEstandar;
			// $nevosDatos->nro_tema_eliminar = $campos[0];
			// $nevosDatos->nro_estandar = $campos[1];
			// $nevosDatos->id_prueba = 3; //$campos[2];
			// $nevosDatos->estandar = $campos[2];
			 // /* En el modelo debe estar desactivada la opción de timestamps para evitar errores */ 
			 // /* relacionados al updated_at y created_at (public $timestamps = false;)  */
			// $nevosDatos->save();
		// }
	// }

	public function calculaCuadrantesNacional(){
		
		$path = app_path('Http/Controllers/')."IIE/datos_txt/";
		$file = file($path."ruts.txt");
		echo "<table border = 1>";
		foreach($file as $fileAux){
			$select = DB::select("SELECT cod_iie  , rut, respuesta
			FROM  lime_pregunta, lime_respuesta, evaluados
			WHERE rut = '".trim($fileAux)."'
			AND lime_pregunta.id_lime_pregunta = lime_respuesta.id_lime_pregunta
			AND evaluados.id_excel_iie = cod_iie
			AND tipo_pregunta!='alternativa'");
			echo "<tr><td>".$select[0]->rut."</td><td>".nl2br($select[0]->respuesta)."</td></tr>";
		}
		echo "</table>";
		
		//https://www.diagnosticafid.cl/public/calcula-cuadrantes-nacional
		exit;
		
		
		$promedioCarrera = DB::select("
		   SELECT carreras.id_carrera, lime_reporte_institucional.tipo_prueba, 
                   avg(lime_reporte_institucional.promedio) AS avg 
				   FROM lime_reporte_institucional
				   JOIN carreras ON lime_reporte_institucional.id_carrera = carreras.id_carrera
				   JOIN institucionestudios ON lime_reporte_institucional.id_institucion = institucionestudios.id
				   GROUP BY carreras.id_carrera, lime_reporte_institucional.tipo_prueba
				   ORDER BY carreras.id_carrera		
		"); 
		
		foreach($promedioCarrera as $promedioCarreraAux){
			$x[$promedioCarreraAux->id_carrera][strtolower($promedioCarreraAux->tipo_prueba)] = $promedioCarreraAux->avg;
		}
		
		$limeTendencia = DB::select("
			SELECT institucionestudios.id as id_institucion, carreras.id_carrera, lime_reporte_institucional.tipo_prueba, 
				   avg(lime_reporte_institucional.promedio) AS avg 
				   FROM lime_reporte_institucional
				   JOIN carreras ON lime_reporte_institucional.id_carrera = carreras.id_carrera
				   JOIN institucionestudios ON lime_reporte_institucional.id_institucion = institucionestudios.id
				   GROUP BY institucionestudios.id, carreras.id_carrera, lime_reporte_institucional.tipo_prueba
				   ORDER BY institucionestudios.id, carreras.id_carrera		
		");
		foreach($limeTendencia as $limeTendenciaAux){
			$porAlumno[$limeTendenciaAux->id_institucion][$limeTendenciaAux->id_carrera][strtolower($limeTendenciaAux->tipo_prueba)] = $limeTendenciaAux->avg;
		}

		foreach($porAlumno as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$pruebas){
				if(count($pruebas)==2){
					if(($pruebas["pcdd"]>=$x[$id_carrera]["pcdd"])&&($pruebas["pcpg"]<$x[$id_carrera]["pcpg"])){
						@$cuadrante[1][$id_institucion][$id_carrera]++;
					}
					elseif(($pruebas["pcpg"]>=$x[$id_carrera]["pcpg"])&&($pruebas["pcdd"]>=$x[$id_carrera]["pcdd"])){
						@$cuadrante[2][$id_institucion][$id_carrera]++;	
					}
					elseif(($pruebas["pcpg"]>=$x[$id_carrera]["pcpg"])&&($pruebas["pcdd"]<$x[$id_carrera]["pcdd"])){
						@$cuadrante[3][$id_institucion][$id_carrera]++;	
					}
					elseif(($pruebas["pcpg"]<$x[$id_carrera]["pcpg"])&&($pruebas["pcdd"]<$x[$id_carrera]["pcdd"])){
						@$cuadrante[4][$id_institucion][$id_carrera]++;	
					}
					else{
						echo "s";	
					}
				}
			}
		}
		
		DB::select("update lime_reporte_institucional_global set cuadrante1nac = 0, cuadrante2nac = 0, cuadrante3nac = 0, cuadrante4nac = 0");
		foreach($cuadrante as $nro_cuadrante=>$universidades){
			foreach($universidades as $id_institucion=>$carreras){
				foreach($carreras as $id_carrera=>$total){
					$limeReporteInstitucionalGlobal = LimeReporteInstitucionalGlobal::where("id_institucion", $id_institucion)->where("id_carrera", $id_carrera)->first();				
					if(!isset($limeReporteInstitucionalGlobal->id_reporte_institucional_global)){
						$limeReporteInstitucionalGlobal = new LimeReporteInstitucionalGlobal;
						$limeReporteInstitucionalGlobal->id_institucion = $id_institucion; 
						$limeReporteInstitucionalGlobal->id_carrera = $id_carrera; 
					}
					if($nro_cuadrante==1){
						$limeReporteInstitucionalGlobal->cuadrante1nac = $total; 	
					}
					elseif($nro_cuadrante==2){
						$limeReporteInstitucionalGlobal->cuadrante2nac = $total; 	
					}
					elseif($nro_cuadrante==3){
						$limeReporteInstitucionalGlobal->cuadrante3nac = $total; 	
					}
					elseif($nro_cuadrante==4){
						$limeReporteInstitucionalGlobal->cuadrante4nac = $total; 	
					}
					$limeReporteInstitucionalGlobal->save();
				}
			}	
		}		
	}	
	
	public function calculaCuadrantes(){
		
		//https://www.diagnosticafid.cl/public/calcula-cuadrantes
		//exit;
		
		
		$promedioCarrera = DB::select("
		   SELECT carreras.id_carrera, lime_reporte_institucional.tipo_prueba, 
                   avg(lime_reporte_institucional.promedio) AS avg 
				   FROM lime_reporte_institucional
				   JOIN carreras ON lime_reporte_institucional.id_carrera = carreras.id_carrera
				   JOIN institucionestudios ON lime_reporte_institucional.id_institucion = institucionestudios.id
				   GROUP BY carreras.id_carrera, lime_reporte_institucional.tipo_prueba
				   ORDER BY carreras.id_carrera		
		");   
		foreach($promedioCarrera as $promedioCarreraAux){
			$x[$promedioCarreraAux->id_carrera][strtolower($promedioCarreraAux->tipo_prueba)] = $promedioCarreraAux->avg;
		}
		
		
		$limeTendencia = DB::select("select * from lime_tendencia where anio = 2018 order by rut");
		foreach($limeTendencia as $limeTendenciaAux){
			$porAlumno[$limeTendenciaAux->id_institucion][$limeTendenciaAux->id_carrera][$limeTendenciaAux->rut][$limeTendenciaAux->tipo_prueba] = $limeTendenciaAux->puntaje;
		}


		foreach($porAlumno as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$alumnos){
				foreach($alumnos as $rut=>$pruebas){
					if(count($pruebas)==2){
						if(($pruebas["pcdd"]>=$x[$id_carrera]["pcdd"])&&($pruebas["pcpg"]<$x[$id_carrera]["pcpg"])){
							@$cuadrante[1][$id_institucion][$id_carrera]++;
						}
						elseif(($pruebas["pcpg"]>=$x[$id_carrera]["pcpg"])&&($pruebas["pcdd"]>=$x[$id_carrera]["pcdd"])){
							@$cuadrante[2][$id_institucion][$id_carrera]++;	
						}
						elseif(($pruebas["pcpg"]>=$x[$id_carrera]["pcpg"])&&($pruebas["pcdd"]<$x[$id_carrera]["pcdd"])){
							@$cuadrante[3][$id_institucion][$id_carrera]++;	
						}
						elseif(($pruebas["pcpg"]<$x[$id_carrera]["pcpg"])&&($pruebas["pcdd"]<$x[$id_carrera]["pcdd"])){
							@$cuadrante[4][$id_institucion][$id_carrera]++;	
						}
						else{
							echo "s";	
						}
					}
				}	
			}
		}
		
		DB::select("update lime_reporte_institucional_global set cuadrante1 = 0, cuadrante2 = 0, cuadrante3 = 0, cuadrante4 = 0");
		foreach($cuadrante as $nro_cuadrante=>$universidades){
			foreach($universidades as $id_institucion=>$carreras){
				foreach($carreras as $id_carrera=>$total){
					$limeReporteInstitucionalGlobal = LimeReporteInstitucionalGlobal::where("id_institucion", $id_institucion)->where("id_carrera", $id_carrera)->first();				
					if(!isset($limeReporteInstitucionalGlobal->id_reporte_institucional_global)){
						$limeReporteInstitucionalGlobal = new LimeReporteInstitucionalGlobal;
						$limeReporteInstitucionalGlobal->id_institucion = $id_institucion; 
						$limeReporteInstitucionalGlobal->id_carrera = $id_carrera; 
					}
					if($nro_cuadrante==1){
						$limeReporteInstitucionalGlobal->cuadrante1 = $total; 	
					}
					elseif($nro_cuadrante==2){
						$limeReporteInstitucionalGlobal->cuadrante2 = $total; 	
					}
					elseif($nro_cuadrante==3){
						$limeReporteInstitucionalGlobal->cuadrante3 = $total; 	
					}
					elseif($nro_cuadrante==4){
						$limeReporteInstitucionalGlobal->cuadrante4 = $total; 	
					}
					$limeReporteInstitucionalGlobal->save();
				}
			}	
		}		
	}	
	
	public function calculoCorrelacion(){
		
		//https://www.diagnosticafid.cl/public/calculo-correlacion
		
		exit;
		
		$limeTendencia = DB::select("select * from lime_tendencia where anio = 2018 order by rut");
		foreach($limeTendencia as $limeTendenciaAux){
			if($limeTendenciaAux->tipo_prueba=='pcdd'){
				$aCompararPCDD[$limeTendenciaAux->id_institucion][$limeTendenciaAux->id_carrera][] = $limeTendenciaAux->puntaje;		
			}
			else{
				$aCompararPCPG[$limeTendenciaAux->id_institucion][$limeTendenciaAux->id_carrera][] = $limeTendenciaAux->puntaje;		
			}
		}

		foreach($aCompararPCPG as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$datos){
				//foreach($pruebas as $tipo_prueba=>$datos){
					
					//if(array_key_exists($id_institucion,$aCompararPCDD)){
					//	if(array_key_exists($id_carrera,$aCompararPCDD[$id_institucion])){
							//if(array_key_exists($tipo_prueba,$aCompararPCDD[$id_institucion][$id_carrera])){
							if(isset($aCompararPCDD[$id_institucion][$id_carrera])){
								//if(($id_institucion==16)&&($id_carrera==10)){
									$x1 = $aCompararPCPG[$id_institucion][$id_carrera];
									//debería dar 0,6105
									$x2 = $aCompararPCDD[$id_institucion][$id_carrera];
									//foreach($x1 as $x1Aux){
									//	echo str_replace(".",",",$x1Aux)."<br>";
									//}									
									// echo $id_institucion."<br/>";
									// echo $id_carrera."<br/>";
									// echo $tipo_prueba."<br/>";
									
									 //arreglo($x1);
									 //arreglo($x2);
									// exit;
									if((count($x1)>=10)&&(count($x2)>=10)){
										// arreglo(Significance::tTest($x1, $x2));
										// arreglo(php_correlation($x1, $x2));
										// arreglo(Correlation::describe($x1, $x2));
										// arreglo(Correlation::r($x1, $x2));
										// arreglo(pearson_correlation($x1, $x2));
										// exit;
										$tCorrelation[$id_institucion][$id_carrera] = Correlation::r($x1, $x2);	
										//$tCorrelation[$id_institucion][$id_carrera] = pearson_correlation($x1, $x2);
									}									
								//}

							}
							//else{
							//	echo $id_institucion."-".$id_carrera;	
							//}
					//	}
					//	else{
					//		//echo $id_institucion."-".$id_carrera."<br/>";	
					//	}
					//}
					//else{
						//echo $id_institucion."<br/>";		
					//}
					
					
				//}
			}
		}

		//arreglo($tCorrelation[16][11]);exit;
		DB::select("update lime_reporte_institucional_global set correlacion = null");
		foreach($tCorrelation as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$pruebas){
				$limeReporteInstitucionalGlobal = LimeReporteInstitucionalGlobal::where("id_institucion", $id_institucion)->where("id_carrera", $id_carrera)->first();				
				// if(!isset($limeReporteInstitucionalGlobal->id_reporte_institucional_global)){
					// $limeReporteInstitucionalGlobal = new LimeReporteInstitucionalGlobal;	
					// $limeReporteInstitucionalGlobal->id_institucion = $id_institucion; 
					// $limeReporteInstitucionalGlobal->id_carrera = $id_carrera; 
				// }
				$limeReporteInstitucionalGlobal->correlacion = $tCorrelation[$id_institucion][$id_carrera]; 
				$limeReporteInstitucionalGlobal->save();
				
				// $limeReporteInstitucional = LimeReporteInstitucional::where("id_institucion", $id_institucion)->where("id_carrera", $id_carrera)->get();				
				// foreach($limeReporteInstitucional as $limeReporteInstitucionalAux){
					// $limeReporteInstitucionalAux->id_reporte_institucional_global = $limeReporteInstitucionalGlobal->id_reporte_institucional_global;
					// $limeReporteInstitucionalAux->save();
				// }
			}	
		}		
	}
	
	public function calculoSignificanciaNacional(){
		
		//https://www.diagnosticafid.cl/public/calculo-significancia-nacional
		
		$limeTendencia = DB::select("SELECT * FROM public.lime_reporte_institucional;");
		
		foreach($limeTendencia as $limeTendenciaAux){
			if(($limeTendenciaAux->promedio2017!="")&&($limeTendenciaAux->promedio!="")){
				$aComparar2017[$limeTendenciaAux->id_carrera][$limeTendenciaAux->tipo_prueba][] = $limeTendenciaAux->promedio2017;		
				$aComparar2018[$limeTendenciaAux->id_carrera][$limeTendenciaAux->tipo_prueba][] = $limeTendenciaAux->promedio;		
			}
		}

		foreach($aComparar2018 as $id_carrera=>$pruebas){
			foreach($pruebas as $tipo_prueba=>$datos){
				if(array_key_exists($id_carrera,$aComparar2017)){
						$x1 = $aComparar2018[$id_carrera][$tipo_prueba];
						$x2 = $aComparar2017[$id_carrera][$tipo_prueba];
						if((count($x1)>=10)&&(count($x2)>=10)){
							$x1 = $aComparar2018[$id_carrera][$tipo_prueba];
							$x2 = $aComparar2017[$id_carrera][$tipo_prueba];
							$res = Significance::tTest($x1, $x2);
							$tTest[$id_carrera][$tipo_prueba] = Significance::tTest($x1, $x2);		
						}
						else{
						}
				}
				else{
				}
			}
		}
		
		DB::select("update lime_reporte_institucional set significancia	= -1");
		foreach($tTest as $id_carrera=>$pruebas){
			foreach($pruebas as $tipo_prueba=>$datos){
				$limeNacional = new LimeReporteNacionalGlobal;
				$limeNacional->id_carrera = $id_carrera; 
				$limeNacional->tipo_prueba = $tipo_prueba; 
				$limeNacional->significancia = $datos['p2']; 
				$limeNacional->save();
			}
		}	
	}
	
	public function calculoSignificancia(){
		//phpinfo();exit;
		//https://www.diagnosticafid.cl/public/calculo-significancia
		
		$limeTendencia = DB::select("select * from lime_tendencia  where anio in (2017,2018) order by id_institucion, id_carrera, tipo_prueba");
		
		//$limeTendencia = LimeTendencia::get();
		
		foreach($limeTendencia as $limeTendenciaAux){
			if($limeTendenciaAux->anio==2017){
				$aComparar2017[$limeTendenciaAux->id_institucion][$limeTendenciaAux->id_carrera][$limeTendenciaAux->tipo_prueba][] = $limeTendenciaAux->puntaje;		
			}
			else{
				$aComparar2018[$limeTendenciaAux->id_institucion][$limeTendenciaAux->id_carrera][$limeTendenciaAux->tipo_prueba][] = $limeTendenciaAux->puntaje;		
			}
		}

		foreach($aComparar2018 as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$pruebas){
				foreach($pruebas as $tipo_prueba=>$datos){
					
					if(array_key_exists($id_institucion,$aComparar2017)){
						if(array_key_exists($id_carrera,$aComparar2017[$id_institucion])){
								$x1 = $aComparar2018[$id_institucion][$id_carrera][$tipo_prueba];
								$x2 = $aComparar2017[$id_institucion][$id_carrera][$tipo_prueba];
								if((count($x1)>=10)&&(count($x2)>=10)){
									
									$x1 = $aComparar2018[$id_institucion][$id_carrera][$tipo_prueba];
									$x2 = $aComparar2017[$id_institucion][$id_carrera][$tipo_prueba];
									//stats_stat_paired_t($x1,$x2) ;
									//exit;
									//$res = Significance::tTest($x1, $x2);
									//if(trim($res["p2"]) == 'NAN'){
										//echo $id_institucion."--".$id_carrera."--".$tipo_prueba;
										$res = Significance::tTest($x1, $x2);
										//arreglo($res);
										//$res = Significance::tTest($x1, array_pop($x2));
										
										// foreach($x1 as $x1Aux){
											// echo $x1Aux."<br/>";
										// }

										// echo "----------------------------<br/><br/><br/><br/>";
										
										// foreach($x2 as $x2Aux){
											// echo $x2Aux."<br/>";
										// }
										//arreglo($res);
										//exit;
									//}
									$tTest[$id_institucion][$id_carrera][$tipo_prueba] = Significance::tTest($x1, $x2);		
								}
								else{
									$tTest[$id_institucion][$id_carrera][$tipo_prueba] = array("p2"=>-2);	
								}
						}
						else{
						}
					}
					else{
					}
				}
			}
		}
		
		//arreglo($tTest);exit;
		DB::select("update lime_reporte_institucional set significancia	= -1");
		foreach($tTest as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$pruebas){
				foreach($pruebas as $tipo_prueba=>$datos){
					$limeReporteInstitucional = LimeReporteInstitucional::where("id_institucion", $id_institucion)->where("id_carrera", $id_carrera)->where("tipo_prueba", strtoupper($tipo_prueba))->first();				
					$limeReporteInstitucional->significancia = $datos['p2']; 
					$limeReporteInstitucional->save();
				}
			}	
		}		
	}	
	
	public function calculaPuntajes2018(){
		
		//calcula los promedios, minima, maxima
		
		//https://www.diagnosticafid.cl/public/calcula-puntajes-2018
		
		$sql = "
			SELECT rut, id_institucion, id_carrera, tipo_prueba, puntaje , modalidad_estudio as extra_prosecucion	
			FROM lime_tendencia where anio = 2018
		";

		//organizamos la info
		$ptje = DB::select($sql);		
		

		foreach($ptje as $ptjeAux){
			$extraProsecucion = 'regular';
			if($ptjeAux->extra_prosecucion == 'prosecucion'){
				$extraProsecucion = 'prosecucion';	
			}
			
			//institucion/carrera/tipo_prueba/modalidad
			@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba][$extraProsecucion]["sum"]+= $ptjeAux->puntaje;
			@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba][$extraProsecucion]["ctd"]++;
			$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba][$extraProsecucion]["todos"][] = $ptjeAux->puntaje;

			//institucion/carrera/tipo_prueba
			@$resICT[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba]["sum"]+= $ptjeAux->puntaje;
			@$resICT[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba]["ctd"]++;
			$resICT[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba]["todos"][] = $ptjeAux->puntaje;
		}
		
		//calculamos
		foreach($res as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$tipo_pruebas){
				foreach($tipo_pruebas as $tipo_prueba=>$modEst){
					$resICT[$id_institucion][$id_carrera][$tipo_prueba]["promedio"] = $resICT[$id_institucion][$id_carrera][$tipo_prueba]["sum"]/$resICT[$id_institucion][$id_carrera][$tipo_prueba]["ctd"];
					$resICT[$id_institucion][$id_carrera][$tipo_prueba]["min"] =  min($resICT[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
					$resICT[$id_institucion][$id_carrera][$tipo_prueba]["max"] =  max($resICT[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
					$resICT[$id_institucion][$id_carrera][$tipo_prueba]["mediana"] =  get_percentile(50,$resICT[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
					$resICT[$id_institucion][$id_carrera][$tipo_prueba]["perce25"] =  get_percentile(25,$resICT[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
					$resICT[$id_institucion][$id_carrera][$tipo_prueba]["perce75"] =  get_percentile(75,$resICT[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);

					foreach($modEst as $mEst=>$datos){
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["promedio"] =  $res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["sum"]/$res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["ctd"];
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["min"] =  min($res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["max"] =  max($res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["mediana"] =  get_percentile(50,$res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["perce25"] =  get_percentile(25,$res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["perce75"] =  get_percentile(75,$res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
					}
				}	
			}
		}
		
		//arreglo($resOrg[20][2]["pcpg"]["regular"]);
		//exit;
		
		DB::select("update lime_resultado_institucion set prom = null, min	= null, max	= null, perce25	= null, perce75 = null, mediana	= null");
		
		//grabamos en DB
		foreach($resOrg as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$tipo_pruebas){
				foreach($tipo_pruebas as $tipo_prueba=>$modEst){
					$limeReporteInstitucional = LimeReporteInstitucional::where("id_institucion",$id_institucion)->where("id_carrera", $id_carrera)->where("tipo_prueba", strtoupper($tipo_prueba))->first();					
					if(isset($limeReporteInstitucional->id_reporte_institucional)){
						$limeReporteInstitucional->promedio = $resICT[$id_institucion][$id_carrera][$tipo_prueba]["promedio"];
						$limeReporteInstitucional->min = $resICT[$id_institucion][$id_carrera][$tipo_prueba]["min"];
						$limeReporteInstitucional->max = $resICT[$id_institucion][$id_carrera][$tipo_prueba]["max"];
						$limeReporteInstitucional->mediana = $resICT[$id_institucion][$id_carrera][$tipo_prueba]["mediana"];
						$limeReporteInstitucional->perce25 = $resICT[$id_institucion][$id_carrera][$tipo_prueba]["perce25"];
						$limeReporteInstitucional->perce75 = $resICT[$id_institucion][$id_carrera][$tipo_prueba]["perce75"];
						$limeReporteInstitucional->save();
			
						foreach($modEst as $mEst=>$datos){
							//grabamos en tabla lime_resultado_institucion
							
							$limeResultadoInstitucion = LimeResultadoInstitucion::where("id_reporte_institucional",$limeReporteInstitucional->id_reporte_institucional)->where("modo_estudio", $mEst)->first();
							if(isset($limeResultadoInstitucion->id_resultado_institucion)){
								$limeResultadoInstitucion->prom = $datos["promedio"];
								$limeResultadoInstitucion->min = $datos["min"];
								$limeResultadoInstitucion->max = $datos["max"];
								$limeResultadoInstitucion->mediana = $datos["mediana"];
								$limeResultadoInstitucion->perce25 = $datos["perce25"];
								$limeResultadoInstitucion->perce75 = $datos["perce75"];
								$limeResultadoInstitucion->save();
							}
							else{
								echo $limeReporteInstitucional->id_reporte_institucional."<br/>";
								echo $mEst;
								exit;
							}
						}						
					}
					else{
						//"revisar porque entra acá";
					}
				}	
			}
		}
	}
		
	public function calculaPuntajes2017(){
		
		//calcula los promedios, minima, maxima y los ingresa a la tabla lime_reporte_institucional
		
		//https://www.diagnosticafid.cl/public/calcula-puntajes-2017
		
		$sql = "SELECT * FROM lime_tendencia where anio = 2017";
		
		$ptje = DB::select($sql);		
		foreach($ptje as $ptjeAux){
				@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba]["sum"]+= $ptjeAux->puntaje;
				@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba]["ctd"]++;
				//todos
				$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba]["todos"][] = $ptjeAux->puntaje;
		}
		
		foreach($res as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$tipo_pruebas){
				foreach($tipo_pruebas as $tipo_prueba=>$datos){
					$resOrg[$id_institucion][$id_carrera][$tipo_prueba]["promedio"] =  $res[$id_institucion][$id_carrera][$tipo_prueba]["sum"]/$res[$id_institucion][$id_carrera][$tipo_prueba]["ctd"];
					//$resOrg[$id_institucion][$id_carrera][$tipo_prueba]["min"] =  min($res[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
					//$resOrg[$id_institucion][$id_carrera][$tipo_prueba]["max"] =  max($res[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
					//$resOrg[$id_institucion][$id_carrera][$tipo_prueba]["mediana"] =  get_percentile(50,$res[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
				}	
			}
		}
		
		foreach($resOrg as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$tipo_pruebas){
				foreach($tipo_pruebas as $tipo_prueba=>$datos){
					$limeReporteInstitucional = LimeReporteInstitucional::where("id_institucion",$id_institucion)->where("id_carrera", $id_carrera)->where("tipo_prueba", strtoupper($tipo_prueba))->first();					
					if(isset($limeReporteInstitucional->id_reporte_institucional)){
						$limeReporteInstitucional->promedio2017 = $datos["promedio"];	
						$limeReporteInstitucional->save();
					}
					else{
						//echo "no existe	".$id_institucion." ".$id_carrera." ".$tipo_prueba."<br/>"; 
					}
				}	
			}
		}
	}
	
	public function reporteInstitucional(){
		
		//https://www.diagnosticafid.cl/public/reporte-institucional
		
		/*
		delete from lime_reporte_institucional_tema;
		delete from lime_reporte_institucional_estandar;
		delete from lime_resultado_institucion;
		delete from lime_reporte_institucional;
		*/
		// DB::select("delete from lime_reporte_institucional_tema");
		// DB::select("delete from lime_reporte_institucional_estandar");
		// DB::select("delete from lime_resultado_institucion");
		// DB::select("delete from lime_reporte_institucional");
			
		$sql = "
			select institucionestudios.id as id_institucion, evaluados.id_carrera, id_excel_iie, pruebas.tipo_prueba, extra_prosecucion
			from evaluados, carreras, carrera_prueba, pruebas, institucionestudios, sedeinstitucion
			where evaluados.id_carrera = carreras.id_carrera 
			and carrera_prueba.id_carrera  = carreras.id_carrera 
			and carrera_prueba.id_prueba = pruebas.id
			and codigo_prueba not in (563156)
			and evaluados.cumple_requisito = true
			and evaluados.sedeinstitucion_id = sedeinstitucion.id
			and institucionestudios.id = sedeinstitucion.institucionestudios_id
			ORDER BY institucionestudios.nombre_institucion asc, carreras.carrera, rut desc
		";
		
									
		$listadoCompleto = DB::select($sql);		
		
		//porcentaje de logro por tema
		$pLogroTema = DB::select("
								select cod_iie, tipo_prueba, id_tema, porcentaje 
								from lime_porcentaje_logro_tema, lime_tema , pruebas 
								where lime_porcentaje_logro_tema.id_tema = lime_tema.id_lime_tema
								and lime_tema.id_prueba = pruebas.id order by cod_iie desc, tipo_prueba , nro_tema 
									");		
									
		foreach($pLogroTema as $pLogroTemaAux){
			$pLT[$pLogroTemaAux->cod_iie][$pLogroTemaAux->tipo_prueba][$pLogroTemaAux->id_tema] = $pLogroTemaAux->porcentaje;	
		}
		
		//porcentaje de logro por estandar
		$pLogroEstandar = DB::select("
								select cod_iie, tipo_prueba, id_estandar, porcentaje 
								from lime_porcentaje_logro_estandar, lime_estandar , pruebas 
								where lime_porcentaje_logro_estandar.id_estandar = lime_estandar.id_lime_estandar
								and lime_estandar.id_prueba = pruebas.id order by cod_iie desc, tipo_prueba , nro_estandar 
									");	
									
		foreach($pLogroEstandar as $pLogroTemaAux){
			$pL[$pLogroTemaAux->cod_iie][$pLogroTemaAux->tipo_prueba][$pLogroTemaAux->id_estandar] = $pLogroTemaAux->porcentaje;	
		}
		
		$totalProsecucion = array();
		$totalRegular = array();
		

		foreach($listadoCompleto as $listadoCompletoAux){
			$extraProsecucion = ($listadoCompletoAux->extra_prosecucion==true)?'prosecucion':'regular';
			$listadoCompletoAux = $listadoCompletoAux ;
			// if(!array_key_exists($listadoCompletoAux->tipo_prueba,$pL[$listadoCompletoAux->id_excel_iie])){
				// echo $listadoCompletoAux->id_excel_iie;
				// arreglo($pL[$listadoCompletoAux->id_excel_iie]);
				// exit;
			// }
			$resOrg[$listadoCompletoAux->id_institucion][$listadoCompletoAux->id_carrera][$listadoCompletoAux->tipo_prueba][$extraProsecucion]["estandar"][] = $pL[$listadoCompletoAux->id_excel_iie][$listadoCompletoAux->tipo_prueba];
			$resOrg[$listadoCompletoAux->id_institucion][$listadoCompletoAux->id_carrera][$listadoCompletoAux->tipo_prueba][$extraProsecucion]["tema"][] = $pLT[$listadoCompletoAux->id_excel_iie][$listadoCompletoAux->tipo_prueba];
		}
		
		foreach($resOrg as $institucion =>$instituciones){
			foreach($instituciones as $carrera=>$carreras){
				foreach($carreras as $tipoPrueba=>$modEstudios){
					foreach($modEstudios as $modEstudio=>$tipoPuntajes){
						foreach($tipoPuntajes as $tipoPuntaje=>$alumnosAux){
							foreach($alumnosAux as $alumnos){
								foreach($alumnos as $numero => $puntajes){
									$porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero][] = $puntajes;
									@$totalPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["total"]++;
									@$sumaPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["suma"]+= $puntajes;
								}
							}	
						}
					}
				}
			}
		}
		
		//sacamos promedio y otros calculos
		foreach($resOrg as $institucion =>$instituciones){
			foreach($instituciones as $carrera=>$carreras){
				foreach($carreras as $tipoPrueba=>$modEstudios){
					foreach($modEstudios as $modEstudio=>$tipoPuntajes){
						foreach($tipoPuntajes as $tipoPuntaje=>$alumnosAux){
							foreach($alumnosAux as $alumnos){
								foreach($alumnos as $numero => $puntajes){
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['promedio'] = $sumaPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["suma"]/$totalPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["total"];
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['minimo'] = min($porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['maximo'] = max($porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['mediana'] = get_percentile(50, $porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['perce25'] = get_percentile(25, $porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['perce75'] = get_percentile(75, $porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
								}
							}
						}
					}
				}
			}
		}

		$sqlAux = '';
		foreach($Xnumero as $institucion =>$instituciones){
			foreach($instituciones as $carrera=>$carreras){
				foreach($carreras as $tipoPrueba=>$modEstudios){
					
					$reporteInstitucional = LimeReporteInstitucional::where("id_institucion", $institucion)->where("id_carrera", $carrera)->where("tipo_prueba", $tipoPrueba)->first();			
					if(!isset($reporteInstitucional->id_reporte_institucional)){
						$reporteInstitucional = new LimeReporteInstitucional();				
					}
					// $reporteInstitucional->id_institucion = $institucion;
					// $reporteInstitucional->id_carrera = $carrera;
					// $reporteInstitucional->tipo_prueba = $tipoPrueba;
					// $reporteInstitucional->save();
					
					foreach($modEstudios as $modEstudio=>$alumnos){
						$LimeResultadoInstitucion = LimeResultadoInstitucion::where("id_reporte_institucional", $reporteInstitucional->id_reporte_institucional)->where("modo_estudio", $modEstudio)->first();			
						if(!isset($LimeResultadoInstitucion->id_resultado_institucion)){
							$LimeResultadoInstitucion = new LimeResultadoInstitucion();			
						}
						// $LimeResultadoInstitucion->id_reporte_institucional	 = $reporteInstitucional->id_reporte_institucional;	
						// $LimeResultadoInstitucion->modo_estudio	= $modEstudio;
						// $LimeResultadoInstitucion->save();

						
						foreach($alumnos as $tipoPuntaje=>$resultados){
							foreach($resultados as $numeroTema=>$tema){
								if($tipoPuntaje=='estandar'){
									$limeReporteInstitucionalEstandar = LimeReporteInstitucionalEstandar::where("id_resultado_institucion", $LimeResultadoInstitucion->id_resultado_institucion)->where("id_estandar", $numeroTema)->first();			
									if(!isset($limeReporteInstitucionalEstandar->id_reporte_institucional_estandar)){
										$limeReporteInstitucionalEstandar = new LimeReporteInstitucionalEstandar();	
									}
									$limeReporteInstitucionalEstandar->id_resultado_institucion	= $LimeResultadoInstitucion->id_resultado_institucion;
									$limeReporteInstitucionalEstandar->id_estandar = $numeroTema;
									
									$limeReporteInstitucionalEstandar->prom	 = $tema["promedio"];
									$limeReporteInstitucionalEstandar->min	 = $tema["minimo"];
									$limeReporteInstitucionalEstandar->max	 = $tema["maximo"];
									$limeReporteInstitucionalEstandar->mediana	 = $tema["mediana"];
									$limeReporteInstitucionalEstandar->perce25	 = $tema["perce25"];
									$limeReporteInstitucionalEstandar->perce75	 = $tema["perce75"];
									
									$limeReporteInstitucionalEstandar->save();
								}
								else{
									$limeReporteInstitucionalTema = LimeReporteInstitucionalTema::where("id_resultado_institucion", $LimeResultadoInstitucion->id_resultado_institucion)->where("id_tema", $numeroTema)->first();			
									if(!isset($limeReporteInstitucionalTema->id_reporte_institucional_tema)){
										$limeReporteInstitucionalTema = new LimeReporteInstitucionalTema();	
									}
									
									$limeReporteInstitucionalTema->id_resultado_institucion	= $LimeResultadoInstitucion->id_resultado_institucion;
									$limeReporteInstitucionalTema->prom	 = $tema["promedio"];
									$limeReporteInstitucionalTema->min	 = $tema["minimo"];
									$limeReporteInstitucionalTema->max	 = $tema["maximo"];
									$limeReporteInstitucionalTema->mediana	 = $tema["mediana"];
									$limeReporteInstitucionalTema->perce25	 = $tema["perce25"];
									$limeReporteInstitucionalTema->perce75	 = $tema["perce75"];
									$limeReporteInstitucionalTema->id_tema = $numeroTema;
									$limeReporteInstitucionalTema->save();
								}							
							}
						}
					}
				}
			}
		}
		echo "ok";
	}


	// public function porcentajeLogro()
    // {
		// //https://www.diagnosticafid.cl/public/porcentaje-logro
		
		// // SELECT nombre_corto, rut, nro_tema, porcentaje	 
		// // FROM lime_porcentaje_logro, evaluados, lime_tema, pruebas
		// // where lime_porcentaje_logro.cod_iie  = evaluados.id_excel_iie
		// // and lime_tema.id_lime_tema = lime_porcentaje_logro.id_tema
		// // and lime_tema.id_prueba = pruebas.id
		// // order by nombre_corto, rut,nro_tema
		
		// $traduccionResp["A"] = "A1";
		// $traduccionResp["B"] = "A2";
		// $traduccionResp["C"] = "A3";
		// $traduccionResp["D"] = "A4";
		
		// $traduccionRespInv["A1"] = "A";
		// $traduccionRespInv["A2"] = "B";
		// $traduccionRespInv["A3"] = "C";
		// $traduccionRespInv["A4"] = "D";
		

		// //pregunta pertenece a qué tema
		// $limePregunta = LimePregunta::where('codigo_prueba_deprecado','!=',563156)->get();
		
		// foreach($limePregunta as $limePreguntas){
			// $respuestasCorrectas[$limePreguntas->codigo_prueba][$limePreguntas->orden] = $limePreguntas->respuesta_correcta;
		// }


		// foreach($limePregunta as $limePreguntaAux){
			// $preguntaTema[$limePreguntaAux->id_lime_pregunta] = $limePreguntaAux->id_lime_tema;	
		// }

		// $codigo_pruebadeprecado[] = 829993; //PCPG - Conocimientos Pedagógicos Generales para Educación Parvularia 
		// $codigo_pruebadeprecado[] = 999922; //PCPG - Conocimientos Pedagógicos Generales para Educación Básica
		// $codigo_pruebadeprecado[] = 142248; //PCPG - Conocimientos Pedagógicos Generales para Educación Básica (PERO ES PARA ESPECIAL)
		// $codigo_pruebadeprecado[] = 999933; //PCPG - Conocimientos Pedagógicos Generales para Educación Media	
		
		// $codigo_pruebadeprecado[] = 479156; //PCDD - Conocimientos Disciplinarios y Didácticos para Artes Visuales	
		// $codigo_pruebadeprecado[] = 399132; //PCDD - Conocimientos Disciplinarios y Didácticos para Biología
		// $codigo_pruebadeprecado[] = 293621; //PCDD - Conocimientos Disciplinarios y Didácticos para Educación Básica
		// $codigo_pruebadeprecado[] = 518711; //PCDD - Conocimientos Generales de Educación Especial	
		// $codigo_pruebadeprecado[] = 681587; //PCDD - Conocimientos Disciplinarios y Didácticos para Educación Física
		// $codigo_pruebadeprecado[] = 151547; //PCDD - Conocimientos Disciplinarios y Didácticos para Educación Parvularia
		// $codigo_pruebadeprecado[] = 725271; //PCDD - Conocimientos Disciplinarios y Didácticos para Física
		// $codigo_pruebadeprecado[] = 263661; //PCDD - Conocimientos Disciplinarios y Didácticos para Historia, Geografía y Ciencias Sociales
		// $codigo_pruebadeprecado[] = 229213; //PCDD - Conocimientos Disciplinarios y Didácticos para Inglés
		// $codigo_pruebadeprecado[] = 336575; //PCDD - Conocimientos Disciplinarios y Didácticos para Lenguaje y Comunicación
		// $codigo_pruebadeprecado[] = 852364; //PCDD - Conocimientos Disciplinarios y Didácticos para Matemática
		// $codigo_pruebadeprecado[] = 536992; //PCDD - Conocimientos Disciplinarios y Didácticos para Música
		// $codigo_pruebadeprecado[] = 838329; //PCDD - Conocimientos Disciplinarios y Didácticos para Química

		// $path = app_path('Http/Controllers/')."IIE/datos_txt/monitoreo/";
		// @unlink($path."_porcentaje_logro_sql.txt");
		// $fp = fopen($path."_porcentaje_logro_sql.txt", 'w+');	
		
		// $sqlDelete = "DELETE FROM lime_porcentaje_logro";
		// DB::select($sqlDelete);
		
		
		// foreach($codigo_pruebadeprecado as $codigo_prueba_deprecado){
			// $pr = Prueba::where("codigo_prueba",$codigo_prueba_deprecado)->first();
			// $id_prueba = $pr->id;		
			// $limeRespuestaSql = "SELECT lime_pregunta.id_lime_pregunta, cod_iie , rut
									// FROM lime_respuesta, lime_pregunta, lime_tema,evaluados 
									// WHERE lime_respuesta.id_lime_pregunta = lime_pregunta.id_lime_pregunta 
									// AND evaluados.id_excel_iie = lime_respuesta.cod_iie
									// AND codigo_prueba_deprecado = ".$codigo_prueba_deprecado."
									// AND lime_pregunta.id_lime_tema =  lime_tema.id_lime_tema
									// AND lime_pregunta.excluir = false
									// AND lime_pregunta.tipo_pregunta = 'alternativa'
									// AND cumple_requisito = true
									// AND id_prueba = ".$id_prueba;
			
			// $limeRespuesta = DB::select($limeRespuestaSql);
			
			
	// ////////		
			// $_limeRespuesta = DB::select(trim("SELECT id_excel_iie, respuesta, codigo_prueba_deprecado,respuesta_correcta , orden, lime_pregunta.id_lime_pregunta 
				// FROM lime_respuesta, lime_pregunta, evaluados 
				// WHERE lime_respuesta.id_lime_pregunta = lime_pregunta.id_lime_pregunta 
				// AND evaluados.id_excel_iie = lime_respuesta.cod_iie	
				// AND lime_pregunta.codigo_prueba_deprecado = ".$codigo_prueba_deprecado."
				// AND tipo_pregunta = 'alternativa'
				// AND lime_pregunta.excluir = false
				// AND cumple_requisito = true
				// ORDER BY orden ASC"));
				
				
				
			// $resRes = array();

			// foreach($_limeRespuesta as $limeRespuestas){
				// //para el binario
				// if(($limeRespuestas->respuesta=="")||($limeRespuestas->respuesta == null)){
					// $resRes[$limeRespuestas->id_excel_iie][$limeRespuestas->id_lime_pregunta] = "";
				// }
				// else{
					// if($traduccionResp[$limeRespuestas->respuesta_correcta] == $limeRespuestas->respuesta){
						// $resRes[$limeRespuestas->id_excel_iie][$limeRespuestas->id_lime_pregunta] = "1";
					// }
					// else{
						// $resRes[$limeRespuestas->id_excel_iie][$limeRespuestas->id_lime_pregunta] = "0";
					// }
				// }
			// }
	// /////////		
			// $resAlu = array();
			// foreach($limeRespuesta as $limeRespuestaAux){
				// $resAlu[$limeRespuestaAux->cod_iie][$preguntaTema[$limeRespuestaAux->id_lime_pregunta]][$limeRespuestaAux->id_lime_pregunta] = $resRes[$limeRespuestaAux->cod_iie][$limeRespuestaAux->id_lime_pregunta];			
			// }
			
			// unset($limeRespuesta);
			// $resPorAlu = array();
			// foreach($resAlu as $codIIE=>$temas){
				// $promedio = array();
				// foreach($temas as $idTema=>$preguntas){
					// $sum = 0;
					// $promedio[$idTema] = "";
					// foreach($preguntas as $codigo){
						// if($codigo == 1){
							// $sum++; 
						// }
					// }
					// $promedio[$idTema] = $sum/count($preguntas);
				// }
				// $resPorAlu[$codIIE] = $promedio;
			// }

			// unset($resAlu);
			
			// foreach($resPorAlu as $cod_iie=>$porcentajes){
				// foreach($porcentajes as $id_tema=>$porcentaje){
					// // $limePorcentajeLogro = new LimePorcentajeLogro();	
					// // $limePorcentajeLogro->cod_iie = trim($cod_iie);	
					// // $limePorcentajeLogro->id_tema = trim($id_tema);	
					// // $limePorcentajeLogro->porcentaje = trim($porcentaje);	
					// // $limePorcentajeLogro->save();
					// $sqlAux[] = "insert into lime_porcentaje_logro (cod_iie, id_tema, porcentaje) values ('".trim($cod_iie)."', '".trim($id_tema)."', '".trim($porcentaje)."');\n";
					
				// }
			// }
		// }	
		
		// $lines = array_unique($sqlAux);
		// fwrite($fp, implode($lines));
		// fclose($fp);				
		// $comando  = 'PGPASSWORD=k1LL2018 psql -h 162.216.18.16 -d endfid -U postgres -p 5432 -a -q -f /home/diag2018fid/public_html/app/Http/Controllers/IIE/datos_txt/monitoreo/_porcentaje_logro_sql.txt';
		// echo $comando;
		// //shell_exec($comando);
	// }
	
	
	public function porcentajeLogro()
    {
		
		//https://www.diagnosticafid.cl/public/porcentaje-logro
		
		// SELECT nombre_corto, rut, nro_estandar	, porcentaje	 
		// FROM lime_porcentaje_logro_estandar, evaluados, lime_estandar, pruebas
		// where lime_porcentaje_logro_estandar.cod_iie  = evaluados.id_excel_iie
		// and lime_estandar.id_lime_estandar = lime_porcentaje_logro_estandar.id_estandar
		// and lime_estandar.id_prueba = pruebas.id
		// order by nombre_corto, rut,nro_estandar	

		$tipoDato = "tema";
		//$tipoDato = "estandar";
		
		$traduccionResp["A"] = "A1";
		$traduccionResp["B"] = "A2";
		$traduccionResp["C"] = "A3";
		$traduccionResp["D"] = "A4";
		
		$traduccionRespInv["A1"] = "A";
		$traduccionRespInv["A2"] = "B";
		$traduccionRespInv["A3"] = "C";
		$traduccionRespInv["A4"] = "D";
		
		$path = app_path('Http/Controllers/')."IIE/datos_csv/respuestas/";
	
		//pregunta
		$limePregunta = LimePregunta::where('codigo_prueba_deprecado','!=',563156)->get();
		
		// foreach($limePregunta as $limePreguntas){
			// $respuestasCorrectas[$limePreguntas->codigo_prueba][$limePreguntas->orden] = $limePreguntas->respuesta_correcta;
		// }

		if($tipoDato=='estandar'){
			foreach($limePregunta as $limePreguntaAux){
				$preguntaEstandar[$limePreguntaAux->id_lime_pregunta] = $limePreguntaAux->id_lime_estandar;	
			}
		}
		else{
			foreach($limePregunta as $limePreguntaAux){
				$preguntaEstandar[$limePreguntaAux->id_lime_pregunta] = $limePreguntaAux->id_lime_tema;	
			}
		}

		$codigo_pruebadeprecado[] = 829993; //PCPG - Conocimientos Pedagógicos Generales para Educación Parvularia 
		$codigo_pruebadeprecado[] = 999922; //PCPG - Conocimientos Pedagógicos Generales para Educación Básica
		$codigo_pruebadeprecado[] = 142248; //PCPG - Conocimientos Pedagógicos Generales para Educación Básica (PERO ES PARA ESPECIAL)
		$codigo_pruebadeprecado[] = 999933; //PCPG - Conocimientos Pedagógicos Generales para Educación Media	
		
		$codigo_pruebadeprecado[] = 479156; //PCDD - Conocimientos Disciplinarios y Didácticos para Artes Visuales	
		$codigo_pruebadeprecado[] = 399132; //PCDD - Conocimientos Disciplinarios y Didácticos para Biología
		$codigo_pruebadeprecado[] = 293621; //PCDD - Conocimientos Disciplinarios y Didácticos para Educación Básica

		$codigo_pruebadeprecado[] = 681587; //PCDD - Conocimientos Disciplinarios y Didácticos para Educación Física
		$codigo_pruebadeprecado[] = 229213; //PCDD - Conocimientos Disciplinarios y Didácticos para Inglés
		$codigo_pruebadeprecado[] = 336575; //PCDD - Conocimientos Disciplinarios y Didácticos para Lenguaje y Comunicación
		$codigo_pruebadeprecado[] = 852364; //PCDD - Conocimientos Disciplinarios y Didácticos para Matemática

		$codigo_pruebadeprecado[] = 838329; //PCDD - Conocimientos Disciplinarios y Didácticos para Química

		
		$codigo_pruebadeprecado[] = 151547; //PCDD - Conocimientos Disciplinarios y Didácticos para Educación Parvularia
		$codigo_pruebadeprecado[] = 518711; //PCDD - Conocimientos Generales de Educación Especial	
		$codigo_pruebadeprecado[] = 725271; //PCDD - Conocimientos Disciplinarios y Didácticos para Física		
		$codigo_pruebadeprecado[] = 536992; //PCDD - Conocimientos Disciplinarios y Didácticos para Música
		$codigo_pruebadeprecado[] = 263661; //PCDD - Conocimientos Disciplinarios y Didácticos para Historia, Geografía y Ciencias Sociales
		
		$sqlAux = "";
		
		$sqlDelete = "DELETE FROM lime_porcentaje_logro_".$tipoDato." ";
		DB::select($sqlDelete);
		
		foreach($codigo_pruebadeprecado as $codigo_prueba_deprecado){
		
			$pr = Prueba::where("codigo_prueba",$codigo_prueba_deprecado)->first();
			$id_prueba = $pr->id;		
			$limeRespuestaSql = "SELECT id_excel_iie, respuesta, respuesta_correcta, orden, lime_pregunta.id_lime_pregunta, cod_iie , rut
									FROM lime_respuesta, lime_pregunta, lime_".$tipoDato.", evaluados 
									WHERE lime_respuesta.id_lime_pregunta = lime_pregunta.id_lime_pregunta 
									AND evaluados.id_excel_iie = lime_respuesta.cod_iie
									AND lime_pregunta.id_lime_".$tipoDato." =  lime_".$tipoDato.".id_lime_".$tipoDato."
									AND lime_pregunta.excluir = false
									AND lime_pregunta.tipo_pregunta = 'alternativa'
									AND cumple_requisito = true
									AND id_prueba = ".$id_prueba;
			
			$limeRespuesta = DB::select($limeRespuestaSql);
			
			// ////////		
			// $_limeRespuesta = DB::select(trim("SELECT id_excel_iie, respuesta, codigo_prueba_deprecado,respuesta_correcta , orden, lime_pregunta.id_lime_pregunta 
				// FROM lime_respuesta, lime_pregunta, evaluados ,lime_estandar
				// WHERE lime_respuesta.id_lime_pregunta = lime_pregunta.id_lime_pregunta 
				// AND evaluados.id_excel_iie = lime_respuesta.cod_iie	
				// AND lime_pregunta.id_lime_estandar =  lime_estandar.id_lime_estandar
				// AND tipo_pregunta = 'alternativa'
				// AND lime_pregunta.excluir = false
				// AND cumple_requisito = true
				// AND id_prueba = ".$id_prueba."
				// ORDER BY orden ASC"));
			
			$resRes = array();
			$resAlu = array();
			foreach($limeRespuesta as $limeRespuestas){
				//para el binario
				if(($limeRespuestas->respuesta=="")||($limeRespuestas->respuesta == null)){
					$resRes[$limeRespuestas->id_excel_iie][$limeRespuestas->id_lime_pregunta] = "0";
				}
				else{
					if($traduccionResp[$limeRespuestas->respuesta_correcta] == $limeRespuestas->respuesta){
						$resRes[$limeRespuestas->id_excel_iie][$limeRespuestas->id_lime_pregunta] = "1";
					}
					else{
						$resRes[$limeRespuestas->id_excel_iie][$limeRespuestas->id_lime_pregunta] = "0";
					}
				}
				$resAlu[$limeRespuestas->cod_iie][$preguntaEstandar[$limeRespuestas->id_lime_pregunta]][$limeRespuestas->id_lime_pregunta] = $resRes[$limeRespuestas->cod_iie][$limeRespuestas->id_lime_pregunta];							
			}

			/////////		
			//foreach($limeRespuesta as $limeRespuestaAux){
			//	$resAlu[$limeRespuestaAux->cod_iie][$preguntaEstandar[$limeRespuestaAux->id_lime_pregunta]][$limeRespuestaAux->id_lime_pregunta] = $resRes[$limeRespuestaAux->cod_iie][$limeRespuestaAux->id_lime_pregunta];			
			//}
			
			unset($limeRespuesta);
			$resPorAlu = array();
			foreach($resAlu as $codIIE=>$estandares){
				$promedio = array();
				foreach($estandares as $idEstandar=>$preguntas){
					$sum = 0;
					$promedio[$idEstandar] = "";
					foreach($preguntas as $codigo){
						if($codigo == 1){
							$sum++; 
						}
					}
					$promedio[$idEstandar] = $sum/count($preguntas);
				}
				$resPorAlu[$codIIE] = $promedio;
			}

			
			unset($resAlu);
			//@unlink($path."__sql.txt");
			
			foreach($resPorAlu as $cod_iie=>$porcentajes){
				foreach($porcentajes as $id_estandar=>$porcentaje){
					$sqlAux.= "insert into lime_porcentaje_logro_".$tipoDato." (cod_iie, id_".$tipoDato.", porcentaje) values ('".trim($cod_iie)."', '".trim($id_estandar)."', '".trim($porcentaje)."');\n";
				}
			}
		}	
		$nArchivo = $path.date('Y_m_d-H_i_s')."_sql.txt";
		$fp = fopen($nArchivo, 'w+');	
		fwrite($fp, $sqlAux);
		fclose($fp);		

		$comando  = 'PGPASSWORD=k1LL2018 psql -h 162.216.18.16 -d endfid -U postgres -p 5432 -a -q -f '.$nArchivo;
		echo $comando;
	}	
	
	
    public function resultados()
    {
		//https://www.diagnosticafid.cl/public/reportes/resultados
		
		$traduccionResp["A"] = "A1";
		$traduccionResp["B"] = "A2";
		$traduccionResp["C"] = "A3";
		$traduccionResp["D"] = "A4";
		
		$traduccionRespInv["A1"] = "A";
		$traduccionRespInv["A2"] = "B";
		$traduccionRespInv["A3"] = "C";
		$traduccionRespInv["A4"] = "D";
		
		
		$path = app_path('Http/Controllers/')."IIE/datos_csv/respuestas/";
		mkdir($path.date('Y-m-d_H_i_s'), 0700);
		$path = $path.date('Y-m-d_H_i_s')."/";
		
		$limePregunta = LimePregunta::get();
		foreach($limePregunta as $limePreguntas){	
			$respuestasCorrectas[$limePreguntas->codigo_prueba][$limePreguntas->orden] = $limePreguntas->respuesta_correcta;
		}
		
		$pp[] = 563156;
		
		//nombres de pruebas
		$pruebas = Prueba::get();
		foreach($pruebas as $prueba){
			if(!in_array($prueba->codigo_prueba, $pp)){
				$nombrePrueba[$prueba->codigo_prueba] = $prueba->nombre_corto;	
			
				$codigo_prueba = $prueba->codigo_prueba;
				
				$limeRespuesta = "
					SELECT rut, respuesta, codigo_prueba_deprecado,respuesta_correcta , orden 
					FROM lime_respuesta, lime_pregunta, evaluados 
					WHERE lime_respuesta.id_lime_pregunta = lime_pregunta.id_lime_pregunta 
					AND evaluados.id_excel_iie = lime_respuesta.cod_iie	
					AND lime_pregunta.codigo_prueba_deprecado = ".$codigo_prueba."
					AND tipo_pregunta = 'alternativa'
					ORDER BY orden ASC";
				$_limeRespuesta = DB::select(trim($limeRespuesta));
				
				
				$limePreguntas = "
					SELECT orden 
					FROM lime_pregunta
					WHERE lime_pregunta.codigo_prueba_deprecado = ".$codigo_prueba."
					AND tipo_pregunta = 'alternativa'
					ORDER BY orden ASC";			
				$_limePreguntas = DB::select(trim($limePreguntas));
				$resRes = array();
				$resResLetra = array();
				foreach($_limeRespuesta as $limeRespuestas){
					//para el binario
					if(($limeRespuestas->respuesta=="")||($limeRespuestas->respuesta == null)){
						$resRes[$limeRespuestas->rut][$limeRespuestas->orden] = "";
					}
					else{
						if($traduccionResp[$limeRespuestas->respuesta_correcta] == $limeRespuestas->respuesta){
							$resRes[$limeRespuestas->rut][$limeRespuestas->orden] = "1";
						}
						else{
							$resRes[$limeRespuestas->rut][$limeRespuestas->orden] = "0";
						}
					}

					//para el de respuestas
					if(($limeRespuestas->respuesta=="")||($limeRespuestas->respuesta == null)){
						$resResLetra[$limeRespuestas->rut][$limeRespuestas->orden] = "";
					}
					else{
						$resResLetra[$limeRespuestas->rut][$limeRespuestas->orden] = $traduccionRespInv[$limeRespuestas->respuesta];
					}
					
				}
				
				//para el binario
				$t = "RUN,";
				foreach($_limePreguntas as $fileAux){
					$t.=$fileAux->orden.",";
				}	
				$t.="\n";
				foreach($resRes as $rut=>$fileAux){
					$t.= $rut.",".implode(",",$fileAux)."\n";
				}
				
				$fileName = $path.$nombrePrueba[$codigo_prueba]."_binario.csv";
				$fp = fopen($fileName, 'a+');
				fwrite($fp, $t);
				fclose($fp);	
				
				//para las alternativas
				$tR = "RUN,";
				foreach($_limePreguntas as $fileAux){
					$t.=$fileAux->orden.",";
				}	
				$tR.="\n";
				foreach($resResLetra as $rut=>$fileAux){
					$tR.= $rut.",".implode(",",$fileAux)."\n";
				}
				$fileNameR = $path.$nombrePrueba[$codigo_prueba]."_respuesta.csv";
				$fp = fopen($fileNameR, 'a+');
				fwrite($fp, $tR);
				fclose($fp);	
				
			}
		}
	}

    public function asistencia(Request $request)
    {
		//https://www.diagnosticafid.cl/public/reportes/asistencia

		//829993; //PCPG - Conocimientos Pedagógicos Generales para Educación Parvularia 
		//999922; //PCPG - Conocimientos Pedagógicos Generales para Educación Básica
		//142248; //PCPG - Conocimientos Pedagógicos Generales para Educación Básica (PERO ES PARA ESPECIAL)
		//999933; //PCPG - Conocimientos Pedagógicos Generales para Educación Media	
		//678692  //PCPG - Conocimientos Pedagógicos Generales para Educación Media

		//518711; //PCDD - Conocimientos Generales de Educación Especial	
		//151547; //PCDD - Conocimientos Disciplinarios y Didácticos para Educación Parvularia
		//293621; //PCDD - Conocimientos Disciplinarios y Didácticos para Educación Básica
		//681587; //PCDD - Conocimientos Disciplinarios y Didácticos para Educación Física
		//725271; //PCDD - Conocimientos Disciplinarios y Didácticos para Física
		//838329; //PCDD - Conocimientos Disciplinarios y Didácticos para Química
		//399132; //PCDD - Conocimientos Disciplinarios y Didácticos para Biología
		//336575; //PCDD - Conocimientos Disciplinarios y Didácticos para Lenguaje y Comunicación
		//536992; //PCDD - Conocimientos Disciplinarios y Didácticos para Música
		//263661  //PCDD - Conocimientos Disciplinarios y Didácticos para Historia, Geografía y Ciencias Sociales
		//229213  //PCDD - Conocimientos Disciplinarios y Didácticos para Inglés
		//852364  //PCDD - Conocimientos Disciplinarios y Didácticos para Matemáticas
		//479156  //PCDD - Conocimientos Disciplinarios y Didácticos para Artes Visuales

		//cuestionario
		//563156; //Cuestionario de Información Complementaria 
			
		$fecha_agendada = '2019-01-23';
		$complementaria = true;
		
		$asistencia = DB::select("SELECT codigo_prueba, cod_iie 
								  FROM lime_respuesta, lime_pregunta 
								  WHERE lime_respuesta.id_lime_pregunta = lime_pregunta.id_lime_pregunta
								  AND complementaria = ".$complementaria."
								  GROUP BY codigo_prueba, cod_iie");
		
		foreach($asistencia as $_asistencia){
			$asiste[$_asistencia->codigo_prueba][] = $_asistencia->cod_iie;
		}
		
		$programacion = DB::select("select 
		carrera_prueba.id_carrera, carrera_prueba.id_prueba, evaluados.id as id_evaluado,id_excel_iie,rut,aplicaciones.fecha_agendada, 
		p.codigo_prueba, p.nombre_prueba, p.tipo_prueba, email1, email2, rinde_pcdd, lab_cod_iie, carrera
		from evaluados, carreras, carrera_prueba, pruebas p, evaluadosaplicaciones, aplicaciones, dependencias
		where evaluados.id_carrera = carreras.id_carrera 
		and dependencias.id = aplicaciones.dependencia_id
		and carrera_prueba.id_carrera  = carreras.id_carrera 
		and carrera_prueba.id_prueba = p.id
		and evaluadosaplicaciones.idevaluado = evaluados.id
		and aplicaciones.id = evaluadosaplicaciones.idaplicacion
		and fecha_agendada = '".$fecha_agendada."'
		and p.codigo_prueba<>'563156'
		ORDER BY tipo_prueba DESC, rut");

		foreach($programacion as $_programacion){
			$arrAlumno[$_programacion->id_excel_iie]["PCDD"] = "No aplica";
		}	
		
		foreach($programacion as $_programacion){
		
			$arrAlumno[$_programacion->id_excel_iie]["rut"] = $_programacion->rut;
			$arrAlumno[$_programacion->id_excel_iie]["carrera"] = $_programacion->carrera;
			$arrAlumno[$_programacion->id_excel_iie]["email1"] = $_programacion->email1;
			$arrAlumno[$_programacion->id_excel_iie]["email2"] = $_programacion->email2;
			if(in_array($_programacion->id_excel_iie, $asiste[$_programacion->codigo_prueba])){
				$arrAlumno[$_programacion->id_excel_iie][$_programacion->tipo_prueba] = "Si";
			}
			else{
				$arrAlumno[$_programacion->id_excel_iie][$_programacion->tipo_prueba] = "No";
			}
		}
		
		//ACA INCLUIR RUTINA PARA ACTUALIZAR LOS CAMPOS: pasa_a_enero, rindio_en_diciembre, cumple_requisito, pcpg_regular, pcpg_complementaria, pcdd_regular, pcdd_complementaria 
		//tomar la formula de cumple o no desde el archivo Reportes.php.bak
		
		$csv = "RUN,CARRERA,EMAIL1, EMAIL2, PCPG, PCDD <br/>";
		foreach($arrAlumno as $codIie=>$alumnos){
				$csv.= $alumnos["rut"].",";
				$csv.= $alumnos["carrera"].",";
				$csv.= $alumnos["email1"].",";
				$csv.= $alumnos["email2"].",";
				$csv.= $alumnos["PCPG"].",";
				$csv.= $alumnos["PCDD"].",";
				$csv.= "<br>";
		}
		echo $csv;
	}
	
    public function listadoFinalFull(Request $request)
    {
		
		//https://www.diagnosticafid.cl/public/reportes/listado-final-full
		
		$file = DB::select(
		'
			SELECT 
					
					evaluado.id_excel_iie,
					nombre_institucion as "Institución",
					ri.numero_region as "Número Región Sede Institución",
					ri.nombre_region as "Nombre Región Sede Institución",
					cs.nombre_comuna as "Comuna Sede",        
					direccion_sede as "Dirección sede institución",
					nombre_sede as "Nombr Sede institución",
					evaluado.extra_nom_orig_carrera        as "Nombre original del programa o carrera",
					evaluado.extra_nivel_carrera        as "Nivel Carrera",
					evaluado.extra_asignatura        as "Asignatura (Pedagogía en Educación Media)",
					carrera as "Carrera oficial",
					dia_de_aplicacion as "Día Aplicación",
					evaluado.extra_prosecucion        as "Programa de prosecución de estudios",
					evaluado.extra_titulo_otorga        as "Título que otorga",
					evaluado.modalidad_estudio as "Modalidad 1 (Presencial)",
			
			CASE
			   WHEN  evaluado.modalidad_horario = 48   THEN \'Diurno\'
			   WHEN  evaluado.modalidad_horario = 49   THEN \'No Aplica\'
			   WHEN  evaluado.modalidad_horario = 50   THEN \'Vespertino\'
			 END 
			 AS "Modalidad 2 (Horario)",
			evaluado.anio_ingreso as "Año ingreso",
			CASE
			   WHEN  evaluado.id_genero = 46   THEN \'Femenino\'
			   WHEN  evaluado.id_genero = 47   THEN \'Masculino\'
			 END 
			 AS "Género",

					
					evaluado.nombres as "Nombres",
					evaluado.apellido_paterno as "Apellido paterno",
					evaluado.apellido_materno as "Apellido materno",
					evaluado.rut as "RUN",
					re.numero_region as "Número Región", 
					re.nombre_region as "Nombre Región Residencia",
					ce.nombre_comuna as "Comuna residencia",        
					evaluado.email1 as "mail1",
					evaluado.email2 as "Mail2",
					evaluado.telefono_fijo as "Teléfono",
					evaluado.telefono_movil as "Celular(9 dígitos)",
					evaluado.con_discapacidad as "Estudiante con discapacidad(indique en la siguiente columna qué tipo de discapacidad posee y que medios requiere para rendir la evaluación)",
					evaluado.medios_necesarios as "Discapacidad y medios necesarios para rendir la Evaluación",
					evaluado.rezagado as "Estudiante rezagado",
					evaluado.observaciones as "Observaciones (indicar cualquier otro elemento que considere relevante)",
					CASE
					   WHEN  evaluado.complementaria = true   THEN \'Sí\'
					   WHEN  evaluado.complementaria = false   THEN \'No\'
					 END 
					 AS "Segunda aplicación",
					CASE
					   WHEN  evaluado.pcpg_regular	 = true   THEN \'Sí\'
					   WHEN  evaluado.pcpg_regular	 = false   THEN \'No\'
					 END 
					 AS "Rindió PCPG Regular",
					CASE
					   WHEN  evaluado.pcdd_regular	 = true   THEN \'Sí\'
					   WHEN  evaluado.pcdd_regular	 = false   THEN \'No\'
					 END 
					 AS "Rindió PCDD Regular",
					CASE
					   WHEN  evaluado.pcpg_complementaria	 = true   THEN \'Sí\'
					   WHEN  evaluado.pcpg_complementaria	 = false   THEN \'No\'
					 END 
					 AS "Rindió PCPG Complementaria",					 
					CASE
					   WHEN  evaluado.pcdd_complementaria	 = true   THEN \'Sí\'
					   WHEN  evaluado.pcdd_complementaria	 = false   THEN \'No\'
					 END 
					 AS "Rindió PCDD Complementaria",
					CASE
					   WHEN  evaluado.cumple_requisito	 = true   THEN \'Sí\'
					   WHEN  evaluado.cumple_requisito	 = false   THEN \'No\'
					 END 
					 AS "Cumple",

					CASE
					WHEN  evaluado.rindio_en_diciembre = true 
						THEN (
							SELECT 
							dependencias.lab_cod_iie as id_iie
							FROM evaluadosaplicaciones, evaluados, aplicaciones, dependencias
							WHERE evaluadosaplicaciones.idevaluado  = evaluados.id
							AND evaluadosaplicaciones.idaplicacion =  aplicaciones.id
							AND dependencias.id = aplicaciones.dependencia_id
							AND evaluados.id_excel_iie = evaluado.id_excel_iie
							AND tiposaplicacion_id  = 60
							) 
					WHEN  evaluado.rindio_en_diciembre = false THEN -1 
					END 
					AS "laboratorio Id Regular",
					
					CASE
					WHEN  complementaria = true 
						THEN (
							SELECT 
							dependencias.lab_cod_iie as id_iie
							FROM evaluadosaplicaciones, evaluados, aplicaciones, dependencias
							WHERE evaluadosaplicaciones.idevaluado  = evaluados.id
							AND evaluadosaplicaciones.idaplicacion =  aplicaciones.id
							AND dependencias.id = aplicaciones.dependencia_id
							AND evaluados.id_excel_iie =  evaluado.id_excel_iie
							AND tiposaplicacion_id  = 62
							) 
						ELSE -1
					END 
					AS "laboratorio Id Complementaria",
					evaluado.es_nuevo	
					 
			FROM institucionestudios, 
			sedeinstitucion, comunas as cs, regiones as ri,
			evaluados as evaluado , comunas as ce, regiones as re,
			carreras

			WHERE evaluado.sedeinstitucion_id = sedeinstitucion.id
			AND sedeinstitucion.institucionestudios_id = institucionestudios.id
			AND evaluado.id_carrera = carreras.id_carrera
			AND ce.id = evaluado.id_comuna
			AND cs.id = sedeinstitucion.comuna_id
			AND ri.id = cs.region_id
			AND re.id = ce.region_id
			AND evaluado.borrado = false
			ORDER BY rut
			');



	// $file = DB::select(
	// '
		// SELECT 
				// evaluado.id_excel_iie as "Id Alumno",
				// evaluado.rut as "RUN",
				// evaluado.nombres as "Nombre",
				// evaluado.apellido_paterno as "Primer Apellido",
				// evaluado.apellido_materno as "Segundo Apellido",
				// evaluado.email1 as "Correo1",
				// evaluado.email2 as "Correo2",
				// evaluado.telefono_fijo as "Teléfono 1",
				// evaluado.telefono_movil as "Teléfono 2",
				// ri.numero_region as "Región institución",
				// cs.nombre_comuna as "Comuna",               
				// evaluado.anio_ingreso as "Año ingreso",
				// nombre_institucion as "Institución",
				// nombre_sede as "Sede",
				// carreras.carrera        as "Carrera",
				// evaluado.extra_prosecucion        as "Programa de prosecución de estudios",
				
				// CASE
				   // WHEN  evaluado.extra_prosecucion = true   THEN \'Sí\'
				   // WHEN  evaluado.extra_prosecucion = false   THEN \'No\'
				   
				 // END 
					// AS "Programa de prosecución de estudios",
					

				// CASE
				   // WHEN  (evaluado.rut in (\'15757686-0\',\'13969876-2\',\'14540795-8\',\'16650582-8\',\'12905151-5\',\'16364476-2\',\'18471137-0\',\'13345655-4\',\'17594183-5\',\'16918168-3\',\'18267272-6\',\'13026604-5\',\'17056473-1\',\'20344200-9\',\'18742356-2\',\'17056304-2\',\'15522985-3\',\'15304741-3\',\'17855801-3\',\'17418022-9\',\'16533717-4\',\'9250262-7\',\'16533856-1\',\'13826511-0\',\'17233558-6\',\'17127229-7\',\'15507945-2\',\'17495772-K\',\'18218078-5\',\'15968791-0\',\'17234383-K\',\'13410809-6\',\'15469877-9\',\'16151819-0\',\'16363940-8\',\'17595295-0\',\'17593203-8\') ) THEN \'Papel\'
				   // WHEN  (evaluado.rut not in (\'15757686-0\',\'13969876-2\',\'14540795-8\',\'16650582-8\',\'12905151-5\',\'16364476-2\',\'18471137-0\',\'13345655-4\',\'17594183-5\',\'16918168-3\',\'18267272-6\',\'13026604-5\',\'17056473-1\',\'20344200-9\',\'18742356-2\',\'17056304-2\',\'15522985-3\',\'15304741-3\',\'17855801-3\',\'17418022-9\',\'16533717-4\',\'9250262-7\',\'16533856-1\',\'13826511-0\',\'17233558-6\',\'17127229-7\',\'15507945-2\',\'17495772-K\',\'18218078-5\',\'15968791-0\',\'17234383-K\',\'13410809-6\',\'15469877-9\',\'16151819-0\',\'16363940-8\',\'17595295-0\',\'17593203-8\') ) THEN \'Digital\'

				 // END 
				 // AS "Medio de Respuesta",
				// CASE
				   // WHEN  evaluado.modalidad_estudio = 51   THEN \'No presencial\'
				   // WHEN  evaluado.modalidad_estudio = 52   THEN \'Presencial\'
				   // WHEN  evaluado.modalidad_estudio = 53   THEN \'Semipresencial\'					   
				   
				 // END 
					// AS "Modalidad_estudio",
				 
				 // /*
				// CASE
				  // WHEN  (evaluado.pasa_a_enero = true ) THEN \'Posible Rezagado\'
				  // WHEN  (evaluado.rindio_en_diciembre = true and evaluado.pcpg_regular = true and evaluado.pcdd_regular = true )   THEN \'Evaluación finalizada\'  
				  // WHEN  (evaluado.pasa_a_enero = false ) THEN \'Evaluación finalizada\'
				// END 
				// AS "Estado Aplicación Dic 2018",

				// CASE
				  // WHEN  (evaluado.complementaria = false)  THEN \'No inscrito\'
				  // WHEN  (evaluado.complementaria = true and (evaluado.pcpg_complementaria = false or evaluado.pcdd_complementaria = false))  THEN  \'Inscrito\'
				  // WHEN  (evaluado.complementaria = true and evaluado.pcpg_complementaria = true and evaluado.pcdd_complementaria = true )   THEN \'Evaluación finalizada\'
				   
				// END 
				// AS "Estado Aplicación Ene 2019",
				// */
				// CASE
				   // WHEN  (evaluado.cumple_requisito = true )   THEN \'Cumple requisito\'
				   // WHEN  (evaluado.cumple_requisito = false)   THEN \'No Cumple requisito\'
				 // END 
				 // AS "Estado final END FID"

				 
		// FROM institucionestudios, 
		// sedeinstitucion, comunas as cs, regiones as ri,
		// evaluados as evaluado , comunas as ce, regiones as re,
		// carreras

		// WHERE evaluado.sedeinstitucion_id = sedeinstitucion.id
		// AND sedeinstitucion.institucionestudios_id = institucionestudios.id
		// AND evaluado.id_carrera = carreras.id_carrera
		// AND ce.id = evaluado.id_comuna
		// AND cs.id = sedeinstitucion.comuna_id
		// AND ri.id = cs.region_id
		// AND re.id = ce.region_id
		// AND evaluado.borrado = false
		// AND evaluado.cumple_requisito = true
		// ORDER BY rut
		
		// ');			
			
		//$res = json_encode($file);
			
		$array = json_decode(json_encode($file), true);			

		//$fileName = "planillaFullAlumnos-".date("Y-m-d_H_i_s");
		//echo $fileName;	exit;
		
		$table = arrayToTable($array);
		echo $table;
		
		
		//$path = app_path('Http/Controllers/')."IIE/datos_txt/respuestas/";
		//$fp = fopen($path.$fileName.".html", 'w');
		//if(fwrite($fp, utf8_decode($t))){
			// $file_url = $path.$fileName;				
			// $header[] = "Cache-Control: no-store, no-cache, must-revalidate, max-age=0";
			// $header[] = "Cache-Control: post-check=0, pre-check=0";
			// $header[] = "Pragma: no-cache";
			// return response()->file($file_url, $header);
		//}
		//fclose($fp);
		// header("Content-type: application/vnd.ms-excel;");
		// header("Content-Disposition: attachment; filename=".$fileName);
		// header("Pragma: no-cache");
		// header("Expires: 0");
		//echo utf8_decode($t);	
	}	
	
	
	
	
	/*
		LISTA YENIFFER
		$file = DB::select(
		'
			SELECT 
					evaluado.id_excel_iie as "Id Alumno",
					evaluado.rut as "RUN",
					evaluado.nombres as "Nombres",
					evaluado.apellido_paterno as "Apellido paterno",
					evaluado.apellido_materno as "Apellido materno",
					evaluado.email1 as "Mail1",
					evaluado.email2 as "Mail2",
					evaluado.telefono_fijo as "Teléfono",
					evaluado.telefono_movil as "Celular(9 dígitos)",
					ri.nombre_region as "Nombre Región Sede Institución",
					cs.nombre_comuna as "Comuna",               
					evaluado.anio_ingreso as "Año ingreso",
					nombre_institucion as "Institución",
					nombre_sede as "Nombre Sede institución",
					
					CASE
					   WHEN  (evaluado.pasa_a_enero = true ) THEN \'Posible Rezagado\'
					   WHEN  (evaluado.rindio_en_diciembre = true and evaluado.pcpg_regular = true and evaluado.pcdd_regular = true )   THEN \'Evaluación finalizada\'  
					   WHEN  (evaluado.pasa_a_enero = false ) THEN \'Evaluación finalizada\'
					 END 
					 AS "Estado Aplicación Dic 2018",

					CASE
					   WHEN  (evaluado.complementaria = false)  THEN \'No inscrito\'
					   WHEN  (evaluado.complementaria = true and (evaluado.pcpg_complementaria = false or evaluado.pcdd_complementaria = false))  THEN  \'Inscrito\'
					   WHEN  (evaluado.complementaria = true and evaluado.pcpg_complementaria = true and evaluado.pcdd_complementaria = true )   THEN \'Evaluación finalizada\'
					   
					 END 
					 AS "Estado Aplicación Ene 2019",

					CASE
					   WHEN  (evaluado.cumple_requisito = true )   THEN \'Cumple requisito\'
					   WHEN  (evaluado.cumple_requisito = false)   THEN \'No Cumple requisito\'
					 END 
					 AS "Estado final END FID"

					 
			FROM institucionestudios, 
			sedeinstitucion, comunas as cs, regiones as ri,
			evaluados as evaluado , comunas as ce, regiones as re,
			carreras

			WHERE evaluado.sedeinstitucion_id = sedeinstitucion.id
			AND sedeinstitucion.institucionestudios_id = institucionestudios.id
			AND evaluado.id_carrera = carreras.id_carrera
			AND ce.id = evaluado.id_comuna
			AND cs.id = sedeinstitucion.comuna_id
			AND ri.id = cs.region_id
			AND re.id = ce.region_id
			AND evaluado.borrado = false
			
			ORDER BY rut
			
			');
			
			
		$array = json_decode(json_encode($file), true);			

		$fileName = "planillaFullAlumnos-".date("Y-m-d_H_i_s");
		
		$table = arrayToTable($array);
		echo $table;
		exit;	
	*/
	



}
function php_correlation($x,$y){
    if(count($x)!==count($y)){return -1;}   
    $x=array_values($x);
    $y=array_values($y);    
    $xs=array_sum($x)/count($x);
    $ys=array_sum($y)/count($y);    
    $a=0;$bx=0;$by=0;
    for($i=0;$i<count($x);$i++){     
        $xr=$x[$i]-$xs;
        $yr=$y[$i]-$ys;     
        $a+=$xr*$yr;        
        $bx+=pow($xr,2);
        $by+=pow($yr,2);
    }   
    $b = sqrt($bx*$by);
    if($b==0) return 0;
    return $a/$b;
}


function pearson_correlation($x,$y){
    if(count($x)!==count($y)){return -1;}   
    $x=array_values($x);
    $y=array_values($y);    
    $xs=array_sum($x)/count($x);
    $ys=array_sum($y)/count($y);    
    $a=0;$bx=0;$by=0;
    for($i=0;$i<count($x);$i++){     
        $xr=$x[$i]-$xs;
        $yr=$y[$i]-$ys;     
        $a+=$xr*$yr;        
        $bx+=pow($xr,2);
        $by+=pow($yr,2);
    }   
    $b = sqrt($bx*$by);
    return $a/$b;
}

function get_percentile($percentile, $array) {
	sort($array);
	$index = ($percentile/100) * count($array);
	if (floor($index) == $index) {
		 $result = ($array[$index-1] + $array[$index])/2;
	}
	else {
		$result = $array[floor($index)];
	}
	return $result;
}