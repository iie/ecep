<?php
namespace App\Http\Controllers\IIE;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Carrera;
use App\Models\Aplicaciones;
use App\Models\Prueba;
use App\Models\EvaluadosAplicaciones;
use App\Models\EstudianteListado;
use App\Models\Reporte\Asistencia;
use App\Models\LimePregunta;
use App\Models\LimeRespuesta;
use App\Models\CentroInstitucion;
use App\Models\CentroAplicacion;
use App\Models\Dependencias;


use App\Models\CLimeReporteInstitucional;
use App\Models\CLimeReporteInstitucionalEstandar;
use App\Models\CLimeReporteInstitucionalTema;
use App\Models\CLimeResultadoInstitucion;



use Illuminate\Support\Facades\DB;

class CReportes extends Controller
{
	 
	public function __construct()
    {
		$this->fields = array();	
    }	

	
	public function calculaPuntajes2018(){
		
		//calcula los promedios, minima, maxima
		
		//https://www.diagnosticafid.cl/public/c-calcula-puntajes-2018
		
		$sql = "

			SELECT evaluados.rut, evaluados.sedeinstitucion_id as id_institucion, evaluados.id_carrera, tipo_prueba, puntaje , lime_tendencia.modalidad_estudio as extra_prosecucion	
			FROM lime_tendencia, 
			evaluados, institucionestudios, sedeinstitucion
			where anio = 2018 
			and lime_tendencia.rut = evaluados.rut
			and institucionestudios.id = sedeinstitucion.institucionestudios_id
			and evaluados.sedeinstitucion_id = sedeinstitucion.id
			
		";
		
		//organizamos la info
		$ptje = DB::select($sql);		
		foreach($ptje as $ptjeAux){
			if($ptjeAux->extra_prosecucion=='prosecucion'){
				$extraProsecucion = 'prosecucion';	
			}
			else{
				$extraProsecucion = 'regular';	
			}
			
			//institucion/carrera/tipo_prueba/modalidad
			@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba][$extraProsecucion]["sum"]+= $ptjeAux->puntaje;
			@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba][$extraProsecucion]["ctd"]++;
			$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba][$extraProsecucion]["todos"][] = $ptjeAux->puntaje;

			//institucion/carrera/tipo_prueba
			@$resICT[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba]["sum"]+= $ptjeAux->puntaje;
			@$resICT[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba]["ctd"]++;
			$resICT[$ptjeAux->id_institucion][$ptjeAux->id_carrera][$ptjeAux->tipo_prueba]["todos"][] = $ptjeAux->puntaje	;
			
		}
		
		//calculamos
		foreach($res as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$tipo_pruebas){
				foreach($tipo_pruebas as $tipo_prueba=>$modEst){
					$resICT[$id_institucion][$id_carrera][$tipo_prueba]["promedio"] = $resICT[$id_institucion][$id_carrera][$tipo_prueba]["sum"]/$resICT[$id_institucion][$id_carrera][$tipo_prueba]["ctd"];
					foreach($modEst as $mEst=>$datos){
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["promedio"] =  $res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["sum"]/$res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["ctd"];
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["min"] =  min($res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["max"] =  max($res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["mediana"] =  get_percentile(50,$res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["perce25"] =  get_percentile(25,$res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
						$resOrg[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["perce75"] =  get_percentile(75,$res[$id_institucion][$id_carrera][$tipo_prueba][$mEst]["todos"]);
					}
				}	
			}
		}
		
		//grabamos en DB
		foreach($resOrg as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$tipo_pruebas){
				foreach($tipo_pruebas as $tipo_prueba=>$modEst){
					$limeReporteInstitucional = CLimeReporteInstitucional::where("id_sede",$id_institucion)->where("id_carrera",$id_carrera)->where("tipo_prueba", strtoupper($tipo_prueba))->first();					
					if(isset($limeReporteInstitucional->id_reporte_institucional)){
						$limeReporteInstitucional->promedio = $resICT[$id_institucion][$id_carrera][$tipo_prueba]["promedio"];
						$limeReporteInstitucional->save();
			
						foreach($modEst as $mEst=>$datos){
							//grabamos en tabla lime_resultado_institucion
							$limeResultadoInstitucion = CLimeResultadoInstitucion::where("id_reporte_institucional",$limeReporteInstitucional->id_reporte_institucional)->where("modo_estudio", $mEst)->first();
							//if(isset($limeResultadoInstitucion->id_reporte_institucional)){
								//$limeResultadoInstitucion->modo_estudio = $mEst;
								$limeResultadoInstitucion->prom = $datos["promedio"];
								$limeResultadoInstitucion->min = $datos["min"];
								$limeResultadoInstitucion->max = $datos["max"];
								$limeResultadoInstitucion->mediana = $datos["mediana"];
								//$limeResultadoInstitucion->perce25 = $datos["perce25"];
								//$limeResultadoInstitucion->perce75 = $datos["perce75"];
								$limeResultadoInstitucion->save();
								
							//}
						}						
					}
					else{
						//"revisar porque entra acá";
					}
				}	
			}
		}
	}

/*
		
	public function calculaPuntajes2017(){
		
		//calcula los promedios, minima, maxima y los ingresa a la tabla lime_reporte_institucional
		
		//https://www.diagnosticafid.cl/public/calcula-puntajes-2017
		
		$sql = "
			select id_institucion, lime_puntaje_individual_2017.id_carrera as id_carrera, pcpg, pcdd
			from carreras, institucionestudios, lime_puntaje_individual_2017
			where lime_puntaje_individual_2017.id_institucion = institucionestudios.id
			and lime_puntaje_individual_2017.id_carrera = carreras.id_carrera
			
		";
		
		$ptje = DB::select($sql);		
		foreach($ptje as $ptjeAux){
			@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera]["pcpg"]["sum"]+= $ptjeAux->pcpg;
			@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera]["pcpg"]["ctd"]++;
			@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera]["pcdd"]["sum"]+= $ptjeAux->pcdd;
			@$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera]["pcdd"]["ctd"]++;
			//todos
			$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera]["pcpg"]["todos"][] = $ptjeAux->pcpg;
			$res[$ptjeAux->id_institucion][$ptjeAux->id_carrera]["pcdd"]["todos"][] = $ptjeAux->pcdd;
		}
		
		foreach($res as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$tipo_pruebas){
				foreach($tipo_pruebas as $tipo_prueba=>$datos){
					$resOrg[$id_institucion][$id_carrera][$tipo_prueba]["promedio"] =  $res[$id_institucion][$id_carrera][$tipo_prueba]["sum"]/$res[$id_institucion][$id_carrera][$tipo_prueba]["ctd"];
					$resOrg[$id_institucion][$id_carrera][$tipo_prueba]["min"] =  min($res[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
					$resOrg[$id_institucion][$id_carrera][$tipo_prueba]["max"] =  max($res[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
					$resOrg[$id_institucion][$id_carrera][$tipo_prueba]["mediana"] =  get_percentile(50,$res[$id_institucion][$id_carrera][$tipo_prueba]["todos"]);
					
				}	
			}
		}
		
		foreach($resOrg as $id_institucion=>$carreras){
			foreach($carreras as $id_carrera=>$tipo_pruebas){
				foreach($tipo_pruebas as $tipo_prueba=>$datos){
					$limeReporteInstitucional = LimeReporteInstitucional::where("id_institucion",$id_institucion)->where("id_carrera", $id_carrera)->where("tipo_prueba", strtoupper($tipo_prueba))->first();					
					if(isset($limeReporteInstitucional->id_reporte_institucional)){
						//if($tipo_prueba=='pcpg'){
							$limeReporteInstitucional->promedio2017 = $datos["promedio"];	
						//}
						//else{
						//	$limeReporteInstitucional->promedio2017 = $datos["promedio"];		
						//}
						$limeReporteInstitucional->save();
					}
					else{
						//echo "no existe	".$id_institucion." ".$id_carrera." ".$tipo_prueba."<br/>"; 
					}
				}	
			}
		}
	}
*/	
	
	public function reporteInstitucional(){
		
		//https://www.diagnosticafid.cl/public/c-reporte-institucional
		
		/*
		delete from lime_reporte_ins	titucional_tema;
		delete from lime_reporte_institucional_estandar;
		delete from lime_resultado_institucion;
		delete from lime_reporte_institucional;
		*/
		// DB::select("delete from lime_reporte_institucional_tema");
		// DB::select("delete from lime_reporte_institucional_estandar");
		// DB::select("delete from lime_resultado_institucion");
		// DB::select("delete from lime_reporte_institucional");
			
		$sql = "
			select sedeinstitucion_id as id_sede, evaluados.id_carrera, id_excel_iie, pruebas.tipo_prueba, extra_prosecucion
			from evaluados, carreras, carrera_prueba, pruebas, institucionestudios, sedeinstitucion
			where evaluados.id_carrera = carreras.id_carrera 
			and carrera_prueba.id_carrera  = carreras.id_carrera 
			and carrera_prueba.id_prueba = pruebas.id
			and codigo_prueba not in (563156)
			and evaluados.cumple_requisito = true
			and evaluados.sedeinstitucion_id = sedeinstitucion.id
			and institucionestudios.id = sedeinstitucion.institucionestudios_id
			ORDER BY institucionestudios.nombre_institucion desc, carreras.carrera, rut asc
		";
		
									
		$listadoCompleto = DB::select($sql);		
		
		//porcentaje de logro por tema
		$pLogroTema = DB::select("
								select cod_iie, tipo_prueba, id_tema, porcentaje 
								from lime_porcentaje_logro_tema, lime_tema , pruebas 
								where lime_porcentaje_logro_tema.id_tema = lime_tema.id_lime_tema
								and lime_tema.id_prueba = pruebas.id order by cod_iie asc, tipo_prueba , nro_tema 
									");		
									
		foreach($pLogroTema as $pLogroTemaAux){
			$pLT[$pLogroTemaAux->cod_iie][$pLogroTemaAux->tipo_prueba][$pLogroTemaAux->id_tema] = $pLogroTemaAux->porcentaje;	
		}
		
		//porcentaje de logro por estandar
		$pLogroEstandar = DB::select("
								select cod_iie, tipo_prueba, id_estandar, porcentaje 
								from lime_porcentaje_logro_estandar, lime_estandar , pruebas 
								where lime_porcentaje_logro_estandar.id_estandar = lime_estandar.id_lime_estandar
								and lime_estandar.id_prueba = pruebas.id order by cod_iie desc, tipo_prueba , nro_estandar 
									");	
									
		foreach($pLogroEstandar as $pLogroTemaAux){
			$pL[$pLogroTemaAux->cod_iie][$pLogroTemaAux->tipo_prueba][$pLogroTemaAux->id_estandar] = $pLogroTemaAux->porcentaje;	
		}
		
		$totalProsecucion = array();
		$totalRegular = array();
		

		foreach($listadoCompleto as $listadoCompletoAux){
			$extraProsecucion = ($listadoCompletoAux->extra_prosecucion==true)?'prosecucion':'regular';
			$listadoCompletoAux = $listadoCompletoAux ;
			// if(!array_key_exists($listadoCompletoAux->tipo_prueba,$pL[$listadoCompletoAux->id_excel_iie])){
				// echo $listadoCompletoAux->id_excel_iie;
				// arreglo($pL[$listadoCompletoAux->id_excel_iie]);
				// exit;
			// }
			$resOrg[$listadoCompletoAux->id_sede][$listadoCompletoAux->id_carrera][$listadoCompletoAux->tipo_prueba][$extraProsecucion]["estandar"][] = $pL[$listadoCompletoAux->id_excel_iie][$listadoCompletoAux->tipo_prueba];
			$resOrg[$listadoCompletoAux->id_sede][$listadoCompletoAux->id_carrera][$listadoCompletoAux->tipo_prueba][$extraProsecucion]["tema"][] = $pLT[$listadoCompletoAux->id_excel_iie][$listadoCompletoAux->tipo_prueba];
		}
		
		foreach($resOrg as $institucion =>$instituciones){
			foreach($instituciones as $carrera=>$carreras){
				foreach($carreras as $tipoPrueba=>$modEstudios){
					foreach($modEstudios as $modEstudio=>$tipoPuntajes){
						foreach($tipoPuntajes as $tipoPuntaje=>$alumnosAux){
							foreach($alumnosAux as $alumnos){
								foreach($alumnos as $numero => $puntajes){
									$porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero][] = $puntajes;
									@$totalPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["total"]++;
									@$sumaPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["suma"]+= $puntajes;
								}
							}	
						}
					}
				}
			}
		}
		
		//sacamos promedio y otros calculos
		foreach($resOrg as $institucion =>$instituciones){
			foreach($instituciones as $carrera=>$carreras){
				foreach($carreras as $tipoPrueba=>$modEstudios){
					foreach($modEstudios as $modEstudio=>$tipoPuntajes){
						foreach($tipoPuntajes as $tipoPuntaje=>$alumnosAux){
							foreach($alumnosAux as $alumnos){
								foreach($alumnos as $numero => $puntajes){
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['promedio'] = $sumaPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["suma"]/$totalPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["total"];
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['minimo'] = min($porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['maximo'] = max($porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['mediana'] = get_percentile(50, $porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['perce25'] = get_percentile(25, $porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['perce75'] = get_percentile(75, $porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
								}
							}
						}
					}
				}
			}
		}

		// $path = app_path('Http/Controllers/')."IIE/datos_txt/monitoreo/";
		// $archivo = "ptje.txt";
		// @unlink($path.$archivo);
		// $fp = fopen($path.$archivo, 'w+');
		$sqlAux = '';
		foreach($Xnumero as $institucion =>$instituciones){
			foreach($instituciones as $carrera=>$carreras){
				foreach($carreras as $tipoPrueba=>$modEstudios){
					
					$reporteInstitucional = CLimeReporteInstitucional::where("id_sede", $institucion)->where("id_carrera", $carrera)->where("tipo_prueba", $tipoPrueba)->first();			
					if(!isset($reporteInstitucional->id_reporte_institucional)){
						$reporteInstitucional = new CLimeReporteInstitucional();				
					}
					$reporteInstitucional->id_sede = $institucion;
					$reporteInstitucional->id_carrera = $carrera;
					$reporteInstitucional->tipo_prueba = $tipoPrueba;
					$reporteInstitucional->save();
					//$sqlAux.= "insert into lime_reporte_institucional (id_institucion, id_carrera, tipo_prueba) values (".$institucion.", ".$carrera.", '".$tipoPrueba."');\n";
					
					foreach($modEstudios as $modEstudio=>$alumnos){
						$LimeResultadoInstitucion = CLimeResultadoInstitucion::where("id_reporte_institucional", $reporteInstitucional->id_reporte_institucional)->where("modo_estudio", $modEstudio)->first();			
						if(!isset($LimeResultadoInstitucion->id_resultado_institucion)){
							$LimeResultadoInstitucion = new CLimeResultadoInstitucion();			
						}
						$LimeResultadoInstitucion->id_reporte_institucional	 = $reporteInstitucional->id_reporte_institucional;	
						$LimeResultadoInstitucion->modo_estudio	= $modEstudio;
						$LimeResultadoInstitucion->save();

						
						foreach($alumnos as $tipoPuntaje=>$resultados){
							foreach($resultados as $numeroTema=>$tema){
								if($tipoPuntaje=='estandar'){
									$limeReporteInstitucionalEstandar = CLimeReporteInstitucionalEstandar::where("id_resultado_institucion", $LimeResultadoInstitucion->id_resultado_institucion)->where("id_estandar", $numeroTema)->first();			
									if(!isset($limeReporteInstitucionalEstandar->id_reporte_institucional_estandar)){
										$limeReporteInstitucionalEstandar = new CLimeReporteInstitucionalEstandar();	
									}
									$limeReporteInstitucionalEstandar->id_resultado_institucion	= $LimeResultadoInstitucion->id_resultado_institucion;
									$limeReporteInstitucionalEstandar->id_estandar = $numeroTema;
									
									$limeReporteInstitucionalEstandar->prom	 = $tema["promedio"];
									$limeReporteInstitucionalEstandar->min	 = $tema["minimo"];
									$limeReporteInstitucionalEstandar->max	 = $tema["maximo"];
									$limeReporteInstitucionalEstandar->mediana	 = $tema["mediana"];
									$limeReporteInstitucionalEstandar->perce25	 = $tema["perce25"];
									$limeReporteInstitucionalEstandar->perce75	 = $tema["perce75"];
									
									$limeReporteInstitucionalEstandar->save();
								}
								else{
									$limeReporteInstitucionalTema = CLimeReporteInstitucionalTema::where("id_resultado_institucion", $LimeResultadoInstitucion->id_resultado_institucion)->where("id_tema", $numeroTema)->first();			
									if(!isset($limeReporteInstitucionalTema->id_reporte_institucional_tema)){
										$limeReporteInstitucionalTema = new CLimeReporteInstitucionalTema();	
									}
									
									$limeReporteInstitucionalTema->id_resultado_institucion	= $LimeResultadoInstitucion->id_resultado_institucion;
									$limeReporteInstitucionalTema->prom	 = $tema["promedio"];
									$limeReporteInstitucionalTema->min	 = $tema["minimo"];
									$limeReporteInstitucionalTema->max	 = $tema["maximo"];
									$limeReporteInstitucionalTema->mediana	 = $tema["mediana"];
									$limeReporteInstitucionalTema->perce25	 = $tema["perce25"];
									$limeReporteInstitucionalTema->perce75	 = $tema["perce75"];
									$limeReporteInstitucionalTema->id_tema = $numeroTema;
									$limeReporteInstitucionalTema->save();
								}							
							}
						}
					}
				}
			}
		}
		
		// fwrite($fp, $sqlAux);
		// fclose($fp);				
		// $comando  = 'PGPASSWORD=k1LL2018 psql -h 162.216.18.16 -d endfid -U postgres -p 5432 -a -q -f /home/diag2018fid/public_html/app/Http/Controllers/IIE/datos_txt/monitoreo/'.$archivo;
		// echo $comando;

	}
	
	public function reporteInstitucional_no_usar(){

		//https://www.diagnosticafid.cl/public/c-reporte-institucional
		
		/*
		id_institucion
		id_carrera
		id_tipo_prueba
		cumple_requisito
		regular
		prosecucion
		res_anio_anterior
		variacion_anio_anterior
		signif_1
		numtema_max_porcentaje_r
		numtema_min_porcentaje_r
		numtema_max_porcentaje_p
		numtema_min_porcentaje_p
		tema_maxdisp
		tema_max_disp_r
		tema_max_disp_p
		*/

		/*
		delete from lime_reporte_institucional_tema;
		delete from lime_reporte_institucional_estandar;
		delete from lime_resultado_institucion;
		delete from lime_reporte_institucional;
		*/
		//DB::select("delete from lime_reporte_institucional_tema");
		//DB::select("delete from lime_reporte_institucional_estandar");
		//DB::select("delete from lime_resultado_institucion");
		//DB::select("delete from lime_reporte_institucional");
			
		$sql = "
			select institucionestudios.id as id_institucion, sedeinstitucion_id as id_sede, evaluados.id_carrera, id_excel_iie, rut, pruebas.tipo_prueba, pruebas.nombre_corto, cumple_requisito, extra_prosecucion
			from evaluados, carreras, carrera_prueba, pruebas, institucionestudios, sedeinstitucion
			where evaluados.id_carrera = carreras.id_carrera 
			and carrera_prueba.id_carrera  = carreras.id_carrera 
			and carrera_prueba.id_prueba = pruebas.id
			and codigo_prueba not in (563156)
			and evaluados.cumple_requisito = true
			and evaluados.sedeinstitucion_id = sedeinstitucion.id
			and institucionestudios.id = sedeinstitucion.institucionestudios_id
			ORDER BY institucionestudios.nombre_institucion, carreras.carrera, rut
		";
		
									
		$listadoCompleto = DB::select($sql);		
		
		//porcentaje de logro por tema
		$pLogroTema = DB::select("
								select cod_iie, tipo_prueba, id_tema, porcentaje 
								from lime_porcentaje_logro, lime_tema , pruebas 
								where lime_porcentaje_logro.id_tema = lime_tema.id_lime_tema
								and lime_tema.id_prueba = pruebas.id order by cod_iie, tipo_prueba , nro_tema 
									");		
									
		foreach($pLogroTema as $pLogroTemaAux){
			$pLT[$pLogroTemaAux->cod_iie][$pLogroTemaAux->tipo_prueba][$pLogroTemaAux->id_tema] = $pLogroTemaAux->porcentaje;	
		}
		
		//porcentaje de logro por estandar
		$pLogroEstandar = DB::select("
								select cod_iie, tipo_prueba, id_estandar, porcentaje 
								from lime_porcentaje_logro_estandar, lime_estandar , pruebas 
								where lime_porcentaje_logro_estandar.id_estandar = lime_estandar.id_lime_estandar
								and lime_estandar.id_prueba = pruebas.id order by cod_iie, tipo_prueba , nro_estandar 
									");	
									
		foreach($pLogroEstandar as $pLogroTemaAux){
			$pL[$pLogroTemaAux->cod_iie][$pLogroTemaAux->tipo_prueba][$pLogroTemaAux->id_estandar] = $pLogroTemaAux->porcentaje;	
		}
		
		$totalProsecucion = array();
		$totalRegular = array();
		

		foreach($listadoCompleto as $listadoCompletoAux){
			$extraProsecucion = ($listadoCompletoAux->extra_prosecucion==true)?'prosecucion':'regular';
			$listadoCompletoAux = $listadoCompletoAux ;
			$resOrg[$listadoCompletoAux->id_institucion][$listadoCompletoAux->id_sede][$listadoCompletoAux->tipo_prueba][$extraProsecucion]["estandar"][] = $pL[$listadoCompletoAux->id_excel_iie][$listadoCompletoAux->tipo_prueba];
			$resOrg[$listadoCompletoAux->id_institucion][$listadoCompletoAux->id_sede][$listadoCompletoAux->tipo_prueba][$extraProsecucion]["tema"][] = $pLT[$listadoCompletoAux->id_excel_iie][$listadoCompletoAux->tipo_prueba];
			// //totales
			// if($listadoCompletoAux->cumple_requisito==1){
				// @$totalCumple[$listadoCompletoAux->id_institucion][$listadoCompletoAux->id_carrera][$listadoCompletoAux->tipo_prueba]++;	
			// }
			// if($listadoCompletoAux->extra_prosecucion==true){
				// @$totalProsecucion[$listadoCompletoAux->id_institucion][$listadoCompletoAux->id_carrera][$listadoCompletoAux->tipo_prueba]++;	
			// }
			// else{
				// @$totalRegular[$listadoCompletoAux->id_institucion][$listadoCompletoAux->id_carrera][$listadoCompletoAux->tipo_prueba]++;	
			// }
		}
		
		foreach($resOrg as $institucion =>$instituciones){
			foreach($instituciones as $carrera=>$carreras){
				foreach($carreras as $tipoPrueba=>$modEstudios){
					foreach($modEstudios as $modEstudio=>$tipoPuntajes){
						foreach($tipoPuntajes as $tipoPuntaje=>$alumnosAux){
							foreach($alumnosAux as $alumnos){
								foreach($alumnos as $numero => $puntajes){
									$porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero][] = $puntajes;
									@$totalPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["total"]++;
									@$sumaPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["suma"]+= $puntajes;
								}
							}	
						}
					}
				}
			}
		}
		
		//sacamos promedio y otros calculos
		foreach($resOrg as $institucion =>$instituciones){
			foreach($instituciones as $carrera=>$carreras){
				foreach($carreras as $tipoPrueba=>$modEstudios){
					foreach($modEstudios as $modEstudio=>$tipoPuntajes){
						foreach($tipoPuntajes as $tipoPuntaje=>$alumnosAux){
							foreach($alumnosAux as $alumnos){
								foreach($alumnos as $numero => $puntajes){
									//if(!array_key_exists($numero,$sumaPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje])){
										// echo $institucion."<br/>";
										// echo $carrera."<br/>";
										// echo $tipoPrueba."<br/>";
										// echo $modEstudio."<br/>";
										// echo $tipoPuntaje."<br/>";
										//arreglo($sumaPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje]);
										//exit;
									//}
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['promedio'] = $sumaPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["suma"]/$totalPorNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]["total"];
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['minimo'] = min($porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['maximo'] = max($porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['mediana'] = get_percentile(50, $porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['perce25'] = get_percentile(25, $porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
									$Xnumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]['perce75'] = get_percentile(75, $porNumero[$institucion][$carrera][$tipoPrueba][$modEstudio][$tipoPuntaje][$numero]);
								}
							}
						}
					}
				}
			}
		}
		
		foreach($Xnumero as $institucion =>$instituciones){
			foreach($instituciones as $carrera=>$carreras){
				foreach($carreras as $tipoPrueba=>$modEstudios){
					$reporteInstitucional = new CLimeReporteInstitucional();			
					//$reporteInstitucional->id_institucion = $institucion;
					$reporteInstitucional->id_sede = $carrera;
					$reporteInstitucional->tipo_prueba = $tipoPrueba;
					$reporteInstitucional->save();
					
					foreach($modEstudios as $modEstudio=>$alumnos){
						$LimeResultadoInstitucion = new CLimeResultadoInstitucion();			
						$LimeResultadoInstitucion->id_reporte_institucional	 = $reporteInstitucional->id_reporte_institucional;	
						$LimeResultadoInstitucion->modo_estudio	= $modEstudio;
						$LimeResultadoInstitucion->save();
						
						foreach($alumnos as $tipoPuntaje=>$resultados){
							foreach($resultados as $numeroTema=>$tema){
								if($tipoPuntaje=='estandar'){
									$limeReporteInstitucionalEstandar = new CLimeReporteInstitucionalEstandar();
									$limeReporteInstitucionalEstandar->id_resultado_institucion	= $LimeResultadoInstitucion->id_resultado_institucion;
									$limeReporteInstitucionalEstandar->prom	 = $tema["promedio"];
									$limeReporteInstitucionalEstandar->min	 = $tema["minimo"];
									$limeReporteInstitucionalEstandar->max	 = $tema["maximo"];
									
									$limeReporteInstitucionalEstandar->mediana	 = $tema["mediana"];
									$limeReporteInstitucionalEstandar->perce25	 = $tema["perce25"];
									$limeReporteInstitucionalEstandar->perce75	 = $tema["perce75"];
									
									$limeReporteInstitucionalEstandar->id_estandar = $numeroTema;
									$limeReporteInstitucionalEstandar->save();
								}
								else{
									$limeReporteInstitucionalTema = new CLimeReporteInstitucionalTema();
									$limeReporteInstitucionalTema->id_resultado_institucion	= $LimeResultadoInstitucion->id_resultado_institucion;
									$limeReporteInstitucionalTema->prom	 = $tema["promedio"];
									$limeReporteInstitucionalTema->min	 = $tema["minimo"];
									$limeReporteInstitucionalTema->max	 = $tema["maximo"];
									
									$limeReporteInstitucionalTema->mediana	 = $tema["mediana"];
									$limeReporteInstitucionalTema->perce25	 = $tema["perce25"];
									$limeReporteInstitucionalTema->perce75	 = $tema["perce75"];
									
									$limeReporteInstitucionalTema->id_tema = $numeroTema;
									$limeReporteInstitucionalTema->save();
								}							
							}

						}
					}
				}
			}
		}
	}
}
	function get_percentile($percentile, $array) {
		sort($array);
		$index = ($percentile/100) * count($array);
		if (floor($index) == $index) {
			 $result = ($array[$index-1] + $array[$index])/2;
		}
		else {
			$result = $array[floor($index)];
		}
		return $result;
	}