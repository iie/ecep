<?php
namespace App\Http\Controllers\IIE;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Prueba;
use App\Models\monitoreos;
use App\Models\Evaluado;
use Illuminate\Support\Facades\DB;

class Monitoreo extends Controller
{
	 
	public function __construct()
    {
		$this->fields = array();	
    }	
	
	function get_content($url)
	{
		$ch = curl_init();

		curl_setopt ($ch, CURLOPT_URL, $url);
		curl_setopt ($ch, CURLOPT_HEADER, 0);

		ob_start();

		curl_exec ($ch);
		curl_close ($ch);
		$string = ob_get_contents();

		ob_end_clean();
	   
		return $string;    
	}	
	

	// public function guardarCuestionario($prueba, $momento, $column, $tipo)
    // {
		
		// $contenido = array();
		// foreach($prueba as $pruebas){
			// $contenido = array();

			// //resumen
			// $fecha = monitoreos::where('fecha_'.$momento.'_cuestionario','!=',NULL)->max('fecha_'.$momento.'_cuestionario');
			// if(!$fecha){
				// $gestor = $this->get_content('http://cw01.iie.cl/lsinicia/evaluacion/inws/'.$tipo.'.php?ssid='.$pruebas.'&date=hola', "r");
			// }else{
				// $gestor = $this->get_content('http://cw01.iie.cl/lsinicia/evaluacion/inws/'.$tipo.'.php?ssid='.$pruebas.'&date='.$fecha, "r");
			// }

			// if($gestor!=""){
				// $contenido[$pruebas]["ssid"] = $pruebas;
				// $contenido[$pruebas]["resumen"] = json_decode($gestor,1);	
				// $cAux[] = $contenido;
			// }
		// }
		// if(isset($cAux)){
			// DB::beginTransaction();
			// try{
				// foreach($cAux as $contenido){
					// foreach ($contenido as $contenido_prueba) {
						// foreach ($contenido_prueba["resumen"] as $data) {
							// echo 'fecha_'.$momento.'_cuestionario'.$data[$column].'<br>';
							// monitoreos::where('cod_iie',$data["id_excel_iie"])->update(['fecha_'.$momento.'_cuestionario'=>$data[$column]]);
						// }
					// }
				// }

			// }catch(\Exception $e){
				// DB::rollback();
				// echo "error al guardar cuestionario<br>";
				// echo $e;
			// }
			// DB::commit();
		// }
		
	// }	

	public function cargarDatos(){
		//https://www.diagnosticafid.cl/monitoreo/get/guardarDatos

		//CONSULTA PARA GENERAR LA VISTA
		/*
		SELECT  e.id_excel_iie as cod_iie, c.carrera, c.dia_de_aplicacion,re.numero_region, co.nombre_comuna, ca.nombre_sede, ci.nombre_institucion, de.nombre_dependencia as nombre_laboratorio, de.lab_cod_iie, mo.fecha_inicio_bloque1, mo.fecha_fin_bloque1, mo.fecha_inicio_bloque2, mo.fecha_fin_bloque2,mo.fecha_inicio_cuestionario, mo.fecha_fin_cuestionario, (CASE WHEN mo.fecha_inicio_bloque1 IS NOT NULL THEN true else NULL END) as bloque1_inicio,(CASE WHEN mo.fecha_inicio_bloque2 IS NOT NULL THEN true else NULL END) as bloque2_inicio,(CASE WHEN mo.fecha_fin_bloque1 IS NOT NULL THEN true else NULL END) as bloque1_fin,(CASE WHEN mo.fecha_fin_bloque2 IS NOT NULL THEN true else NULL END) as bloque2_fin,(CASE WHEN mo.fecha_inicio_cuestionario IS NOT NULL THEN true else NULL END) as cuestionario_inicio,(CASE WHEN mo.fecha_fin_cuestionario IS NOT NULL THEN true else NULL END) as cuestionario_fin
		FROM evaluados as e, carreras as c, aplicaciones as a, evaluadosaplicaciones as ea, dependencias as de, centrosaplicacion as ca, comunas as co,
		regiones as re, centro_institucion as ci, monitoreo as mo
		WHERE e.id_carrera=c.id_carrera AND ea.idevaluado=e.id AND a.id=ea.idaplicacion AND a.dependencia_id=de.id AND de.centrosaplicacion_id=ca.id AND
		ca.id_comuna=co.id AND co.region_id=re.id AND ca.centro_institucion_id=ci.id_centro_institucion AND mo.cod_iie=e.id_excel_iie
		and a.tiposaplicacion_id= 62		
		*/

		echo date('H:i:s')."<br/>";
		
		//DB::select("delete from monitoreo");
    	
		$path = app_path('Http/Controllers/')."IIE/datos_txt/monitoreo/";
		
		//$cargarAlumnosInscritos = true;
		$pruebasBloque1 = [999933, 829993, 999922, 142248];
		$pruebasBloque2 = [293621,518711,479156,229213,263661,336575,399132,725271,838329,536992,681587,852364,151547];
		$cuestionario = [563156];		

		// $pruebasBloque1 = [999933, 829993];
		// $pruebasBloque2 = array();
		// $cuestionario = array();		

		$prueba = array_merge($pruebasBloque1,$pruebasBloque2,$cuestionario);
		
		
						
		foreach($prueba as $pruebas){
			
			$aGrabar = array();	
			
			if(in_array($pruebas ,$pruebasBloque1)){
				$camposUsar = "fecha_inicio_bloque1, fecha_fin_bloque1";	
			}
			elseif(in_array($pruebas, $pruebasBloque2)){
				$camposUsar = "fecha_inicio_bloque2, fecha_fin_bloque2";	
			}
			elseif(in_array($pruebas, $cuestionario)){
				$camposUsar = "fecha_inicio_cuestionario, fecha_fin_cuestionario";	
			}
			
			//$cc = explode(",",$camposUsar);
			$actualizar = array();
			$als = DB::select("select cod_iie from monitoreo");
			
			foreach($als as $_als){
				//$actualizar[$_als->cod_iie] = true;
				$actualizar[] = $_als->cod_iie;
			}
			
			
			$gestor = $this->get_content('http://cw01.iie.cl/lsinicia/evaluacion/inws/monitoreo.php?ssid='.$pruebas, "r");
			//echo 'http://cw01.iie.cl/lsinicia/evaluacion/inws/monitoreo.php?ssid='.$pruebas;
			// @unlink($path."_.txt");
			// $fp = fopen($path."_.txt", 'w');
			// fwrite($fp, $gestor);
			// fclose($fp);

			//ABRO EL ARCHIVO Y PROCESO
			//$file = file($path."_.txt");
			if($gestor!=""){
				$json = json_decode($gestor, 1);
				
				foreach($json[$pruebas] as $codigoPrueba=>$data){
					$aGrabarAux["cod_iie"] = $data["attribute_13"];
					$aGrabarAux["startdate"] = (($data["startdate"]==null)or($data["startdate"]==''))?'null':$data["startdate"];
					$aGrabarAux["submitdate"] = (($data["submitdate"]==null)or($data["submitdate"]==''))?'null':$data["submitdate"];
					//$aGrabarAux["codigo_prueba"] = $pruebas;
					//if($cargarAlumnosInscritos==true){
						$aGrabar[] = $aGrabarAux;		
					//}						
					//else{
					//	if(in_array($data["attribute_13"], $actualizar)){
					//		$aGrabar[] = $aGrabarAux;		
					//	}
					//}
				}
			}

			//GENERO UN ARCHIVO SQL CON LOS INSERTS
			@unlink($path."_sql.txt");
			$fp = fopen($path."_sql.txt", 'w+');	
			$cont = 0;
			$sql = "";
			foreach($aGrabar as $_aGrabar){
				if(!in_array($_aGrabar["cod_iie"], $actualizar)){
					$sqlAux = "insert into monitoreo (".$camposUsar.", cod_iie	) values ('".$_aGrabar["startdate"]."', '".$_aGrabar["submitdate"]."', '".$_aGrabar["cod_iie"]."');\n";
					$sql.= str_replace("'null'", "null", $sqlAux);
				}
				else{
					$cc = explode(",",$camposUsar);
					$sqlAux = "update  monitoreo set ".$cc[0]." = '".$_aGrabar["startdate"]."', ".$cc[1]." = '".$_aGrabar["submitdate"]."' where cod_iie = '".$_aGrabar["cod_iie"]."' ;\n";	
					$sql.= str_replace("'null'", "null", $sqlAux);
				}
				$cont++;
			}
			fwrite($fp, $sql);
			fclose($fp);
			
			$comando  = 'PGPASSWORD=k1LL2018 psql -h 162.216.18.16 -d endfid -U postgres -p 5432 -a -q -f /home/diag2018fid/public_html/app/Http/Controllers/IIE/datos_txt/monitoreo/_sql.txt';
			
			//shell_exec($comando);
			
			echo "total a insertar->".$cont."<br/>";
		}
		$totalRegistros = DB::select("SELECT count(*) FROM public.monitoreo");
		arreglo($totalRegistros);
		echo date('H:i:s')."<br/>";		
	}
}


