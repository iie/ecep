<?php
namespace App\Http\Controllers\IIE;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Institucion;
use App\Models\InstitucionCampus;
use App\Models\Aplicaciones;
use App\Models\Carrera;
use App\Models\EstudianteModificacion;
use App\Models\EstudianteListado;
use App\Models\rolesproceso;
use App\Models\rolusuario;
use App\Models\personas;
use App\Models\usuarios;
use App\Models\comunas;
use App\Models\CentroInstitucion;
use App\Models\CentroAplicacion;
use App\Models\Dependencias;
use App\Models\EvaluadosAplicaciones;
use App\Models\LimePregunta;
use App\Models\LimeRespuesta;
use App\Models\LimePuntajesAnteriores;
use App\Models\LimePuntajeIndividualPcpg;
use App\Models\LimePorcentajeLogro;
use App\Models\LimeReporteInstitucional;
use App\Models\LimeTema;
use App\Models\LimeTendencia;
use App\Models\Evaluado;
use App\Models\LimeEstandar;
use App\Models\LimePrp;
use App\Models\Prueba;
use App\Models\LimeReporteInstitucionalGlobal;
use App\Models\LimeCuestionario;
use App\Models\LimeCuestionarioCodigo;

use Illuminate\Support\Facades\DB;
use PHPMailer\PHPMailer;
use Illuminate\Support\Facades\Auth;
use Mail;

class Tools extends Controller
{
	 
	public function __construct()
    {
		$this->fields = array();	
    }	
	
	public function sqlToTable(){
		$sql = "
		SELECT nombre_corto, rut, nro_estandar, porcentaje	, estandar	 
		FROM lime_porcentaje_logro_estandar, evaluados, lime_estandar, pruebas
		where lime_porcentaje_logro_estandar.cod_iie  = evaluados.id_excel_iie
		and lime_estandar.id_lime_estandar = lime_porcentaje_logro_estandar.id_estandar
		and lime_estandar.id_prueba = pruebas.id
		order by nombre_corto, rut,nro_estandar		
		";
		
		$listadoCompleto = DB::select($sql);		
		$cols = json_decode(json_encode($listadoCompleto[0]),1);
		
		echo "<table>";
		echo "<tr>";
		foreach($cols as $index=>$colsAux){
			echo "<td>".trim($index)."</td>";
			$colsArr[] = trim($index);
		}
		echo "</tr>";
		
		
		foreach($listadoCompleto as $listadoCompletoAux){
			echo "<tr>";
			foreach($listadoCompletoAux as $valor){
				echo "<td>".trim(str_replace(".",",",$valor))."</td>";
			}	
			echo "</tr>";
		}
		echo "</table>";
		
	}	
	
	public function ingresaTemas()
    {
		//https://www.diagnosticafid.cl/public/ingresa-temas
		exit;
		
		//ingresar temas
		$nroPrueba = 12;
		$pr = Prueba::find($nroPrueba);
		$limeTema = LimeTema::where('id_prueba', $nroPrueba)->orderBy("nro_tema","asc")->get();
		foreach($limeTema as $limeTemaAux){
			$codigoTema[$limeTemaAux->nro_tema] = $limeTemaAux->id_lime_tema;
		}
		//arreglo($codigoTema);exit;
		$path = app_path('Http/Controllers/')."IIE/datos_txt/temas_prueba/";
		$file = file($path.$nroPrueba.".txt");

		foreach($file as $fileAux){
			$campos = explode("\t", $fileAux);
			$limePregunta = LimePregunta::where("orden", trim($campos[0]))->where("codigo_prueba_deprecado", $pr->codigo_prueba)->get();
			foreach($limePregunta as $limePreguntaAux){
				$limePreguntaAux->id_lime_tema = $codigoTema[trim($campos[1])];
				$limePreguntaAux->save();
			}
		}	
	}	

	public function asignaEstandares()
    {
		//https://www.diagnosticafid.cl/public/asigna-estandares
		exit;
		//ingresar estandares
		$nroPrueba = 3;
		$pr = Prueba::find($nroPrueba);
		$limeEstandar = LimeEstandar::where('id_prueba', $nroPrueba)->orderBy("nro_estandar","asc")->get();
		foreach($limeEstandar as $limeEstandarAux){
			$codigoEstandar[$limeEstandarAux->nro_tema_eliminar][$limeEstandarAux->nro_estandar] = $limeEstandarAux->id_lime_estandar;
		}
		
		$path = app_path('Http/Controllers/')."IIE/datos_txt/estandar_prueba/";
		$file = file($path.$nroPrueba.".txt");

		foreach($file as $fileAux){
			$campos = explode("\t", $fileAux);
			$limePregunta = LimePregunta::where("orden", trim($campos[0]))->where("codigo_prueba_deprecado", $pr->codigo_prueba)->get();
			foreach($limePregunta as $limePreguntaAux){
				$limePreguntaAux->id_lime_estandar = $codigoEstandar[trim($campos[1])][trim($campos[2])];
				$limePreguntaAux->save();
			}
		}	
	}	

	public function corregirCuestionario()
    {
		exit;
		//https://www.diagnosticafid.cl/public/corrige-cuestionario
		$cuestionario = LimeCuestionario::all();
		/* Agregar cod_iie por rut*/
		/*foreach($cuestionario as $cuest){
			$ev = Evaluado::where("rut", $cuest->rut)->first();
			if(isset($ev->id)){
				$lc = LimeCuestionario::find($cuest->id_lime_cuestionario);
				$lc->cod_iie = $ev->id_excel_iie;
				$lc->save();
			}else{
				echo "No encontrado<br>";
			}
		}*/
		/* Agregar foraneas codigo p23 y p24 de tabla de codigos*/
		foreach($cuestionario as $cuest){
			$lcc23 = LimeCuestionarioCodigo::where("tipo", "p23")->where("codigo", $cuest->codigo_numerico_p23a)->first();
			$lcc24 = LimeCuestionarioCodigo::where("tipo", "p24")->where("codigo", $cuest->codigo_numerico_p24a)->first();
			$lc = LimeCuestionario::find($cuest->id_lime_cuestionario);
			$lc->p23_cod = isset($lcc23->id_lime_cuestionario_codigo) ? $lcc23->id_lime_cuestionario_codigo : null;
			$lc->p24_cod = isset($lcc24->id_lime_cuestionario_codigo) ? $lcc24->id_lime_cuestionario_codigo : null;
			$lc->save();
		}
		echo "Completado!";
	}	

	public function cargaTendencia()
    {
		exit;
		//https://www.diagnosticafid.cl/public/carga-tendencia

		/* ----2016----*/
		$path = app_path('Http/Controllers/')."IIE/datos_txt/importar_excel/";
		$file = file($path."tendencia_2016.txt");
		$cont = 0;
		foreach($file as $fileAux){
			$cont++;
			// if($cont==5){
			// 	exit;
			// }
			$campos = explode("\t", $fileAux);
			// if($campos[2]==null){
			// 	echo "entré";
			// }
			if($campos[4]!=null && $campos[4]!=""  && $campos[4]!="\n" && $campos[4]!=" "){
				if($campos[1]!=null){
					$lt = new LimeTendencia();
					$lt->tipo_prueba = "pcpg";
					$lt->anio = 2016;
					$lt->puntaje = $campos[1]!=null? $campos[1] : null;
					$lt->id_carrera = $campos[3];
					$lt->id_institucion = $campos[4]!=null? $campos[4] : null;
					$lt->rut = $campos[0];
					$lt->save();	
				}
				
				if($campos[2]!=null){
					$lt = new LimeTendencia();
					$lt->tipo_prueba = "pcdd";
					$lt->anio = 2016;
					$lt->puntaje = $campos[2]!=null ? $campos[2] : null;
					$lt->id_carrera = $campos[3];
					$lt->id_institucion = $campos[4]!=null? $campos[4] : null;
					$lt->rut = $campos[0];
					$lt->save();	
				}
			}
		}	
		echo "completados: ".$cont;
    	/* ---- 2017 ----*/
/*		$sql = 'SELECT
				lime_puntaje_individual_2017.pcpg,
				lime_puntaje_individual_2017.pcdd,
				lime_puntaje_individual_2017.id_institucion,
				lime_puntaje_individual_2017.id_carrera,
				lime_puntaje_individual_2017.run
				FROM
				lime_puntaje_individual_2017';
		$listadoCompleto = DB::select($sql);
		// arreglo($listadoCompleto);exit;
		foreach($listadoCompleto as $list){
			$lt = new LimeTendencia();
			$lt->tipo_prueba = "pcpg";
			$lt->anio = 2017;
			$lt->puntaje = $list->pcpg;	
			$lt->id_carrera = $list->id_carrera;
			$lt->id_institucion = $list->id_institucion;
			$lt->rut = $list->run;
			$lt->save();

			$lt2 = new LimeTendencia();
			$lt2->tipo_prueba = "pcdd";
			$lt2->anio = 2017;
			$lt2->puntaje = $list->pcdd;
			$lt2->id_carrera = $list->id_carrera;
			$lt2->id_institucion = $list->id_institucion;	
			$lt2->rut = $list->run;
			$lt2->save();
		}*/

		/* ---- 2018 ----*/
		/*$sql = 'SELECT
				cod_iie,
				tipo_prueba,
				puntaje
				FROM
				lime_puntaje_individual_2018';
		$listadoCompleto = DB::select($sql);
		// arreglo($listadoCompleto);exit;
		foreach($listadoCompleto as $list){
			$ev = Evaluado::where("id_excel_iie", $list->cod_iie)->first();
			$si = InstitucionCampus::find($ev->sedeinstitucion_id);
			$lt = new LimeTendencia();
			$lt->tipo_prueba = $list->tipo_prueba;
			$lt->anio = 2018;
			$lt->puntaje = $list->puntaje;	
			$lt->id_carrera = $ev->id_carrera;
			$lt->id_institucion = $si->institucionestudios_id;
			$lt->rut = $ev->rut;
			$lt->save();
		}*/

		/* UPDATE tabala de tendencia*/
		/*$sql = 'SELECT
			 	id_lime_tendencia,
				rut
				FROM
				lime_tendencia
				WHERE
				anio = 2018';
		$listadoCompleto = DB::select($sql);
		// arreglo($listadoCompleto);exit;
		foreach($listadoCompleto as $list){
			$ev = Evaluado::where("rut", $list->rut)->first();
			$lt = LimeTendencia::find($list->id_lime_tendencia);
			// arreglo($list->rut);exit;
			// $lt->tipo_prueba = $list->tipo_prueba;
			// $lt->anio = 2018;
			// $lt->puntaje = $list->puntaje;	
			// $lt->id_carrera = $ev->id_carrera;
			// $lt->id_institucion = $si->institucionestudios_id;
			// $lt->rut = $ev->rut;
			$lt->modalidad_estudio = ($ev->extra_prosecucion == true) ? "prosecucion" : "regular";
			$lt->save();
		}*/

		echo "Completado!";
	}

	public function cargaProm2016(Request $request)
	    {
	    	
		exit;	
		/* Sin Ruta (Usado desde otro controlador) */
		/* CARGA Promedios PCDD 2016 */
		$path = app_path('Http/Controllers/')."IIE/datos_txt/importar_excel/";
		$file = file($path."pcdd2016.txt");
		$c = 0;
		$cont= 0;
		foreach($file as $fileAux){
			$campos = explode("\t", multibyte_trim($fileAux));
			// carrera/institucion/promedio
			// arreglo($campos);exit;
			
			$nuevosDatos = LimeReporteInstitucional::where("id_carrera", $campos[0])->where("id_institucion", $campos[1])->where("tipo_prueba", "PCDD")->first();
			if(isset($nuevosDatos->id_reporte_institucional)){
				if($campos[2] != "NA"){
					$nuevosDatos->promedio2016 = $campos[2];
					$nuevosDatos->save();
					$cont++;
					// echo "Grabado " .$cont . "registro.";
				}
			}else{
				// echo "No encontrado";
				echo "C: " .$campos[0] ." - I: " .$campos[1] .".<br>";
				$c++;
			}
		}

		echo "Completados " . $cont. "registros.<br>";
		echo "No encontrados: " . $c. "registros.";


		/* CARGA Promedios PCPG 2016 */
		$path = app_path('Http/Controllers/')."IIE/datos_txt/importar_excel/";
		$file = file($path."pcpg2016.txt");
		$c = 0;
		$cont= 0;
		foreach($file as $fileAux){
			$campos = explode("\t", multibyte_trim($fileAux));
			// carrera/institucion/promedio
			if($campos[1] != "NA"){
				$nuevosDatos = LimeReporteInstitucional::where("id_carrera", $campos[0])->where("id_institucion", $campos[1])->where("tipo_prueba", "PCPG")->first();
				if(isset($nuevosDatos->id_reporte_institucional)){
						$nuevosDatos->promedio2016 = $campos[2];
						$nuevosDatos->save();
						$cont++;
						// echo "Grabado " .$cont . "registro.";
				}else{
					// echo "No encontrado";
					echo "C: " .$campos[0] ." - I: " .$campos[1] .".<br>";
					$c++;
				}
			}
		}

		echo "Completados " . $cont. "registros.<br>";
		echo "No encontrados: " . $c. "registros.";

	}

	public function cargaSignificancia(Request $request){
		
		exit;
		
		//https://www.diagnosticafid.cl/public/carga-significancia
		
		
		$path = app_path('Http/Controllers/')."IIE/datos_txt/importar_excel/";
		$file = file($path."significanciaCorrelacion.txt");
		
		DB::select("update lime_reporte_institucional_global set correlacion_significancia = null");
		
		foreach($file as $fileAux){
			$campos = explode("\t", multibyte_trim($fileAux));
			
			$nuevosDatos = LimeReporteInstitucionalGlobal::where("id_carrera", $campos[1])->where("id_institucion", $campos[0])->first();
			//if(isset($nuevosDatos->id_reporte_institucional_global)){
				if($nuevosDatos->correlacion != ''){
					$nuevosDatos->correlacion_significancia = multibyte_trim($campos[2]);
					$nuevosDatos->save();
				}
			//}
		}
	}

    public function importarExcel(Request $request)
    {
		
		exit;
		
		//https://www.diagnosticafid.cl/public/reportes/importar-excel
		
		//IMPORTAR EXCEL
		$path = app_path('Http/Controllers/')."IIE/datos_txt/importar_excel/";
		$file = file($path."puntajes_anteriores.txt");
		$c = 1;
		$tablaNueva = 'lime_puntaje_individual_2017';
		$colsExcluir[] = 'updated_at';
		$colsExcluir[] = 'created_at';
		
		DB::select("delete from ".$tablaNueva."  ");		
		
		$colsName = DB::select("SELECT * FROM information_schema.columns WHERE table_schema = 'public' and table_name ='".$tablaNueva."'  ");		
		
		foreach($colsName as $colsNameAux){
			if(!in_array($colsNameAux->column_name, $colsExcluir)){
				$cols[] = trim($colsNameAux->column_name);	
			}
		}

		foreach($file as $fileAux){
			$campos = explode("\t", multibyte_trim($fileAux));
			$nevosDatos = new LimePuntajesAnteriores;
			for($i=1; $i<=count($cols)-1; $i++){
				if(array_key_exists(($i-1), $campos)){
					$nevosDatos->{$cols[$i]} = ($campos[$i-1]!="")?multibyte_trim($campos[$i-1]):null;	  	
				}
				else{
					$nevosDatos->{$cols[$i]} = null;	  	
				}
				
			}
			$nevosDatos->save();
		}
	}

	public function importarExcelEstandar(Request $request)
    {
		
		exit;
		
		//IMPORTAR EXCEL
		$path = app_path('Http/Controllers/')."IIE/datos_txt/importar_excel/";
		$file = file($path."estandares_media_7.txt");
		$c = 1;
		$tablaNueva = 'lime_estandar';
		$colsExcluir[] = 'updated_at';
		$colsExcluir[] = 'created_at';
		
		//DB::select("truncate table ".$tablaNueva."  ");		
		
		$colsName = DB::select("SELECT * FROM information_schema.columns WHERE table_schema = 'public' and table_name ='".$tablaNueva."'  ");		
		foreach($colsName as $colsNameAux){
			if(!in_array($colsNameAux->column_name, $colsExcluir)){
				$cols[] = trim($colsNameAux->column_name);	
			}
		}

		foreach($file as $fileAux){
			$campos = explode("\t", multibyte_trim($fileAux));
			$nevosDatos = new LimeEstandar;
			$nevosDatos->nro_estandar = $campos[0];
			$nevosDatos->id_prueba = $campos[1];
			 /* En el modelo debe estar desactivada la opción de timestamps para evitar errores */ 
			 /* relacionados al updated_at y created_at (public $timestamps = false;)  */
			$nevosDatos->save();
		}
	}

	public function importarExcelPrp(Request $request)
    {
    	exit;
		//IMPORTAR EXCEL
		$path = app_path('Http/Controllers/')."IIE/datos_txt/importar_excel/";
		$file = file($path."prp.txt");
		$c = 1;
		$tablaNueva = 'lime_prp';
		$colsExcluir[] = 'updated_at';
		$colsExcluir[] = 'created_at';
		
		//DB::select("truncate table ".$tablaNueva."  ");		
		
		$colsName = DB::select("SELECT * FROM information_schema.columns WHERE table_schema = 'public' and table_name ='".$tablaNueva."'  ");		
		foreach($colsName as $colsNameAux){
			if(!in_array($colsNameAux->column_name, $colsExcluir)){
				$cols[] = trim($colsNameAux->column_name);	
			}
		}

		foreach($file as $fileAux){
			$campos = explode("\t", multibyte_trim($fileAux));
			$evaluado = Evaluado::where("rut", $campos[1])->first();
			if(isset($evaluado->rut)){
				$prp = new LimePrp();
				$prp->cod_iie = $evaluado->id_excel_iie;
				$prp->codigo_comunicacion = $campos[2];
				$prp->lenguaje_inclusivo = ($campos[3] == "Si") ? true : false;
				$prp->codigo_pedagogico = $campos[4];
				$prp->sesgo = ($campos[5] == "Si") ? true : false;
				$prp->save();
			}
		}
		echo ("Guardados");
	}

	public function importarExcelIndividual(Request $request)
    {
		
		exit;
		
		//https://www.diagnosticafid.cl/public/reportes/importar-excel-ind
		
		//vaciamos la tabla
		DB::select("delete from lime_tendencia where anio = 2018");
		
		$sedeinstitucion = DB::select("select * from sedeinstitucion");
		foreach($sedeinstitucion as $sedeinstitucionAux){
			$instit[$sedeinstitucionAux->id] = $sedeinstitucionAux->institucionestudios_id;	 
		}
		
		$path = app_path('Http/Controllers/')."IIE/datos_csv/puntajes/";
		if ($gestor = opendir($path)) {
			while (false !== ($entrada = readdir($gestor))) {
				if ($entrada != "." && $entrada != "..") {
					$file = file($path.$entrada);
					foreach($file as $fileAux){
						$campos = explode(",", multibyte_trim($fileAux));
						if(is_numeric($campos[8])){
							$pos = explode("_PCP_", $entrada);
							$evaluado = Evaluado::where("rut", trim(str_replace('"','',$campos[0])))->first();
							$lpi = new LimeTendencia();
							$lpi->anio = 2018;	
							$lpi->id_carrera = $evaluado->id_carrera;	
							$lpi->id_institucion = 	$instit[$evaluado->sedeinstitucion_id];
							$lpi->rut = $evaluado->rut;	
							$lpi->modalidad_estudio = ($evaluado->extra_prosecucion==true)?"prosecucion":"regular";
							if (count($pos)>1){
								$lpi->tipo_prueba = "pcpg";	
							} else {
								$lpi->tipo_prueba = "pcdd";	
							}							
							$lpi->puntaje = $campos[8];
							$lpi->save();
						}		
					}
				}
			}
			closedir($gestor);
		}		
		echo ("Guardados");
	}

	// public function importarExcelPcddIndividual(Request $request)
    // {
    	// exit;
		// //IMPORTAR EXCEL
		// $path = app_path('Http/Controllers/')."IIE/datos_txt/importar_excel/";
		// $file = file($path."pcdd_informe_individual.txt");
		// $c = 1;
		// $tablaNueva = 'lime_puntaje_individual_2018';
		// $colsExcluir[] = 'updated_at';
		// $colsExcluir[] = 'created_at';
		
		// //DB::select("truncate table ".$tablaNueva."  ");		
		
		// $colsName = DB::select("SELECT * FROM information_schema.columns WHERE table_schema = 'public' and table_name ='".$tablaNueva."'  ");

		// foreach($colsName as $colsNameAux){
			// if(!in_array($colsNameAux->column_name, $colsExcluir)){
				// $cols[] = trim($colsNameAux->column_name);
			// }
		// }
		// // arreglo($cols);exit;
		// foreach($file as $fileAux){
			// $campos = explode("\t", multibyte_trim($fileAux));
			// $evaluado = Evaluado::where("rut", $campos[0])->first();
			// if(isset($evaluado->rut)){
				// $lpi = new LimePuntajeIndividualPcpg();
				// $lpi->cod_iie = $evaluado->id_excel_iie;
				// $lpi->tipo_prueba = "pcdd";
				// $lpi->puntaje = $campos[1];
				// $lpi->save();
			// }
		// }
		// echo ("Guardados");
	// }
	
    public function emailsDuplicado(Request $request)
    {
		exit;
		
		$evaluados = EstudianteListado::get();
		foreach($evaluados as $evaluadosAux){
			if(trim($evaluadosAux->email2)==""){
				$evaluadosAux->email2 = "sin email";
			}
			$s[trim($evaluadosAux->email2)][] = $evaluadosAux->rut;
		}
		foreach($s as $e=>$email){
			if(count($email)>1){
				echo $e.",";
				 foreach($email as $emailz){
					echo $emailz.",";
				 }
				//arreglo($email);
			}
			if(count($email)>1){
				echo "<br/>";
			}
		}
	}
	
	public function diasLabs(Request $request){
		exit;
		
		$file = DB::select(
			'
				SELECT aplicaciones.fecha_agendada, lab_cod_iie, 
				nombre_region, numero_region,
				ca.nombre_comuna as comuna_asignada, 
				centro_institucion.nombre_institucion, 
				centrosaplicacion.nombre_sede, 
				dependencias.nombre_dependencia as laboratorio, count(rut)


				FROM evaluadosaplicaciones, evaluados, aplicaciones, dependencias, comunas ca, comunas cc, comunas cr, centrosaplicacion, centro_institucion, regiones,
				institucionestudios,sedeinstitucion,carreras
				WHERE evaluadosaplicaciones.idevaluado  = evaluados.id
				AND regiones.id = ca.region_id
				AND carreras.id_carrera = evaluados.id_carrera
				AND evaluados.sedeinstitucion_id = sedeinstitucion.id
				AND institucionestudios.id	= sedeinstitucion.institucionestudios_id
				AND evaluadosaplicaciones.idaplicacion =  aplicaciones.id
				AND dependencia_id = dependencias.id
				AND ca.id = centrosaplicacion.id_comuna
				AND cc.id = sedeinstitucion.comuna_id
				AND cr.id = evaluados.id_comuna
				AND centrosaplicacion.id = dependencias.centrosaplicacion_id
				AND centro_institucion.id_centro_institucion = centrosaplicacion.centro_institucion_id
				group by aplicaciones.fecha_agendada, lab_cod_iie, nombre_region, numero_region,comuna_asignada, centro_institucion.nombre_institucion, 
				centrosaplicacion.nombre_sede, 
				laboratorio				
				
				order by numero_region	ASC, nombre_region	ASC, comuna_asignada	ASC, nombre_institucion	ASC, nombre_sede ASC
				
				
			');
			
			foreach($file as $diasLabsAux){
				$x[$diasLabsAux->lab_cod_iie][$diasLabsAux->fecha_agendada] = $diasLabsAux;
				$datoLab[$diasLabsAux->lab_cod_iie] = $diasLabsAux;
			}
		
			echo "<table border = 1>";
			echo "<tr>
					<td>IdLab</td>
					<td>region_num</td>
					<td>region_nombre</td>
					<td>ciudad(comuna)</td>
					<td>nombre_institucion</td>
					<td>nombre_sede</td>
					<td>laboratorio</td>
					<td>Día 1</td>
					<td>Día 2</td>
					<td>Día 3</td>
					<td>Día 4</td>
					
				  </tr>
				";
			
			
			foreach($x as $codLab=>$dias){
			
				//foreach($dias as $fecha =>$datos){
					echo "<tr>
							<td>".$codLab."</td>
							<td>".$datoLab[$codLab]->numero_region."</td>
							<td>".$datoLab[$codLab]->nombre_region."</td>
							
							<td>".$datoLab[$codLab]->comuna_asignada."</td>
							<td>".$datoLab[$codLab]->nombre_institucion."</td>
							<td>".$datoLab[$codLab]->nombre_sede."</td>
							<td>".$datoLab[$codLab]->laboratorio."</td>
							<td>".((isset($dias["2018-12-18"]))?$dias["2018-12-18"]->count:0)."</td>
							<td>".((isset($dias["2018-12-19"]))?$dias["2018-12-19"]->count:0)."</td>
							<td>".((isset($dias["2018-12-20"]))?$dias["2018-12-20"]->count:0)."</td>
							<td>".((isset($dias["2018-12-21"]))?$dias["2018-12-21"]->count:0)."</td>
							
						  </tr>
						";
					
				//}
				
			}
			//arreglo($x);
	
	}	

	public function excelListado(Request $request)
    {
		
		exit;
		
		$file = DB::select(
		'
			SELECT 
			evaluados.id_excel_iie,
			nombre_institucion as "Institución",
			ri.numero_region as "Número Región Sede Institución",
			ri.nombre_region as "Nombre Región Sede Institución",
			cs.nombre_comuna as "Comuna Sede",        
			direccion_sede as "Dirección sede institución",
			nombre_sede as "Nombr Sede institución",
			evaluados.extra_nom_orig_carrera        as "Nombre original del programa o carrera",
			evaluados.extra_nivel_carrera        as "Nivel Carrera",
			evaluados.extra_asignatura        as "Asignatura (Pedagogía en Educación Media)",
			carrera as "Carrera oficial",
			dia_de_aplicacion as "Día Aplicación",
			evaluados.extra_prosecucion        as "Programa de prosecución de estudios",
			evaluados.extra_titulo_otorga        as "Título que otorga",
			evaluados.modalidad_estudio as "Modalidad 1 (Presencial)",
			
			CASE
			   WHEN  evaluados.modalidad_horario = 48   THEN \'Diurno\'
			   WHEN  evaluados.modalidad_horario = 49   THEN \'No Aplica\'
			   WHEN  evaluados.modalidad_horario = 50   THEN \'Vespertino\'
			 END 
			 AS "Modalidad 2 (Horario)",
			evaluados.anio_ingreso as "Año ingreso",
			CASE
			   WHEN  evaluados.id_genero = 46   THEN \'Femenino\'
			   WHEN  evaluados.id_genero = 47   THEN \'Masculino\'
			 END 
			 AS "Género",

			evaluados.id_genero as "Género",
			evaluados.nombres as "Nombres",
			evaluados.apellido_paterno as "Apellido paterno",
			evaluados.apellido_materno as "Apellido materno",
			evaluados.rut as "RUN",
			re.numero_region as "Número Región", 
			re.nombre_region as "Nombre Región Residencia",
			ce.nombre_comuna as "Comuna residencia",        
			evaluados.email1 as "mail1",
			evaluados.email2 as "Mail2",
			evaluados.telefono_fijo as "Teléfono",
			evaluados.telefono_movil as "Celular(9 dígitos)",
			evaluados.con_discapacidad as "Estudiante con discapacidad(indique en la siguiente columna qué tipo de discapacidad posee y que medios requiere para rendir la evaluación)",
			evaluados.medios_necesarios as "Discapacidad y medios necesarios para rendir la Evaluación",
			evaluados.rezagado as "Estudiante rezagado",
			evaluados.observaciones as "Observaciones (indicar cualquier otro elemento que considere relevante)"


			FROM institucionestudios, 
			sedeinstitucion, comunas as cs, regiones as ri,
			evaluados,  comunas as ce, regiones as re,
			carreras

			WHERE evaluados.sedeinstitucion_id = sedeinstitucion.id
			AND sedeinstitucion.institucionestudios_id = institucionestudios.id
			AND evaluados.id_carrera = carreras.id_carrera
			AND ce.id = evaluados.id_comuna
			AND cs.id = sedeinstitucion.comuna_id
			AND ri.id = cs.region_id
			AND re.id = ce.region_id
			AND evaluados.borrado = false			
		'
		);	
		$array = json_decode(json_encode($file), true);
		$encabezado = array_keys($array[0]);
		
		$t = "<table border = '1'>";
		$t.= "<tr><td  style='font-weight:bold'>Nro</td>";

		$t.= "<td style='font-weight:bold'>".implode("</td><td style='font-weight:bold'>", $encabezado)."</td>";
		$t.= "</tr>";
		$cont = 1;
		foreach($array as $fileAux){
			$t.= "<tr>";
			$t.= "<td>".$cont."</td><td>".implode("</td><td>",$fileAux)."</td>";
			$t.= "</tr>";
			$cont++;
		}
		
		$t.= "</table>";			
		
		$file = "planillaAlumnos-".date("Y-m-d_H_i_s").".xls";			

		header("Content-type: application/vnd.ms-excel");
		header("Content-Disposition: attachment; filename=".$file);
		header("Pragma: no-cache");
		header("Expires: 0");
		echo $t;

	}		
	
	public function buscarRutsModificados(Request $request)
    {
		
		exit;
		
		$evaluados = EstudianteListado::get();
		foreach($evaluados as $evaluadosAux){
			$tmActual[$evaluadosAux->id] = mb_strtolower($evaluadosAux->rut);
			$tmDatos[$evaluadosAux->id]["sedeinstitucion_id"] = mb_strtolower($evaluadosAux->sedeinstitucion_id);
			$tmDatos[$evaluadosAux->id]["id_carrera"] = mb_strtolower($evaluadosAux->id_carrera);
			$tmDatos[$evaluadosAux->id]["nombres"] = mb_strtolower($evaluadosAux->nombres);
			$tmDatos[$evaluadosAux->id]["apellido_paterno"] = mb_strtolower($evaluadosAux->apellido_paterno);
		}
		
		$path = app_path('Http/Controllers/')."IIE/datos_txt/";
		$file = file($path."ruts.txt");
		foreach($file as $fileAux){
			$campos = explode("\t", $this->multibyte_trim($fileAux));
			$idExcel = trim($campos[0]);
			$idRut = trim($campos[1]);
			$tm[$idExcel] = mb_strtolower($idRut);
			$tmaDatos[$idExcel]["sedeinstitucion_id"] = $campos[2];
			$tmaDatos[$idExcel]["id_carrera"] = $campos[3];
			$tmaDatos[$idExcel]["nombres"] = $campos[4];
			$tmaDatos[$idExcel]["apellido_paterno"] = $campos[5];
		}
		
		foreach($tmActual as $idEx=>$rutt){
			if(array_key_exists($idEx, $tm)){
				if($tm[$idEx]!=$rutt){
					//echo $rutt." cambia a ".$tm[$idEx]."-->".$tmDatos[$idEx]["sedeinstitucion_id"]."-".$tmDatos[$idEx]["id_carrera"]."-".$tmDatos[$idEx]["nombres"]."-".$tmDatos[$idEx]["apellido_paterno"]."-".$tmaDatos[$idEx]["sedeinstitucion_id"]."-".$tmaDatos[$idEx]["id_carrera"]."-".$tmaDatos[$idEx]["nombres"]."-".$tmaDatos[$idEx]["apellido_paterno"]."<br/>";
					echo $rutt." reemplaza a ".$tm[$idEx]."<br/>";
				}
			}
			else{
				//echo $idEx."<br/>";
			}
		}

	}	

	
    
	public function updatePruebas(Request $request)
    {
		
		exit;
		
		// $lp = LimePregunta::where("codigo_prueba", 293621)->orderBy("orden", "asc")->get();
		// foreach ($lp as $pregunta) {
		// 	arreglo($pregunta->orden);
		// }exit;
		// arreglo(sizeof($lp));exit;
		
		$path = app_path('Http/Controllers/')."IIE/datos_txt/respuestas_correctas/";
		$file = file($path."pcd_basica.txt");
		foreach($file as $fileAux){
			$campos = explode("\t", $this->multibyte_trim($fileAux));
			$un["indice"] = substr($this->multibyte_trim($campos[0]), -2);
			$un["cod_pregunta"] = $this->multibyte_trim($campos[1]);
			$un["clave"] = $this->multibyte_trim($campos[2]);			
			$preguntas[] = $un;
		}

		foreach ($preguntas as $pregunta) {
			$lp = LimePregunta::where("codigo_prueba", 293621)->where("orden", $pregunta["indice"])->first();
			$lp->respuesta_correcta = $pregunta["clave"];
			$lp->codigo_pregunta = $pregunta["cod_pregunta"];
			$lp->save();
			arreglo($lp->orden);
		}	
		exit;
	}	
	
/*
	public function ingresoUniversidades(Request $request)
    {
		exit;
		
		$path = app_path('Http/Controllers/')."IIE/datos_txt/";
		$file = file($path."universidades.txt");
		foreach($file as $fileAux){
			$campos = explode("\t", $this->multibyte_trim($fileAux));
			$un["universidad"] = $this->multibyte_trim($campos[0]);
			$un["sede"] = $this->multibyte_trim($campos[1]);
			$un["direccion"] = $this->multibyte_trim($campos[2]);			
			$universidades[$this->multibyte_trim($campos[0])][] = $un;
		}	
		
		foreach($universidades as $nombre=>$universidad){
			$i = Institucion::where("nombre_institucion", $nombre)->first();
			if(!isset($i->nombre_institucion)){
				echo "no existe->".$i->nombre_institucion."<br/	>";
			}
			else{
				
			}
			foreach($universidad as $sedes){
				$s = InstitucionCampus::where("nombre_sede", $sedes["sede"])->where("institucionestudios_id", $i->id)->first();				
				if(!isset($s->nombre_sede)){
					echo "no hay sede<br/>";
				}
				else{
					$s->direccion_sede = $this->multibyte_trim($sedes["direccion"]);
					$s->save();
				}
			}
		}
	}	
	
*/


	public function ingresoEstudiantes(Request $request)
    {
		//https://www.diagnosticafid.cl/public/ingreso-estudiantes
		exit;
		$nominaNombre = 'nuevos_enero2.txt';
		$id_excel_iie = 18212;
		
		$cont = 0;
		
		
		//ID DE COMUNA
		$comuna_reside = comunas::get();
		foreach($comuna_reside as $comunaReside){
			$comunaReside->nombre_comuna = $this->multibyte_trim($comunaReside->nombre_comuna);
			$comunaReside->nombre_comuna = str_replace(" ","_", $comunaReside->nombre_comuna);
			$comunaReside->nombre_comuna = str_replace("a","á", mb_strtolower($comunaReside->nombre_comuna));
			$comunaReside->nombre_comuna = str_replace("e","é", mb_strtolower($comunaReside->nombre_comuna));
			$comunaReside->nombre_comuna = str_replace("i","í", mb_strtolower($comunaReside->nombre_comuna));
			$comunaReside->nombre_comuna = str_replace("o","ó", mb_strtolower($comunaReside->nombre_comuna));
			$comunaReside->nombre_comuna = str_replace("u","ú", mb_strtolower($comunaReside->nombre_comuna));
			$comunaReside->nombre_comuna = str_replace("n","ñ", mb_strtolower($comunaReside->nombre_comuna));
			$comunaReside->nombre_comuna = str_replace("ñ","ni", mb_strtolower($comunaReside->nombre_comuna));
			
			//$comunaReside->nombre_comuna = trim($comunaReside->nombre_comuna);
			$cId[mb_strtolower($comunaReside->nombre_comuna)] = $comunaReside->id;
		}
		unset($comuna_reside);
	
		//ID DE SEDE
		$institucionestudios = DB::select("SELECT institucionestudios.nombre_institucion  as inst, nombre_sede, sedeinstitucion.id FROM institucionestudios, sedeinstitucion where institucionestudios.id =  sedeinstitucion.institucionestudios_id");
		foreach($institucionestudios as $_institucionestudios){
			$sedeId[$_institucionestudios->inst."----".$_institucionestudios->nombre_sede] = $_institucionestudios->id;
		}
		unset($institucionestudios);

		//ID DE CARRERA		
		$carrera = Carrera::get();
		foreach($carrera as $carreras){
			$carrerasId[mb_strtolower($carreras->carrera)] = $carreras->id_carrera;
		}
		unset($carrera);
		

		$noCarrera = array();
		$path = app_path('Http/Controllers/')."IIE/datos_txt/nomina_alumnos/";
		$file = file($path.$nominaNombre);
		
		//verificamos que no hayan rut que ya estén en bd
		$hayRepetidos = false;
		foreach($file as $fileAux){
			$campos = explode("\t", trim($fileAux));
			$el = EstudianteListado::where("rut", trim($campos[20])."-".trim(strtoupper($campos[21])))->first();
			if(isset($el->id)){
				$hayRepetidos=true;
				echo "'".$el->rut."',";
			}
		}		
		if($hayRepetidos=='true') {
			exit;
		}
		
		
		DB::beginTransaction();
		try{
			foreach($file as $fileAux){
				$campos = explode("\t", trim($fileAux));

				// [0] => Institución
				// [1] => Número Región Sede Institución
				// [2] => Nombre Región Sede Institución
				// [3] => Comuna Sede
				// [4] => Dirección sede institución
				// [5] => Nombr Sede institución
				// [6] => Nombre original del programa o carrera
				// [7] => Nivel Carrera
				// [8] => Asignatura (Pedagogía en Educación Media)
				// [9] => Carrera oficial
				// [10] => Día Aplicación
				// [11] => Programa de prosecución de estudios
				// [12] => Título que otorga
				// [13] => Modalidad 1 (Presencial)
				// [14] => Modalidad 2 (Horario)
				// [15] => Año ingreso
				// [16] => Género
				// [17] => Nombres
				// [18] => Apellido paterno
				// [19] => Apellido materno
				// [20] => RUN
				// [21] => Dígito verificador del RUN
				// [22] => Número Región 
				// [23] => Nombre Región Residencia
				// [24] => Comuna residencia
				// [25] => mail1
				// [26] => Mail2
				// [27] => Código de área
				// [28] => Teléfono
				// [29] => Celular(9 dígitos)
				// [30] => Estudiante con discapacidad(indique en la siguiente columna qué tipo de discapacidad posee y que medios requiere para rendir la evaluación)
				// [31] => Discapacidad y medios necesarios para rendir la Evaluación
				// [32] => Estudiante rezagado
				// [33] => Observaciones (indicar cualquier otro elemento que considere relevante)

				
				//ID DE COMUNA
				$comunaResidencia = $campos[24];
				$cOriginal = $comunaResidencia;
				$comunaResidencia = $this->multibyte_trim($comunaResidencia);
				$comunaResidencia = str_replace(" ","_", $comunaResidencia);
				$comunaResidencia = str_replace("a","á", mb_strtolower($comunaResidencia));
				$comunaResidencia = str_replace("e","é", mb_strtolower($comunaResidencia));
				$comunaResidencia = str_replace("i","í", mb_strtolower($comunaResidencia));
				$comunaResidencia = str_replace("o","ó", mb_strtolower($comunaResidencia));
				$comunaResidencia = str_replace("u","ú", mb_strtolower($comunaResidencia));
				$comunaResidencia = str_replace("n","ñ", mb_strtolower($comunaResidencia));
				$comunaResidencia = str_replace("ñ","ni", mb_strtolower($comunaResidencia));
				
				$claveComuna = $comunaResidencia;
				//if(!array_key_exists($claveComuna, $cId)){
					// arreglo($campos);
					// arreglo($cId);
					// echo $cOriginal."<br/>";
				//	if(strtolower($campos[13])!='presencial'){
				//		echo "no existe comuna->".$claveComuna."|<br/>";	
				//	}
					
					
				//}
				//else{
					$clave = $this->multibyte_trim($campos[0])."----".$this->multibyte_trim($campos[5]);
					if(!array_key_exists($clave, $sedeId)){
						echo $clave;
						arreglo($sedeId);
						echo $this->multibyte_trim($campos[0])."->".$this->multibyte_trim($campos[5])."<br/>";
						echo "<br/>No existe sede en universidad<br/>";
						$s = DB::select("SELECT institucionestudios.nombre_excel as inst, nombre_sede, sedeinstitucion.id FROM institucionestudios, sedeinstitucion where institucionestudios.id =  sedeinstitucion.institucionestudios_id and nombre_excel = '".$campos[0]."'");
						echo "SELECT institucionestudios.nombre_excel as inst, nombre_sede, sedeinstitucion.id FROM institucionestudios, sedeinstitucion where institucionestudios.id =  sedeinstitucion.institucionestudios_id and nombre_excel = '".$campos[0]."'";
						echo "<br/>comuna_id:".$claveComuna."-->".$cId[$claveComuna]."<br/>";
						arreglo($campos);
						exit;
					}
					else{
						
						//ID DE CARRERA
						$nivelCarrera = $campos[9];
						//$asignaturaMedia = $this->multibyte_trim($campos[8]);
						//if(trim($nivelCarrera) == "Pedagogía en Educación Especial Diferencial"){
						//	$nivelCarrera = "Pedagogía en Educación Especial";
						//}
						//if(trim($asignaturaMedia) == ""){
						//	$asignaturaMedia = "Otro";
						//}
						
						// if(trim($nivelCarrera) == "Pedagogía en Educación Media"){
							// $cadenaCarrera = $nivelCarrera." (".$asignaturaMedia.")";
						// }
						// else{
							$cadenaCarrera = $this->multibyte_trim($nivelCarrera);				
						// }
						
						if(!array_key_exists(mb_strtolower($cadenaCarrera), $carrerasId)){
							//$noCarrera[$cadenaCarrera] = $cadenaCarrera;
							//echo $cadenaCarrera."<br/>";
							//arreglo($carrerasId);
							//arreglo($campos);
							//exit;
							//echo "1<br/>";
							echo trim($campos[20])."<br/>";
						}	
						else{
							$idCarrera = $carrerasId[mb_strtolower($cadenaCarrera)];
							if(array_key_exists($clave, $sedeId)){
								$idSede = $sedeId[$clave];
								
								$idComunaReside = (array_key_exists($claveComuna, $cId))?$cId[$claveComuna]:15203;
								$idGenero = ($this->multibyte_trim(mb_strtolower($campos[16]))=='masculino')?47:46;
								
								$estudianteListado = new EstudianteListado();			
								$estudianteListado->sedeinstitucion_id = $idSede;
								$estudianteListado->id_comuna = $idComunaReside;
								$estudianteListado->id_carrera = $idCarrera;
								$estudianteListado->id_genero = $idGenero;	
								$estudianteListado->rut = trim($campos[20])."-".trim(strtoupper($campos[21]));
								$estudianteListado->nombres = trim($campos[17]);
								$estudianteListado->apellido_paterno = trim($campos[18]);
								$estudianteListado->apellido_materno = trim($campos[19]);
								$estudianteListado->direccion_residencia = "";
								$estudianteListado->email1 = (array_key_exists(25,$campos))?utf8_encode($this->multibyte_trim(strtolower($campos[25]))):null;
								if(array_key_exists(26, $campos)){
									$estudianteListado->email2 = utf8_encode($this->multibyte_trim(strtolower($campos[26])));	
								}	
								else{
									$estudianteListado->email2 = "";
								}
								
								if((array_key_exists(27, $campos))&&(array_key_exists(28, $campos))){
									$estudianteListado->telefono_fijo = (($campos[27]!="")&&($campos[28]!=""))?trim($campos[27])."-".trim($campos[28]):"";		
								}	
								else{
									$estudianteListado->telefono_fijo = "";
								}	
								
								$estudianteListado->telefono_movil = (array_key_exists(29, $campos))?trim($campos[29]):null;
								$estudianteListado->fecha_nacimiento = null;

								
								if(strtolower($campos[13])=='no presencial'){
									$estudianteListado->modalidad_estudio = 51;
								}
								elseif(strtolower($campos[13])=='presencial'){
									$estudianteListado->modalidad_estudio = 52;
								}	
								elseif(strtolower($campos[13])=='semipresencial'){
									$estudianteListado->modalidad_estudio = 53;
								}	

								
								
								$estudianteListado->modalidad_horario = trim($campos[14]);

								if(strtolower(trim($campos[14]))=='diurno'){
									$estudianteListado->modalidad_horario = 48;
								}
								elseif(strtolower(trim($campos[14]))=='jornada diurna'){
									$estudianteListado->modalidad_horario = 48;
								}	
								elseif(strtolower(trim($campos[14]))=='no aplica'){
									$estudianteListado->modalidad_horario = 49;
								}	
								elseif(strtolower(trim($campos[14]))=='vespertino'){
									$estudianteListado->modalidad_horario = 50;
								}	
								else{
									$estudianteListado->modalidad_horario = null;
									//echo "campo modo estudio raro";
									//arreglo($campos);exit;
								}							

								
								$estudianteListado->extra_nom_orig_carrera = $this->multibyte_trim($campos[6]);
								$estudianteListado->extra_nivel_carrera = $this->multibyte_trim($campos[7]);
								$estudianteListado->extra_asignatura = $this->multibyte_trim($campos[8]);
								//$estudianteListado->dia_aplicacion = $this->multibyte_trim($campos[10]);
								$estudianteListado->extra_prosecucion = ($this->multibyte_trim(mb_strtolower($campos[11]))=='no')?false:true;
								$estudianteListado->extra_titulo_otorga = $this->multibyte_trim($campos[12]);
								$estudianteListado->anio_ingreso = ($this->multibyte_trim($campos[15])!="")?$this->multibyte_trim($campos[15]):null;

					
								//$estudianteListado->anio_ingreso = null;//(isset($campos[15]))?trim($campos[15]):null;
								
								if(array_key_exists(30, $campos)){
									$estudianteListado->con_discapacidad = ($this->multibyte_trim(strtolower($campos[30]))=='no')?false:true;
								}
								else{
									$estudianteListado->con_discapacidad = false;
								}

								if(array_key_exists(31, $campos)){
									$estudianteListado->medios_necesarios = trim($campos[31]);	
								}	
								else{
									$estudianteListado->medios_necesarios = "";	
								}
								
								if(array_key_exists(32, $campos)){
									$estudianteListado->rezagado = trim($campos[32]);			
								}							
								else{
									$estudianteListado->rezagado = "";			
								}
								
								if(array_key_exists(33,$campos)){
									$estudianteListado->observaciones = trim($campos[33]);				
								}
								else{
									$estudianteListado->observaciones = "";
								}
								$cont++;
								$estudianteListado->id_excel_iie = $id_excel_iie;
								$estudianteListado->pasa_a_enero = true;
								$estudianteListado->complementaria = true;
								$estudianteListado->es_nuevo = true;
								$estudianteListado->save();	
								$id_excel_iie++;
								
								
							}		
							else{
								arreglo($campos);
								echo $clave."<br/>";
								echo "no existe sede->".$clave."|";
								exit;						
							}
						}				
					}
					
				//}
			}			
			
		}
		catch(\Exception $ex){
			DB::rollback();
			dd($ex);
			//echo $ex->getMessage();
			return false;
		}
		DB::commit();		

		arreglo($noCarrera);
		echo $cont;		
    } 
	



    public function modificaLabs(Request $request)
    {
		
		exit;
		
		//modifica labs
		$path = app_path('Http/Controllers/')."IIE/datos_txt/asignacion/";
		$file = file($path."infraestructura.txt");
		$total = array();
		foreach($file as $fileAux){
			$fileAux = trim($fileAux);
			$campos = explode("\t", trim($fileAux));
			$cod = $campos[0];
			$direccion = $campos[1];
			
			//$x = Dependencias::where("lab_cod_iie", $cod)->first();
			//if(isset($x->id)){
				//$x->direccion_dep = $direccion;
				//$x->save();
			//}
			//else{
				//echo "a";
			//}
			// if(!@in_Array($direccion, $x[$universidad][$sedeCampus])){
				// $x[$universidad][$sedeCampus][] = $direccion; 	
			// }
			
			
			// $centroInstitucion = CentroInstitucion::where("nombre_institucion",$this->multibyte_trim($universidad))->first();
			// $arr[$centroInstitucion][] = $this->multibyte_trim($sedeCampus))
			// if(isset($centroInstitucion->id_centro_institucion)){
				// $centroAplicacion = CentroAplicacion::where("nombre_sede",$this->multibyte_trim($sedeCampus))->where("centro_institucion_id",$centroInstitucion->id_centro_institucion)->first();
				// if(!isset($centroAplicacion->id)){
					// echo $this->multibyte_trim($sedeCampus)."<br/>";
				// }
				// else{
					// $centroAplicacion->direccion = $direccion; 
					// //$centroAplicacion->save();
				// }
			// }
			// else{
				// echo $this->multibyte_trim($universidad);
			// }
			
			
			//if(isset($campos[1])){
			//	if($campos[1]=='Cumple'){
					//$dependencias->estado_habilitacion_id = 102;	
					//@$total["Cumple"]++;
			//	}
				// elseif($campos[1]=='No Cumple'){
					// $dependencias->estado_habilitacion_id = 103;	
					// @$total["NOCumple"]++;
				// }
				// elseif($campos[1]=='Cumple con observación'){
					// $dependencias->estado_habilitacion_id = 110;	
					// @$total["CumpleObs"]++;
				// }
				// else{
					// $dependencias->estado_habilitacion_id = 111;	
					// @$total["no aplica"]++;
				// }
			//}
			//else{
			//	$dependencias->estado_habilitacion_id = 111;	
			//	@$total["no aplica"]++;
			//}
			//$dependencias->save();
			
		}
		//arreglo($x);
	}	
	
    public function ingresaLaboratorios(Request $request)
    {
		exit;
		// $dependencias->nombre_encargado = isset($campos[$index_encargado])?$this->multibyte_trim($campos[$index_encargado]):null;
		// $dependencias->telefono_dependencia = isset($campos[$index_telefono])?$this->multibyte_trim($campos[$index_telefono]):null;
		// $dependencias->correo_dependencia	= isset($campos[$index_correo])?$this->multibyte_trim($campos[$index_correo]):null;
		// $dependencias->persona_disponible_apertura = isset($campos[$index_encargado_apertura])?$this->multibyte_trim($campos[$index_encargado_apertura]):null;
		// $dependencias->observaciones_dependencia = isset($campos[$index_observaciones])?$this->multibyte_trim($campos[$index_observaciones]):null;
				
		
		//truncate table aplicaciones
		//truncate table evaluadosaplicaciones
		//truncate table aplicaciones_has_tiposcontingencia
		//truncate table dependencias
		//truncate table centrosaplicacion
		//truncate table centro_institucion
		

		
		$path = app_path('Http/Controllers/')."IIE/datos_txt/asignacion/";
		$file = file($path."infraestructuraEnero2.txt");

		$index_cod = 0;
		$index_region = 1;
		$index_universidad = 2;
		$index_comuna = 4;
		$index_sede = 6;
		$index_facultad = 7;
		$index_direccion = 8;
		$index_nombrelab = 9;
		$index_encargado = 13;
		$index_con_holgura = 16;
		$index_sin_holgura = 17;
		$index_telefono = 14;
		//$index_correo = 13;
		//$index_encargado_apertura = 14;
		//$index_observaciones = 15;
		//$index_res_revision = 16;

		// $index_dia1 = 10;
		// $index_dia2 = 11;
		// $index_dia3 = 12;
		// $index_dia4 = 13;
		// $index_confirmado = 7;
		
		foreach($file as $fileAux){
			$fileAux = trim($fileAux);
			$campos = explode("\t", trim($fileAux));
			//arreglo($campos);exit;
			//if(mb_strtolower(trim($campos[$index_confirmado])) != mb_strtolower(trim('Cumple'))){
			//if(isset($campos[$index_res_revision]))	{
				//if((mb_strtolower(trim($campos[$index_res_revision])) == mb_strtolower(trim('Cumple')))||
				//	(mb_strtolower(trim($campos[$index_res_revision])) == mb_strtolower(trim('Cumple con observación')))){				
					$laboratorios[$this->multibyte_trim($campos[$index_universidad])][$this->multibyte_trim($campos[$index_comuna])][$this->multibyte_trim($campos[$index_sede])][] = $campos;
				//}
			//}
		}	
		
		DB::beginTransaction();
		try{
			foreach($laboratorios as $universidad => $universidades){
				$centroInstitucion = CentroInstitucion::where("nombre_institucion", $this->multibyte_trim($universidad))->first();
				if(!isset($centroInstitucion->id_centro_institucion)){
					// echo "no existe CentroInstitucion->".$this->multibyte_trim($universidad)."<br>";
					// $centroInstitucion = new CentroInstitucion();
					// $centroInstitucion->nombre_institucion = $this->multibyte_trim($universidad);
					// $centroInstitucion->save();
				}
				else{
					//echo $centroInstitucion->nombre_institucion."<br/>";
				}
				
				foreach($universidades as $comuna=>$comunas){
					
					$_comunas = comunas::where('nombre_comuna', trim($comuna))->first();
					
					if(!isset($_comunas->id)){
						echo $universidad."-";
						echo $comuna."--------->";exit;
					}
					
					foreach($comunas as $sede => $sedes){
						//arreglo($sedes);exit;
						
						//ingresamos la sede 
						$centroAplicacion = CentroAplicacion::where("nombre_sede",$this->multibyte_trim($sede))->where("centro_institucion_id",$centroInstitucion->id_centro_institucion)->first();
						if(!isset($centroAplicacion->id)){
							//echo "crear centro->".$centroInstitucion->nombre_institucion."--".$this->multibyte_trim($sede)."<br/>";
							// $centroAplicacion = new CentroAplicacion;
							// $centroAplicacion->id_comuna = $_comunas->id;
							// $centroAplicacion->centro_institucion_id = $centroInstitucion->id_centro_institucion;
							// $centroAplicacion->nombre_sede = $this->multibyte_trim($sede);
							// $centroAplicacion->direccion = $sedes[0][$index_direccion];
							// $centroAplicacion->save();
						}
						else{
							//echo "creado-".$centroAplicacion->nombre_sede."<br/>";
						}
						
						foreach($sedes as $_laboratorios){
							$depTemp = Dependencias::where('lab_cod_iie', trim($_laboratorios[$index_cod]))->first();
							//dd($depTemp);
							if(!isset($depTemp->lab_cod_iie)){
								$dependencias = new Dependencias();
								$dependencias->nombre_dependencia = $_laboratorios[$index_nombrelab];
								$dependencias->centrosaplicacion_id = $centroAplicacion->id;
								 
								$_laboratorios[$index_con_holgura] = ($_laboratorios[$index_con_holgura]=="")?0:$_laboratorios[$index_con_holgura];
								$_laboratorios[$index_sin_holgura] = ($_laboratorios[$index_sin_holgura]=="")?0:$_laboratorios[$index_sin_holgura];
								$dependencias->equipos_disponibles = $_laboratorios[$index_con_holgura];
								$dependencias->equipos_contingencia = $_laboratorios[$index_con_holgura]-$_laboratorios[$index_sin_holgura];
								$dependencias->estado_habilitacion_id = 102;//(mb_strtolower(trim($_laboratorios[$index_res_revision])) != mb_strtolower(trim('Cumple')))?'103':'102';
								$dependencias->lab_cod_iie = trim($_laboratorios[$index_cod]);
								$dependencias->facultad_sector	 = $this->multibyte_trim($_laboratorios[$index_facultad]);
								$dependencias->nombre_encargado = isset($_laboratorios[$index_encargado])?$this->multibyte_trim($_laboratorios[$index_encargado]):null; 
								$dependencias->telefono_dependencia = isset($_laboratorios[$index_telefono])?$this->multibyte_trim($_laboratorios[$index_telefono]):null;
								//$dependencias->correo_dependencia	= isset($_laboratorios[$index_correo])?$this->multibyte_trim($_laboratorios[$index_correo]):null;
								//$dependencias->persona_disponible_apertura = isset($_laboratorios[$index_encargado_apertura])?$this->multibyte_trim($_laboratorios[$index_encargado_apertura]):null;
								//$dependencias->observaciones_dependencia = isset($_laboratorios[$index_observaciones])?$this->multibyte_trim($_laboratorios[$index_observaciones]):null;
								//dd($dependencias);
								$dependencias->save();
								
							}
							else{
								// $dependencias = $depTemp;
								// $dependencias->nombre_dependencia = $_laboratorios[$index_nombrelab];
								// //$dependencias->centrosaplicacion_id = $centroAplicacion->id;
								 
								// $_laboratorios[$index_con_holgura] = ($_laboratorios[$index_con_holgura]=="")?0:$_laboratorios[$index_con_holgura];
								// $_laboratorios[$index_sin_holgura] = ($_laboratorios[$index_sin_holgura]=="")?0:$_laboratorios[$index_sin_holgura];
								// $dependencias->equipos_disponibles = $_laboratorios[$index_con_holgura];
								// $dependencias->equipos_contingencia = $_laboratorios[$index_con_holgura]-$_laboratorios[$index_sin_holgura];
								// //$dependencias->estado_habilitacion_id = 102;//(mb_strtolower(trim($_laboratorios[$index_res_revision])) != mb_strtolower(trim('Cumple')))?'103':'102';
								// //$dependencias->lab_cod_iie = trim($_laboratorios[$index_cod]);
								// $dependencias->facultad_sector	 = $this->multibyte_trim($_laboratorios[$index_facultad]);
								// $dependencias->nombre_encargado = isset($_laboratorios[$index_encargado])?$this->multibyte_trim($_laboratorios[$index_encargado]):null; 
								// $dependencias->telefono_dependencia = isset($_laboratorios[$index_telefono])?$this->multibyte_trim($_laboratorios[$index_telefono]):null;
								// //$dependencias->correo_dependencia	= isset($_laboratorios[$index_correo])?$this->multibyte_trim($_laboratorios[$index_correo]):null;
								// //$dependencias->persona_disponible_apertura = isset($_laboratorios[$index_encargado_apertura])?$this->multibyte_trim($_laboratorios[$index_encargado_apertura]):null;
								// //$dependencias->observaciones_dependencia = isset($_laboratorios[$index_observaciones])?$this->multibyte_trim($_laboratorios[$index_observaciones]):null;
								// //dd($dependencias);
								// $dependencias->save();
								
							}
							 
						}	
					}	
				}
				//exit;	
			}
			
		}
		catch(\Exception $ex){

			DB::rollback();
			dd($ex);
			//echo $ex->getMessage();
			return false;
		}
		DB::commit();		
		
	}
	
	function multibyte_trim($str)
	{
		if (!function_exists("mb_trim") || !extension_loaded("mbstring")) {
			return preg_replace("/(^\s+)|(\s+$)/u", "", $str);
		} else {
			return mb_trim($str);
		}
	}	



/*	
    // public function asignaIdExcel(Request $request)
    // {
		// $path = app_path('Http/Controllers/')."IIE/datos_txt/nomina_alumnos/";
		// $file = file($path."nomina_final_alumnos.txt");
		// $cont = 1;
		// foreach($file as $fileAux){
			// $campos = explode("\t", trim($fileAux));
			// $rut = strtoupper($this->multibyte_trim($campos[20])."-".$this->multibyte_trim($campos[21]));		
			// $est = EstudianteListado::where("rut",$rut)->first();
			// if(!isset($est)){
				// $rut = strtolower($this->multibyte_trim($campos[20])."-".$this->multibyte_trim($campos[21]));		
				// $est = EstudianteListado::where("rut",$rut)->first();
			// }
			
			// if(isset($est)){
				// // $est->nom_orig_carrera = $this->multibyte_trim($campos[0]);
				// // $est->nivel_carrera = $this->multibyte_trim($campos[1]);
				// // $est->asignatura = $this->multibyte_trim($campos[2]);
				// // $est->dia_aplicacion = $this->multibyte_trim($campos[3]);
				// // $est->prosecucion = ($this->multibyte_trim(mb_strtolower($campos[4]))=='si')?true:false;
				// // $est->titulo_otorga = $this->multibyte_trim($campos[5]);
				// // $est->anio_ingreso = ($this->multibyte_trim($campos[6])!="")?$this->multibyte_trim($campos[6]):null;
				// // $est->save();
				// $est->id_excel_iie = $cont;
				// $est->save();
				
				// $cont++;
			// }
			// else{

				// echo $rut."<br/>";
				// arreglo($campos);
				// echo "no existe alumno<br>";	
			// }
		// }
		// echo $cont;
	// }	

*/

/*	
    // public function comparaCambios(Request $request)
    // {
		// $path = app_path('Http/Controllers/')."IIE/datos_txt/nomina_alumnos/";
		// $file = file($path."nomina_final_alumnos.txt");
		// $cont = 1;
		// foreach($file as $fileAux){
			// $campos = explode("\t", trim($fileAux));
			// //$rut = strtoupper($this->multibyte_trim($campos[20])."-".$this->multibyte_trim($campos[21]));		
			// $est = EstudianteListado::where("id_excel_iie", $cont)->first();
			// //if(!isset($est)){
			// //	$rut = strtolower($this->multibyte_trim($campos[20])."-".$this->multibyte_trim($campos[21]));		
			// //	$est = EstudianteListado::where("rut",$rut)->first();
			// //}
			
			// if(isset($est)){
				// // [0] => Institución
				// // [1] => Número Región Sede Institución
				// // [2] => Nombre Región Sede Institución
				// // [3] => Comuna Sede
				// // [4] => Dirección sede institución
				// // [5] => Nombr Sede institución
				// // [6] => Nombre original del programa o carrera
				// // [7] => Nivel Carrera
				// // [8] => Asignatura (Pedagogía en Educación Media)
				// // [9] => Carrera oficial
				// // [10] => Día Aplicación
				// // [11] => Programa de prosecución de estudios
				// // [12] => Título que otorga
				// // [13] => Modalidad 1 (Presencial)
				// // [14] => Modalidad 2 (Horario)
				// // [15] => Año ingreso
				// // [16] => Género
				// // [17] => Nombres
				// // [18] => Apellido paterno
				// // [19] => Apellido materno
				// // [20] => RUN
				// // [21] => Dígito verificador del RUN
				// // [22] => Número Región 
				// // [23] => Nombre Región Residencia
				// // [24] => Comuna residencia
				// // [25] => mail1
				// // [26] => Mail2
				// // [27] => Código de área
				// // [28] => Teléfono
				// // [29] => Celular(9 dígitos)
				// // [30] => Estudiante con discapacidad(indique en la siguiente columna qué tipo de discapacidad posee y que medios requiere para rendir la evaluación)
				// // [31] => Discapacidad y medios necesarios para rendir la Evaluación
				// // [32] => Estudiante rezagado
				// // [33] => Observaciones (indicar cualquier otro elemento que considere relevante)
				
				
				// $institucionCampus = InstitucionCampus::find($est->sedeinstitucion_id);
				// $institucion = Institucion::find($institucionCampus->institucionestudios_id);
				// $carrera = Carrera::find($est->id_carrera);
				// if(($this->multibyte_trim(mb_strtolower($campos[0]))!=$this->multibyte_trim(mb_strtolower($institucion->nombre_institucion)))||
					// ($this->multibyte_trim(mb_strtolower($campos[5]))!=$this->multibyte_trim(mb_strtolower($institucionCampus->nombre_sede)))||
					// ($this->multibyte_trim(mb_strtolower($campos[9]))!=$this->multibyte_trim(mb_strtolower($carrera->carrera)))){
					// echo $campos[20]."-".$campos[21]."-->".$campos[0]."->".$campos[5]."-->".$campos[9]."<br/><br/>";
					// echo $est->rut."-->".$institucion->nombre_institucion."->".$institucionCampus->nombre_sede."->".$carrera->carrera;
					// echo "<br/>-------------------------------------------------------------------------------------------------------<br/>";
				// }
			// }
			// else{
				// echo $rut."<br/>";
				// arreglo($campos);
				// echo "no existe alumno<br>";	
			// }
			// $cont++;
		// }
		// echo $cont;
	// }	

*/

/*	
    // public function ingresoEstudiantesDatosExtras(Request $request)
    // {
		
		// exit;
		
		// $path = app_path('Http/Controllers/')."IIE/datos_txt/nomina_alumnos/";
		// $file = file($path."faltantes.txt");
		// $cont = 0;
		// foreach($file as $fileAux){
			// $campos = explode("\t", trim($fileAux));
			
			// // [0] => PEDAGOGÍA EN EDUCACIÓN DIFERENCIAL MENCIÓN TRASTORNOS DE AUDICIÓN Y LENGUAJE - SEGUNDO TÍTULO
			// // [1] => Pedagogía en Educación Especial Diferencial
			// // [2] => 
			// // [3] => Día 2
			// // [4] => Si
			// // [5] => PROFESOR/A / EDUCADOR/A ESPECIAL / DIFERENCIAL
			// // [6] => 2017			
			
			// $rut = strtoupper($this->multibyte_trim($campos[7])."-".$this->multibyte_trim($campos[8]));		
			// $est = EstudianteListado::where("rut",$rut)->first();
			// if(!isset($est)){
				// $rut = strtolower($this->multibyte_trim($campos[7])."-".$this->multibyte_trim($campos[8]));		
				// $est = EstudianteListado::where("rut",$rut)->first();
			// }
			
			// if(isset($est)){
				// $est->nom_orig_carrera = $this->multibyte_trim($campos[0]);
				// $est->nivel_carrera = $this->multibyte_trim($campos[1]);
				// $est->asignatura = $this->multibyte_trim($campos[2]);
				// $est->dia_aplicacion = $this->multibyte_trim($campos[3]);
				// $est->prosecucion = ($this->multibyte_trim(mb_strtolower($campos[4]))=='si')?true:false;
				// $est->titulo_otorga = $this->multibyte_trim($campos[5]);
				// $est->anio_ingreso = ($this->multibyte_trim($campos[6])!="")?$this->multibyte_trim($campos[6]):null;
				// $est->save();
				// echo $cont++;
			// }
			// else{
				// echo $rut."<br/>";
				// arreglo($campos);
				// echo "no existe alumno<br>";	
			// }
		// }
		// echo $cont;
	// }
 */   
	//DB::select("truncate table evaluados cascade");
	
}