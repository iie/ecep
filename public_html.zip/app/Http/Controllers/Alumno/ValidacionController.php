<?php
namespace App\Http\Controllers\Alumno;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Models\Infraestructura\Institucion;
use App\Models\Infraestructura\Sede;

use App\Models\Evaluado\Evaluado;
use App\Models\Evaluado\EvaluadoAccion;
use App\Models\Evaluado\EvaluadoModificacion;
use App\Models\Evaluado\Carrera;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use PHPMailer\PHPMailer;
use Mail;

class ValidacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	 
	public function __construct()
    {
		$this->fields = array();	

    }	
 
    public function index()
    {
        
    }

    public function login(Request $request)
    {
		header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
		header("Pragma: no-cache"); // HTTP 1.0.
		header("Expires: 0"); // Proxies.

		$institucion = Institucion::where("participa", true)->where("borrado", false)->orderBy('institucion')->get();
		$this->fields["institucion"] = $institucion;
		$request->session()->put('id_estudiante', '');
		return view('validacion/login', $this->fields);
    }
	
    public function loginAccion(Request $request)
    {
		header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
		header("Pragma: no-cache"); // HTTP 1.0.
		header("Expires: 0"); // Proxies.
		
		$post = $request->all();

		$enableCaptcha = false;
		$grecaptcha;

		if($enableCaptcha){
			if(isset($post['g-recaptcha-response'])){
				$grecaptcha = $post['g-recaptcha-response'];
			}
			else{
				unset($estudiante);
				return redirect()->route('validacion-estudiante.login')->withFlashDanger("reCaptcha: Por favor verifique que es una persona a través de reCaptcha.")->withInput();
			}

			$secretKey = "6LeeyjgUAAAAAAkU0tfwQ54kqlfIKUauU20EX4og";
			$remoteIP = $_SERVER['REMOTE_ADDR'];

			$captchaAPIData = array(
		            'secret' => $secretKey,
		            'response' => $grecaptcha,
		            'remoteip' => $remoteIP,
		    );

			$verify = curl_init();
			curl_setopt($verify, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");
			curl_setopt($verify, CURLOPT_POST, true);
			curl_setopt($verify, CURLOPT_POSTFIELDS, http_build_query($captchaAPIData));
			curl_setopt($verify, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($verify, CURLOPT_RETURNTRANSFER, true);
			$grecaptchaAPIResponse = curl_exec($verify);
		}

		$auxFlag;

		if(!isset($grecaptchaAPIResponse)){
			$auxFlag = false;
		}
		elseif(json_decode($grecaptchaAPIResponse)->success){
			$auxFlag = true;
		}
		else{
			$auxFlag = false;
		}

		if(($enableCaptcha && $auxFlag) || (!$enableCaptcha && !$auxFlag)){

			$this->validate($request, [
				'rut' => 'required',
				'id_institucion' => 'required|integer',
				/*'clave' => 'required',*/
			]);		
			
			$post["rut"] = mb_strtoupper(trim($post["rut"]));
			$post["rut"] = str_replace(".","",$post["rut"]);//quitamos los puntos
			$post["rut"] = str_replace("-","",$post["rut"]);//quitamos los guiones
			$rutNro = substr($post["rut"], 0, strlen($post["rut"])-1);
			$rutDigito = substr($post["rut"], -1);
			
			$post["rut"] = $rutNro."-".$rutDigito;
			
			$estudiante = Evaluado::where('rut', $post["rut"])->where('borrado', false)->first();
			
			if(isset($estudiante->id_evaluado)){
				/*				
				68 descargaResultados	
				67 clic_link	
				66 validaDatos
				65 ingreso					
				*/
				$evaluadoIngreso = new EvaluadoAccion;
				$evaluadoIngreso->id_evaluado = $estudiante->id_evaluado;
				$evaluadoIngreso->id_accion = 65;
				$evaluadoIngreso->save();
				
				// if(!$estudiante->rinde_en_enero){
					// unset($estudiante);
					// return redirect()->route('validacion-estudiante.login')->withFlashDanger("Usted no está convocado para la aplicación de Marzo. Contáctese con su Universidad para mayor información.")->withInput();
				// }
				
				//**********************PARA ENVIO DE RESULTADOS
				// $envioResultados = EnvioResultados::where('id_excel', $estudiante->id_excel)->first();
				// if(!isset($envioResultados->id_envio_resultados)){
					// return redirect()->route('validacion-estudiante.login')->withFlashDanger("La clave que ha ingresado es incorrecta.")->withInput();
				// }
				// else{
					// if($envioResultados->clave!=$post["clave"]){
						// return redirect()->route('validacion-estudiante.login')->withFlashDanger("La clave que ha ingresado es incorrecta.")->withInput();
					// }
				// }
				//**********************FIN PARA ENVIO DE RESULTADOS
				
				//valido que el rut ingresado sea de la universidad ingresada
				$campus = Sede::find($estudiante->id_sede);	
				if($campus->id_institucion != $post["id_institucion"]){
					unset($estudiante);
					return redirect()->route('validacion-estudiante.login')->withFlashDanger("La universidad seleccionada no corresponde al RUN ingresado.")->withInput();
				}
				
				$request->session()->put('id_estudiante', $estudiante->id_evaluado);
				
				if($estudiante->validado==true){
					return redirect()->route('validacion-estudiante.gracias');
				}
				
				//**********************PARA VALIDAR DATOS
				//$request->session()->put('primera_vez', true);
				return redirect()->route('validacion-estudiante.edit');
				//**********************FIN PARA VALIDAR DATOS
				
				//**********************PARA DESCARGAR PDF
				//$request->session()->put('primera_vez', false);
				//return redirect()->route('validacion-estudiante.descarga-pdf');
				//**********************FIN PARA DESCARGAR PDF
			}
			else{
				unset($estudiante);
				return redirect()->route('validacion-estudiante.login')->withFlashDanger("No existe el RUN ingresado, consulta con tu universidad si fueron enviados tus antecedentes.")->withInput();
			}
		}
		else{
			unset($estudiante);
			return redirect()->route('validacion-estudiante.login')->withFlashDanger("reCaptcha: Navegación sospechosa. Por favor inténtelo más tarde.")->withInput();
		}	
    }	
	
    public function edit(Request $request)
    {
		
		$id_estudiante = $request->session()->get('id_estudiante');     
		if(!$id_estudiante){
			return redirect()->route('validacion-estudiante.login');
		}
		
		$estudiante = Evaluado::find($id_estudiante);
		
		//NO EXISTE EL ALUMNO
		if($estudiante == null){
			return redirect()->route('validacion-estudiante.login');
		}			
		
		$this->fields["rut"] = $estudiante->rut;
		$this->fields["nombres"] = $estudiante->nombres;
		$this->fields["apellido_paterno"] = $estudiante->apellido_paterno;
		$this->fields["apellido_materno"] = $estudiante->apellido_materno;
		$this->fields["email1"] = ($estudiante->email1!="")?$estudiante->email1:"sin_correo";
		$this->fields["email2"] = $estudiante->email2;
		$this->fields["telefono_fijo"] = $estudiante->telefono_fijo;
		$this->fields["telefono_movil"] = $estudiante->telefono_movil;
		
		//************** CAMPUS
		$institucionCampus = Sede::find($estudiante->id_sede);
		$this->fields["id_campus"] = $estudiante->id_sede;		
		$this->fields["sede"] = $institucionCampus["nombre"];
		
		//************** UNIVERSIDAD
		$universidadAlumno = Institucion::find($institucionCampus->id_institucion);
		$this->fields["id_institucion"] = $universidadAlumno->id_institucion;		
		$this->fields["universidad"] = $universidadAlumno->institucion;
		
		//************** CARRERA
		$carrera = Carrera::find($estudiante->id_carrera);		
		$this->fields["id_carrera"] = $estudiante->id_carrera;		
		$this->fields["carrera"] = $carrera->carrera;		
		
		$sql= "SELECT nombre as nombre_prueba
				FROM evaluado.evaluado as evaluado, evaluado.prueba as prueba, evaluado.carrera_prueba as carrera_prueba
				WHERE carrera_prueba.id_carrera = evaluado.id_carrera
				and carrera_prueba.id_prueba = prueba.id_prueba
				and evaluado.id_evaluado = ".$estudiante->id_evaluado;							
		
		$x = DB::select($sql);

		if(count($x)>0){
			$this->fields["prueba1"] = $x[0]->nombre_prueba;
			$this->fields["prueba1_asignatura"] = "";
			
			$this->fields["prueba2"] = $x[1]->nombre_prueba;
			$this->fields["prueba2_asignatura"] = "";
			
			$this->fields["prueba3"] = "";
			$this->fields["prueba3_asignatura"] = "";
			
			$this->fields["ocultaPrueba3"] = '';
			
			
			if(array_key_exists(2, $x)){
				$this->fields["prueba3"] = $x[2]->nombre_prueba;
			}
			else{
				$this->fields["ocultaPrueba3"] = 'style="display:none;"';
			}
			
		}
		else{
			$this->fields["prueba1"] = "";
			$this->fields["prueba1_asignatura"] = "";
			
			$this->fields["prueba2"] = "";
			$this->fields["prueba2_asignatura"] = "";
			
			$this->fields["prueba3"] = "";
			$this->fields["prueba3_asignatura"] = "";
			
			$this->fields["ocultaPrueba3"] = 'style="display:none;"';
		}

		// $salaAsignada = DB::select("SELECT c_sede.direccion, tipo_prueba, prueba, fecha_hora, id_estudiante, rut, nombre_sala, c_sede.sede, institucion, nombre_excel, fecha_hora, comuna.nombre as nombre_ciudad, c_sala.direccion as direccion_sede,
		// c_sala.facultad as facu

		// FROM ap_aplicacion_programacion, ap_prueba_carrera, ap_prueba, estudiante_listado, ap_estudiante_aplicacion, c_sala, ap_aplicacion, c_sede , institucion, comuna
		// WHERE ap_aplicacion_programacion.id_aplicacion_programacion = ap_prueba_carrera.id_aplicacion_programacion
		// AND c_sala.id_comuna = comuna.id_comuna
		// AND estudiante_listado.id = ap_estudiante_aplicacion.id_estudiante
		// AND ap_prueba.id_prueba = ap_aplicacion_programacion.id_prueba 
		// AND estudiante_listado.id_carrera = ap_prueba_carrera.id_carrera
		// AND c_sala.id_sala = ap_aplicacion.id_sala
		// AND ap_aplicacion.id_aplicacion = ap_estudiante_aplicacion.id_aplicacion
		// AND c_sala.id_sede = c_sede.id_sede
		// AND ap_aplicacion_programacion.id_tanda = 2
		// AND ap_aplicacion_programacion.id_aplicacion_programacion = ap_aplicacion.id_aplicacion_programacion
		// and rut = '".$estudiante->rut."'
		// AND institucion.id_institucion = c_sede.id_institucion
		// ORDER BY rut, fecha_hora, tipo_prueba, prueba, email1");	
		
		$txtSiInfo = "Sin información";
		$txtPorAsignar = "Por asignar";
		$txtPorAsignarFecha = "Presentarse";
		$this->fields["c_ciudad"] = $txtPorAsignar;
		$this->fields["c_institucion"] = $txtPorAsignar;
		$this->fields["c_sede"] = $txtPorAsignar;
		$this->fields["c_direccion_sede"] = $txtPorAsignar;
		$this->fields["c_sector_facultad"] = $txtPorAsignar;
		$this->fields["c_sala"] = $txtPorAsignar;
		$this->fields["c_fecha"] = $txtPorAsignarFecha;
		$this->fields["c_head"] = "Aún no te encuentras asignado/a a una sede/sala, te enviaremos un correo electrónico cuando la asignación esté preparada para que la puedas revisar.";

		//true / false
		$this->fields["habilita_box"] = false;
		//none / block
		$this->fields["display_box"] = "none";
		//none / block
		//$this->fields["display_fecha_hora"] = "none";
			
		if(isset($salaAsignada)){
			$this->fields["c_institucion"] = $salaAsignada[0]->nombre_institucion;
			$this->fields["c_ciudad"] = $this->mb_ucwords($salaAsignada[0]->nombre_ciudad);
			$this->fields["c_sede"] = $salaAsignada[0]->sede;
			$this->fields["c_direccion_sede"] = $salaAsignada[0]->direccion_sede;
			$this->fields["c_sector_facultad"] = ($salaAsignada[0]->facu!="")?$salaAsignada[0]->facu:$txtSiInfo;
			$this->fields["c_sala"] = $salaAsignada[0]->nombre_sala;
			$this->fields["c_fecha"] = $this->customFormatDate($salaAsignada[0]->fecha_hora);
			$this->fields["c_head"] = "Para rendir las pruebas que te corresponden, preséntate el día";
			//$this->fields["display_fecha_hora"] = "block";
		}
		
		return view('validacion/edit', $this->fields);	
		
    }

	public function editAccion(Request $request){
		
		$post = $request->all();

		$this->validate($request, [
			'nombres' => 'required',
			'apellido_paterno' => 'required',
		]);			

		$id_estudiante = $request->session()->get('id_estudiante'); 

		$estudiante = Evaluado::find($id_estudiante);
		if($estudiante == null){
			return redirect()->route('validacion-estudiante.login');
		}			
		
		if($estudiante->validado==true){
			return redirect()->route('validacion-estudiante.login')->withFlashDanger("Usuario ya validó sus datos")->withInput();
		}
		
		if($estudiante->nombres!=$post["nombres"]||
			$estudiante->apellido_paterno!=$post["apellido_paterno"]||
			$estudiante->apellido_materno!=$post["apellido_materno"]||
			$estudiante->email1!=$post["email1"]||
			$estudiante->email2!=$post["email2"]||
			$estudiante->telefono_fijo!=$post["telefono_fijo"]||
			$estudiante->telefono_movil != $post["telefono_movil"]){
				
			$evaluadoModificacion = new EvaluadoModificacion;
			$evaluadoModificacion->id_evaluado = $id_estudiante;
			$evaluadoModificacion->nombres = $estudiante->nombres;
			$evaluadoModificacion->apellido_paterno = $estudiante->apellido_paterno;
			$evaluadoModificacion->apellido_materno = $estudiante->apellido_materno;
			$evaluadoModificacion->email1 = $estudiante->email1;
			$evaluadoModificacion->email2 = $estudiante->email2;
			$evaluadoModificacion->telefono_fijo = $estudiante->telefono_fijo;
			$evaluadoModificacion->telefono_movil = $estudiante->telefono_movil;
			$evaluadoModificacion->fecha_modificacion = date("Y-m-d H:i:s");
			$evaluadoModificacion->save();

			$estudiante->nombres = $post["nombres"];
			$estudiante->apellido_paterno = $post["apellido_paterno"];
			$estudiante->apellido_materno = $post["apellido_materno"];
			$estudiante->email1 = mb_strtolower($post["email1"]);
			$estudiante->email2 = mb_strtolower($post["email2"]);
			$estudiante->telefono_fijo = $post["telefono_fijo"];
			$estudiante->telefono_movil = $post["telefono_movil"];
			$estudiante->correccion_obs = $post["correccion"];
		}

		$estudiante->link_validacion = $post["_token"].strrev($post["_token"]);
		$estudiante->validado = true;
		//$estudiante->save();

		/*				
		68 descargaResultados	
		67 clic_link	
		66 validaDatos
		65 ingreso					
		*/
		
		$evaluadoIngreso = new EvaluadoAccion;
		$evaluadoIngreso->id_evaluado = $estudiante->id_evaluado;
		$evaluadoIngreso->id_accion = 66;
		$evaluadoIngreso->save();
				
		$user["rut"] = $estudiante->rut;
		$user["nombres"] = $post["nombres"];
		$user["apellido_paterno"] = $post["apellido_paterno"];
		
		$user["apellido_materno"] = "No registrado";
		if($post["apellido_materno"]!=""){
			$user["apellido_materno"] = $post["apellido_materno"];
		}
		
		$user["email1"] = "No registrado";	
		if($post["email1"]!=""){
			$user["email1"] = $post["email1"];	
		}
		
		$user["email2"] = "No registrado";	
		if($post["email2"]!=""){
			$user["email2"] = $post["email2"];	
		}

		$user["telefono_fijo"] = "No registrado";	
		if($post["telefono_fijo"]!=""){
			$user["telefono_fijo"] = $post["telefono_fijo"];	
		}
		
		$user["telefono_movil"] = "No registrado";	
		if($post["telefono_movil"]!=""){
			$user["telefono_movil"] = $post["telefono_movil"];	
		}

		$user["correccion_obs"] ='';
		$user["mostrarObs"] = '';
		if(isset($post["correccion"])){
			if($post["correccion"]!=""){
				$user["correccion_obs"] = $post["correccion"];	
			}
			else{
				$user["mostrarObs"] = 'style="display:none;"';		
			}
		}
		else{
			$user["mostrarObs"] = 'style="display:none;"';		
		}
		
		
		//************** UNIVERSIDAD
		$sedeAlumno = Sede::where("id_sede", $estudiante->id_sede)->first();
		$universidadAlumno = Institucion::find($sedeAlumno->id_institucion);
		$user["universidad"] = $universidadAlumno->institucion;	

		$sql= "SELECT nombre as nombre_prueba FROM evaluado.evaluado as evaluado, evaluado.prueba as prueba, evaluado.carrera_prueba as carrera_prueba
				WHERE carrera_prueba.id_carrera = evaluado.id_carrera
				and carrera_prueba.id_prueba = prueba.id_prueba
				and evaluado.id_evaluado =	".$estudiante->id_evaluado;							

		
		$x = DB::select($sql);
		
		if(count($x)>0){

			$user["prueba1"] = $x[0]->nombre_prueba;
			$user["prueba1_asignatura"] = "";
			
			$user["prueba2"] = $x[1]->nombre_prueba;
			$user["prueba2_asignatura"] = "";
			
			$user["prueba3"] = "";	
			$user["prueba3_asignatura"] = "";	
			$user["ocultaPrueba3"] = "";
			if(array_key_exists(2, $x)){
				$user["prueba3"] = $x[2]->nombre_prueba;		
			}
			else{
				$user["ocultaPrueba3"] = 'style="display:none;"';
			}
			
			$user["token_validacion"] = $estudiante->link_validacion;
			
			// Mail::send('validacion/gracias-email', $user, function ($m) use ($estudiante) {
				// $m->from('info@diagnosticafid.cl', 'Diagnóstica FID');
				// $m->bcc('consultas@diagnosticafid.cl', 'Diagnóstica FID');
				
				
				// if(($estudiante->email1!="")&&($estudiante->email2!="")){
					// $m->to($estudiante->email1, $estudiante->nombres)->subject('Validación de tus datos de estudiante');	
					// $m->cc($estudiante->email2, $estudiante->nombres)->subject('Validación de tus datos de estudiante');	
				// }
				// elseif(($estudiante->email1!="")&&($estudiante->email2=="")){
					// $m->to($estudiante->email1, $estudiante->nombres)->subject('Validación de tus datos de estudiante');	
				// }
				// elseif(($estudiante->email1=="")&&($estudiante->email2!="")){
					// $m->to($estudiante->email2, $estudiante->nombres)->subject('Validación de tus datos de estudiante');	
				// }
				// else{
					// //$this->fields["email_string"] = "";			
				// }
			// });		
			
		}
		return redirect()->route('validacion-estudiante.gracias');			
	}
	
	public function gracias(Request $request){
		
		$id_estudiante = $request->session()->get('id_estudiante'); 
		if($id_estudiante!=""){
			$estudiante = Evaluado::find($id_estudiante);
			if(isset($estudiante->id_evaluado)){
				//$this->fields["primera_vez"] = "false";
				
				//if($request->session()->get('primera_vez') == true){
					$this->fields["primera_vez"] = "true";	
				//}

				//cambiar a false para cuando cierre el proceso (viernes 8 de diciembre 2017)
				$this->fields["texto_validado"] = true ? "Tus datos ya fueron validados.":"El proceso de validación se encuentra cerrado.";
				

				$this->fields["nombres"] = $estudiante->nombres;
				$this->fields["apellido_paterno"] = $estudiante->apellido_paterno;
				$this->fields["apellido_materno"] = $estudiante->apellido_materno;
				$this->fields["rut"] = $estudiante->rut;

				$this->fields["email1"] = "No registrado";	
				if($estudiante->email1!=""){
					$this->fields["email1"] = mb_strtolower($estudiante->email1);
				}
				
				$this->fields["email2"] = "No registrado";	
				if($estudiante->email2!=""){
					$this->fields["email2"] = mb_strtolower($estudiante->email2);
				}

				$this->fields["telefono_fijo"] = "No registrado";	
				if($estudiante->telefono_fijo!=""){
					$this->fields["telefono_fijo"] = $estudiante->telefono_fijo;
				}
				
				$this->fields["telefono_movil"] = "No registrado";	
				if($estudiante->telefono_movil!=""){
					$this->fields["telefono_movil"] = $estudiante->telefono_movil;	
				}

				$this->fields["usuario"] = $estudiante->usuario;
				
				if(($estudiante->email1!="")&&($estudiante->email2!="")){
					$this->fields["email_string"] = $estudiante->email1.", ".$estudiante->email2;			
				}
				elseif(($estudiante->email1!="")&&($estudiante->email2=="")){
					$this->fields["email_string"] = $estudiante->email1;			
				}
				elseif(($estudiante->email1=="")&&($estudiante->email2!="")){
					$this->fields["email_string"] = $estudiante->email2;			
				}
				else{
					$this->fields["email_string"] = "";			
				}
				
				//$universidadAlumno = InstitucionCampus::find($estudiante->sedeinstitucion_id)->institucion;
				//$this->fields["universidad"] = $universidadAlumno->nombre_institucion;	
				
				$sedeAlumno = Sede::where("id_sede", $estudiante->id_sede)->first();
				$universidadAlumno = Institucion::find($sedeAlumno->id_institucion);
				$this->fields["universidad"] = $universidadAlumno->institucion;	

				// //************** CAMPUS
				// $institucionCampus = InstitucionCampus::find($estudiante->sedeinstitucion_id);
				// $this->fields["sede"] = $institucionCampus["campus"];
				
				// //************** CARRERA
				// $carrera = Carrera::find($estudiante->id_carrera);		
				// $this->fields["carrera"] = $carrera->carrera;		

				$sql= "SELECT nombre as nombre_prueba FROM evaluado.evaluado as evaluado, evaluado.prueba as prueba, evaluado.carrera_prueba as carrera_prueba
					WHERE carrera_prueba.id_carrera = evaluado.id_carrera
					and carrera_prueba.id_prueba = prueba.id_prueba
					and evaluado.id_evaluado =	".$estudiante->id_evaluado;							
			
				
				$x = DB::select($sql);
				if(count($x)>0){
					$this->fields["prueba1"] = $x[0]->nombre_prueba;
					$this->fields["prueba1_asignatura"] = "";
					
					$this->fields["prueba2"] = $x[1]->nombre_prueba;
					$this->fields["prueba2_asignatura"] = "";
					
					$this->fields["prueba3"] = "";
					$this->fields["prueba3_asignatura"] = "";
					
					$this->fields["ocultaPrueba3"] = '';
					
					
					if(array_key_exists(2, $x)){
						$this->fields["prueba3"] = $x[2]->nombre_prueba;
					}
					else{
						$this->fields["ocultaPrueba3"] = 'style="display:none;"';
					}
					
				}
				else{
					$this->fields["prueba1"] = "";
					$this->fields["prueba1_asignatura"] = "";
					
					$this->fields["prueba2"] = "";
					$this->fields["prueba2_asignatura"] = "";
					
					$this->fields["prueba3"] = "";
					$this->fields["prueba3_asignatura"] = "";
					
					$this->fields["ocultaPrueba3"] = 'style="display:none;"';
				}
				
				
				
			$this->fields["correccionesSolicitadas"] = '';
			$this->fields["mostrarObs"] = '';

			if($estudiante->correccion_obs!=""){
				$this->fields["correccionesSolicitadas"] = $estudiante->correccion_obs;	
			}
			else{
				$this->fields["mostrarObs"] = 'style="display:none;"';		
			}
			
			// $salaAsignada = DB::select("SELECT c_sede.direccion, tipo_prueba, prueba, fecha_hora, id_estudiante, rut, nombre_sala, c_sede.sede, institucion, nombre_excel, fecha_hora, comuna.nombre as nombre_ciudad, c_sala.direccion as direccion_sede,
					// c_sala.facultad as facu
			
					// FROM ap_aplicacion_programacion, ap_prueba_carrera, ap_prueba, estudiante_listado, ap_estudiante_aplicacion, c_sala, ap_aplicacion, c_sede , institucion, comuna
					// WHERE ap_aplicacion_programacion.id_aplicacion_programacion = ap_prueba_carrera.id_aplicacion_programacion
					// AND c_sala.id_comuna = comuna.id_comuna
					// AND estudiante_listado.id = ap_estudiante_aplicacion.id_estudiante
					// AND ap_prueba.id_prueba = ap_aplicacion_programacion.id_prueba 
					// AND estudiante_listado.id_carrera = ap_prueba_carrera.id_carrera
					// AND c_sala.id_sala = ap_aplicacion.id_sala
					// AND ap_aplicacion.id_aplicacion = ap_estudiante_aplicacion.id_aplicacion
					// AND c_sala.id_sede = c_sede.id_sede
					// AND ap_aplicacion_programacion.id_tanda = 2
					// AND ap_aplicacion_programacion.id_aplicacion_programacion = ap_aplicacion.id_aplicacion_programacion
					// and rut = '".$estudiante->rut."'
					// AND institucion.id_institucion = c_sede.id_institucion
					// ORDER BY rut, fecha_hora, tipo_prueba, prueba, email1");	
					
				$txtSiInfo = "Sin información";
				$txtPorAsignar = "Por asignar";
				$txtPorAsignarFecha = "Presentarse";
				$this->fields["c_ciudad"] = $txtPorAsignar;
				$this->fields["c_institucion"] = $txtPorAsignar;
				$this->fields["c_sede"] = $txtPorAsignar;
				$this->fields["c_direccion_sede"] = $txtPorAsignar;
				$this->fields["c_sector_facultad"] = $txtPorAsignar;
				$this->fields["c_sala"] = $txtPorAsignar;
				$this->fields["c_fecha"] = $txtPorAsignarFecha;
				$this->fields["c_head"] = "Aún no te encuentras asignado/a a una sede/sala, te enviaremos un correo electrónico cuando la asignación esté preparada para que la puedas revisar.";

				//true / false
				$this->fields["habilita_box"] = false;
				//none / block
				$this->fields["display_box"] = "none";
				//none / block
				//$this->fields["display_fecha_hora"] = "none";
					
				if(isset($salaAsignada)){
					$this->fields["c_institucion"] = $salaAsignada[0]->nombre_institucion;
					$this->fields["c_ciudad"] = $this->mb_ucwords($salaAsignada[0]->nombre_ciudad);
					$this->fields["c_sede"] = $salaAsignada[0]->sede;
					$this->fields["c_direccion_sede"] = $salaAsignada[0]->direccion_sede;
					$this->fields["c_sector_facultad"] = ($salaAsignada[0]->facu!="")?$salaAsignada[0]->facu:$txtSiInfo;
					$this->fields["c_sala"] = $salaAsignada[0]->nombre_sala;
					$this->fields["c_fecha"] = $this->customFormatDate($salaAsignada[0]->fecha_hora);
					$this->fields["c_head"] = "Para rendir las pruebas que te corresponden, preséntate el día";
					//$this->fields["display_fecha_hora"] = "block";
				}
			
			}	
			return view('validacion/gracias', $this->fields);
		}
		return redirect()->route('validacion-estudiante.login');	
		
	}
		
    public function valida(Request $request, $link, $rut)
    {
		//echo $link;
		$this->fields["expirado"] = "link expirado o inexistente";
		if($link!=""){
			$estudiante = Evaluado::where([['link_validacion', $link],['rut', $rut]])->first();	
			
			if(count($estudiante)>0){
				
				//acá se actualizan los datos.
				//$estudiante->link_validado = true;
				//$estudiante->save();

				/*				
				68 descargaResultados	
				67 clic_link	
				66 validaDatos
				65 ingreso					
				*/
				
				$evaluadoIngreso = new EvaluadoAccion;
				$evaluadoIngreso->id_evaluado = $estudiante->id;
				$evaluadoIngreso->id_accion = 67;
				$evaluadoIngreso->save();				
				
				// $datos["id_campus"] = $estudiante->sedeinstitucion_id;
				// $datos["id_carrera"] = $estudiante->id_carrera;
				// $datos["nombres"] = $estudiante->nombres;
				// $datos["apellido_paterno"] = $estudiante->apellido_paterno;
				// $datos["apellido_materno"] = $estudiante->apellido_materno;
				// $datos["rut"] = $estudiante->rut;
				// $datos["id"] = $estudiante->id;
				// $datos["email1"] = $estudiante->email1;
				// $datos["email2"] = $estudiante->email2;
				// $datos["telefono_fijo"] = $estudiante->telefono_fijo;
				// $datos["telefono_movil"] = $estudiante->telefono_movil;
				// $datos["password"] = base64_decode($estudiante->password);

				// //******************INICIO AGREAMGOS AL USUARIO*************************//
				// $yaExisteUsuario = Users::where('username', $estudiante->usuario)->first();	

				// if(count($yaExisteUsuario)>0){
					// return redirect()->route('validacion-estudiante.login')->withFlashDanger("Ya existe el usuario asociado");
				// }
				// $usuarioSistema = new UserRepository(new RoleRepository);
				
				// $datosUser = array(
					// 'first_name' => $estudiante->nombres,
					// 'last_name' => $estudiante->apellido_paterno,
					// 'email' => $estudiante->usuario,
					// 'password' => base64_decode($estudiante->password),
				// );
				
				// $roles = array('assignees_roles'=>Role::where('id',6)->get());
			   
				// $user = new User;
				// $user->first_name = $datosUser["first_name"];
				// $user->last_name = $estudiante->apellido_paterno;				
				// $user->username = $estudiante->usuario;
				// $user->email = $estudiante->usuario;
				// $user->password = bcrypt($datos["password"]);
				// $user->status = 1;
				// $user->confirmation_code = md5(uniqid(mt_rand(), true));
				// $user->confirmed = 1;
			
				// DB::transaction(function () use ($user, $datosUser, $roles) {
					// if ($user->save()) {
						// //User Created, Validate Roles
						// if (! count($roles['assignees_roles'])) {
							// throw new GeneralException(trans('exceptions.backend.access.users.role_needed_create'));
						// }

						// //Attach new roles
						// $user->attachRoles($roles['assignees_roles']);

						// //Send confirmation email if requested and account approval is off
						// if (isset($data['confirmation_email']) && $user->confirmed == 0 && ! config('access.users.requires_approval')) {
							// //$user->notify(new UserNeedsConfirmation($user->confirmation_code));
						// }
						// //event(new UserCreated($user));

						// return true;
					// }

					// //
				// });
				
				// $idUsuario = $user->id;		
				
				
				// //$postulante->id_usuario = $idUsuario;
				// //$postulante->save();
				// //******************FIN AGREAMGOS AL USUARIO*************************//				
				// if((is_numeric($idUsuario))and($idUsuario>0)){
					// $datos["id_usuario"] = $idUsuario;
					
					// Estudiante::ingresaEstudiante($datos);	
				// }
				
				
				// //marcamos como expirado el registro
				// EstudianteModificacion::setLinkExpirado($estudiante->id_estudiante_modificacion);			
				$this->fields["expirado"] = "validación ok";
			}
			else{
				
			}
			return view('validacion/validado', $this->fields);
		}
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    function mb_ucwords($str)
	{
		return mb_convert_case($str, MB_CASE_TITLE, "UTF-8");
	}


	function customFormatDate($string){

		$transMonth["January"] = "Enero";
		$transMonth["February"] = "Febrero";
		$transMonth["March"] = "Marzo";
		$transMonth["April"] = "Abril";
		$transMonth["May"] = "Mayo";
		$transMonth["June"] = "Junio";
		$transMonth["July"] = "Julio";
		$transMonth["August"] = "Agosto";
		$transMonth["September"] = "Septiembre";
		$transMonth["October"] = "Octubre";
		$transMonth["November"] = "Noviembre";
		$transMonth["December"] = "Diciembre";

		$transDay['Sunday'] = "Domingo";
		$transDay['Monday']  = "Lunes";
		$transDay['Tuesday']  = "Martes";
		$transDay['Wednesday']  = "Miércoles";
		$transDay['Thursday'] = "Jueves";
		$transDay['Friday'] = "Viernes";
		$transDay['Saturday'] = "Sábado";

		$d = new \DateTime($string);

		$year = $d->format('Y');
		$month_name = strtolower($transMonth[$d->format('F')]);
		$day = $d->format('d');
		$day_name = strtolower($transDay[$d->format('l')]);

		return $day_name." ".$day." de ".$month_name." de ".$year;
	}

	//function redirectPrueba(){
	//	return view('edit2');
	//}
}

