<?php
namespace App\Models\Core;
use Illuminate\Database\Eloquent\Model;

class RolUsuario extends Model
{
	protected $table = 'core.rol_usuario';
	protected $primaryKey  = 'id_rol_usuario';
}