<?php
namespace App\Models\Core;
use Illuminate\Database\Eloquent\Model;

class RolProceso extends Model
{
	protected $table = 'core.rol_proceso';
	protected $primaryKey  = 'id_rol_proceso';
}