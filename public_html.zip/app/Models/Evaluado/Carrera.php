<?php
namespace App\Models\Evaluado;
use Illuminate\Database\Eloquent\Model;

class Carrera extends Model
{
	protected $table = 'evaluado.carrera';
	protected $primaryKey  = 'id_carrera';
}