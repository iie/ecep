<?php
namespace App\Models\Evaluado;
use Illuminate\Database\Eloquent\Model;

class Evaluado extends Model
{
	protected $table = 'evaluado.evaluado';
	protected $primaryKey  = 'id_evaluado';
}