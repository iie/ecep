<?php
namespace App\Models\Evaluado;
use Illuminate\Database\Eloquent\Model;

class EvaluadoAccion extends Model
{
	protected $table = 'evaluado.evaluado_accion';
	protected $primaryKey  = 'id_evaluado_accion';
}