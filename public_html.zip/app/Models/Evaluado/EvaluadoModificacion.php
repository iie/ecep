<?php
namespace App\Models\Evaluado;
use Illuminate\Database\Eloquent\Model;

class EvaluadoModificacion extends Model
{
	protected $table = 'evaluado.evaluado_modificacion';
	protected $primaryKey  = 'id_evaluado_modificacion';
}