<?php
namespace App\Models\Infraestructura;
use Illuminate\Database\Eloquent\Model;

class LaboratorioRevision extends Model
{
	protected $table = 'infraestructura.laboratorio_revision';
	protected $primaryKey  = 'id_laboratorio_revision';
}