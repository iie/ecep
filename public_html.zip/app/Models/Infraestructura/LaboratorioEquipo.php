<?php
namespace App\Models\Infraestructura;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class LaboratorioEquipo extends Model
{
	protected $table = 'infraestructura.laboratorio_equipo';
	protected $primaryKey  = 'id_laboratorio_equipo';

	static function obtenerCantEquiposTestVelocidad($idLabVisita){
	    $sql = DB::select("SELECT
			Count(infraestructura.laboratorio_equipo.id_laboratorio_equipo)
			FROM
			infraestructura.laboratorio_equipo
			INNER JOIN infraestructura.laboratorio_revision ON infraestructura.laboratorio_equipo.id_laboratorio_revision = infraestructura.laboratorio_revision.id_laboratorio_revision
			WHERE
			infraestructura.laboratorio_revision.id_laboratorio_visita = " . $idLabVisita . "
			AND infraestructura.laboratorio_equipo.velocidad_bajada != NULL");
		if(sizeof($sql>0)){
			return $sql[0]->count;
		}
    }
}